"""BUGS items 8 and 89 (07/10/2026): castShadows and castLocalShadows stored as Bool in compiled appearance data.

WolvenKit 8.19 and 8.20 refuse such a file ("Invalid in wolven rtti: ...castShadows [Expected: shadowsShadowCastingMode
| Got: Bool]"); a body file in that format (player reports, l0_000_base__full.app of a body mod) stopped the whole
conversion. The packages here follow the layout measured on hh_047_pwa__hairs_143.app (WINGDEER hair 47), whose rewritten
copy WolvenKit 8.19 then read (07/10/2026)."""
import json
import struct
import sys
import tempfile
import unittest
import zlib
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))

import legacy_shadows  # noqa: E402
import runtime_resources  # noqa: E402
from runtime_resources import Resources, UnreadableResource  # noqa: E402

NAMES = [b'entSkinnedMeshComponent', b'name', b'CName', b'hair', b'castShadows', b'Bool', b'castLocalShadows',
         b'autoHideDistance', b'Float']


def package(names, chunks):
    """A version 4 package: 1 cruid, names, and chunks given as (type index, [(name, type, value bytes)])."""
    cruids = struct.pack('<hH', -1, 1) + bytes(8)
    base = 0x24 + 8
    refs = b''
    desc_size = 4 * len(names)
    pool, descs = b'', []
    name_data = len(refs) + desc_size
    for name in names:
        descs.append(struct.pack('<I', (name_data + len(pool)) | (len(name) + 1) << 24))
        pool += name + b'\0'
    chunk_desc = name_data + len(pool)
    chunk_data = chunk_desc + 8 * len(chunks)
    bodies = []
    for _, fields in chunks:
        head = 2 + 8 * len(fields)
        table, values = b'', b''
        for name, kind, value in fields:
            table += struct.pack('<HHI', name, kind, head + len(values))
            values += value
        bodies.append(struct.pack('<H', len(fields)) + table + values)
    table, position = b'', chunk_data
    for (kind, _), body in zip(chunks, bodies):
        table += struct.pack('<II', kind, position)
        position += len(body)
    header = struct.pack('<HHI6I', 4, 7, 1, 0, 0, 0, name_data, chunk_desc, chunk_data)
    data = header + cruids + refs + b''.join(descs) + pool + table + b''.join(bodies)
    assert len(header + cruids) == base
    return data


def read_package(data):
    offsets = struct.unpack_from('<6I', data, 8)
    _, cruids = struct.unpack_from('<hH', data, 0x20)
    base = 0x24 + 8 * cruids
    _, _, name_desc, name_data, chunk_desc, chunk_data = offsets
    names = []
    for i in range((name_data - name_desc) // 4):
        value, = struct.unpack_from('<I', data, base + name_desc + 4 * i)
        names.append(data[base + (value & 0xFFFFFF):base + (value & 0xFFFFFF) + (value >> 24) - 1].decode())
    count = (chunk_data - chunk_desc) // 8
    descs = [struct.unpack_from('<II', data, base + chunk_desc + 8 * i) for i in range(count)]
    chunks = []
    for i, (kind, offset) in enumerate(descs):
        start = base + offset
        end = base + descs[i + 1][1] if i + 1 < count else len(data)
        fields, = struct.unpack_from('<H', data, start)
        heads = [struct.unpack_from('<HHI', data, start + 2 + 8 * k) for k in range(fields)]
        stops = sorted(at for _, _, at in heads) + [end - start]
        chunks.append((names[kind], {names[n]: (names[t], data[start + at:start + stops[stops.index(at) + 1]])
                                     for n, t, at in heads}))
    return names, chunks


def cr2w(buffers):
    """A CR2W with no chunks and the given uncompressed buffers, CRCs as the game files have them."""
    table_offset = 160
    objects_end = table_offset + 24 * len(buffers)
    entries, position = b'', objects_end
    for data in buffers:
        entries += struct.pack('<IIIIII', 0, 0, position, len(data), len(data), zlib.crc32(data))
        position += len(data)
    tables = bytearray(120)
    struct.pack_into('<III', tables, 12 * 5, table_offset, len(buffers), zlib.crc32(entries))
    header = bytearray(struct.pack('<4sIIQIIIII', b'CR2W', 195, 0, 0, 0, objects_end, position, 0xDEADBEEF, 0))
    struct.pack_into('<I', header, 32, zlib.crc32(bytes(header) + bytes(tables)))
    return bytes(header) + bytes(tables) + entries + b''.join(buffers)


def old_hair():
    return package(NAMES, [(0, [(1, 2, struct.pack('<H', 3)), (4, 5, b'\x00'), (6, 5, b'\x01'),
                                (7, 8, struct.pack('<f', 50.0))])])


class PackageTests(unittest.TestCase):
    def test_old_bools_become_the_enum_with_never_and_always(self):
        new, changed = legacy_shadows.upgrade_package(old_hair())
        self.assertEqual(changed, 2)
        names, chunks = read_package(new)
        kind, fields = chunks[0]
        self.assertEqual(kind, 'entSkinnedMeshComponent')
        self.assertEqual(fields['castShadows'][0], 'shadowsShadowCastingMode')
        self.assertEqual(names[struct.unpack('<H', fields['castShadows'][1])[0]], 'Never')
        self.assertEqual(fields['castLocalShadows'][0], 'shadowsShadowCastingMode')
        self.assertEqual(names[struct.unpack('<H', fields['castLocalShadows'][1])[0]], 'Always')

    def test_fields_after_them_keep_their_values(self):
        new, _ = legacy_shadows.upgrade_package(old_hair())
        _, chunks = read_package(new)
        fields = chunks[0][1]
        self.assertEqual(struct.unpack('<f', fields['autoHideDistance'][1])[0], 50.0)
        self.assertEqual(fields['name'], ('CName', struct.pack('<H', 3)))
        self.assertEqual(read_package(new)[0][:len(NAMES)], [n.decode() for n in NAMES])

    def test_names_already_in_the_pool_are_reused(self):
        names = NAMES + [b'shadowsShadowCastingMode', b'Never', b'Always']
        data = package(names, [(0, [(4, 5, b'\x00')]), (0, [(4, 9, struct.pack('<H', 11))])])
        new, changed = legacy_shadows.upgrade_package(data)
        self.assertEqual(changed, 1)
        pool, chunks = read_package(new)
        self.assertEqual(len(pool), len(names))
        self.assertEqual(chunks[0][1]['castShadows'], ('shadowsShadowCastingMode', struct.pack('<H', 10)))
        self.assertEqual(chunks[1][1]['castShadows'], ('shadowsShadowCastingMode', struct.pack('<H', 11)))

    def test_current_files_are_left_alone(self):
        names = NAMES + [b'shadowsShadowCastingMode', b'Always']
        data = package(names, [(0, [(4, 9, struct.pack('<H', 10))])])
        self.assertEqual(legacy_shadows.upgrade_package(data), (data, 0))


class FileTests(unittest.TestCase):
    def test_buffer_table_and_crcs_follow_the_new_buffer(self):
        current = package(NAMES, [(0, [(1, 2, struct.pack('<H', 3))])])
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'hair.app'
            path.write_bytes(cr2w([old_hair(), current]))
            self.assertEqual(legacy_shadows.upgrade(path, Path(folder) / 'WolvenKit.CLI.exe'), 2)
            data = path.read_bytes()
        fields = struct.unpack_from('<4sIIQIIIII', data, 0)
        table_offset, count, table_crc = struct.unpack_from('<III', data, 40 + 12 * 5)
        entries = [struct.unpack_from('<IIIIII', data, table_offset + 24 * i) for i in range(count)]
        self.assertEqual(table_crc, zlib.crc32(data[table_offset:table_offset + 24 * count]))
        first, second = entries
        self.assertEqual(first[2], fields[5])
        self.assertEqual(second[2], first[2] + first[3])
        self.assertEqual(fields[6], len(data))
        for entry in entries:
            self.assertEqual(entry[5], zlib.crc32(data[entry[2]:entry[2] + entry[3]]))
        self.assertEqual(data[second[2]:second[2] + second[3]], current)
        header = bytearray(data[:160])
        struct.pack_into('<I', header, 32, 0xDEADBEEF)
        self.assertEqual(fields[7], zlib.crc32(bytes(header)))
        self.assertEqual(read_package(data[first[2]:first[2] + first[3]])[1][0][1]['castShadows'][0],
                         'shadowsShadowCastingMode')

    def test_other_files_are_not_touched(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'other.app'
            data = cr2w([package(NAMES[:4], [(0, [(1, 2, struct.pack('<H', 3))])])])
            path.write_bytes(data)
            self.assertEqual(legacy_shadows.upgrade(path, Path(folder) / 'WolvenKit.CLI.exe'), 0)
            self.assertEqual(path.read_bytes(), data)


class OldFormatWolvenKit:
    """Refuses a file while it still has old Bool fields, as WolvenKit 8.19 does."""

    def __init__(self):
        self.calls = []

    def __call__(self, cli, *args):
        args = [str(a) for a in args]
        self.calls.append(args)
        if args[:2] == ['convert', 'serialize']:
            for source in args[2:]:
                data = Path(source).read_bytes()
                table, count, _ = struct.unpack_from('<III', data, 40 + 12 * 5)
                old = False
                for i in range(count):
                    _, _, at, size, _, _ = struct.unpack_from('<IIIIII', data, table + 24 * i)
                    old = old or legacy_shadows.upgrade_package(data[at:at + size])[1] > 0
                if old:
                    Path(source + '.json').write_text('', encoding='utf8')
                    raise ValueError('WolvenKit: [ 0: Error       ] - Invalid in wolven rtti:'
                                     '"entSkinnedMeshComponent.castShadows" [Expected: "shadowsShadowCastingMode" '
                                     '| Got: "Bool"]')
                Path(source + '.json').write_text(json.dumps({'Data': {'RootChunk': {}}}), encoding='utf8')
        return ''


class ReaderTests(unittest.TestCase):
    RESOURCE = 'base\\characters\\common\\player_base_bodies\\appearances\\l0_000_base__full.app'

    def reader(self, folder, data):
        game = Path(folder)
        (game / 'archive/pc/content').mkdir(parents=True)
        (game / 'archive/pc/mod').mkdir(parents=True)
        reader = Resources(game, game / 'WolvenKit.CLI.exe', game / 'cache')
        path = reader.path(self.RESOURCE)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return reader

    def test_an_old_format_body_file_is_read_after_the_upgrade(self):
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(runtime_resources, 'cli_run', side_effect=OldFormatWolvenKit()) as fake:
            reader = self.reader(folder, cr2w([old_hair()]))
            with patch.object(reader, 'fetch'):
                self.assertEqual(reader.read(self.RESOURCE), {'Data': {'RootChunk': {}}})
            self.assertNotIn(self.RESOURCE, reader.unreadable)
            self.assertEqual(len([c for c in fake.side_effect.calls if c[:2] == ['convert', 'serialize']]), 2)

    def test_the_batch_path_also_upgrades(self):
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(runtime_resources, 'cli_run', side_effect=OldFormatWolvenKit()):
            reader = self.reader(folder, cr2w([old_hair()]))
            with patch.object(reader, 'fetch'):
                reader.serialize([self.RESOURCE])
                self.assertNotIn(self.RESOURCE, reader.unreadable)
                self.assertEqual(reader.read(self.RESOURCE), {'Data': {'RootChunk': {}}})

    def test_a_file_unreadable_for_another_reason_stays_unreadable(self):
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(runtime_resources, 'cli_run', side_effect=ValueError('WolvenKit: [ 0: Error ] other')):
            reader = self.reader(folder, cr2w([package(NAMES[:4], [(0, [(1, 2, struct.pack('<H', 3))])])]))
            with patch.object(reader, 'fetch'), self.assertRaises(UnreadableResource):
                reader.read(self.RESOURCE)


if __name__ == '__main__':
    unittest.main()
