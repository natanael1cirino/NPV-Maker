"""Every NPC appearance of the game carries an entVisualControllerComponent; the NPV had none (10/10/2026)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import runtime_npc  # noqa: E402


def mesh(name, path, appearance):
    return {'$type': 'entSkinnedMeshComponent', 'name': {'$value': name}, 'meshAppearance': {'$value': appearance},
            'mesh': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': path}, 'Flags': 'Default'}}


class VisualControllerTests(unittest.TestCase):
    def setUp(self):
        self.parts = [mesh('t0_body', 'base\\body.mesh', 'skin_01'),
                      {'$type': 'entMorphTargetSkinnedMeshComponent', 'name': {'$value': 'h0_head'},
                       'morphResource': {'DepotPath': {'$value': 'base\\head.morphtarget'}}},
                      {'$type': 'entAnimatedComponent', 'name': {'$value': 'face_rig'}},
                      mesh('hair', 'mod\\hair.mesh', 'black')]
        self.vc = runtime_npc.visual_controller(self.parts)

    def test_it_is_the_component_of_the_game_npcs(self):
        self.assertEqual(self.vc['$type'], 'entVisualControllerComponent')
        self.assertEqual(self.vc['name']['$value'], 'AppearanceVisualController')
        self.assertEqual(self.vc['forcedLodDistance'], 'Cinematic')

    def test_it_lists_the_meshes_with_their_appearance(self):
        deps = [(d['componentName']['$value'], d['appearanceName']['$value'], d['mesh']['DepotPath']['$value'])
                for d in self.vc['appearanceDependency']]
        self.assertEqual(deps, [('t0_body', 'skin_01', 'base\\body.mesh'), ('hair', 'black', 'mod\\hair.mesh')])

    def test_no_proxy_of_another_character(self):
        self.assertEqual(self.vc['meshProxy']['DepotPath']['$value'], '0')


if __name__ == '__main__':
    unittest.main()
