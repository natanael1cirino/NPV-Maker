#include "BodyPolicy.hpp"
#include <iostream>
int main() {
    int own=0, other=0;
    if (!npvfit::MayOverride(1,true,&own,17,&own,17,true)) return 1;
    if (npvfit::MayOverride(1,false,&own,17,&own,17,true)) return 2;
    if (npvfit::MayOverride(1,true,&own,17,&other,17,true)) return 3;
    if (npvfit::MayOverride(1,true,&own,17,&own,18,true)) return 4;
    if (npvfit::MayOverride(0,true,&own,17,&own,17,true)) return 5;
    if (npvfit::MayOverride(1,true,&own,17,&own,17,false)) return 6;
    if (npvfit::MayOverride(1,true,nullptr,0,&own,17,true)) return 7;
    if (!npvfit::ValidBody("ebbrb") || !npvfit::ValidBody("BaseBody") || !npvfit::ValidBody("")) return 8;
    if (npvfit::ValidBody("body:path") || npvfit::ValidBody("../mesh") || npvfit::ValidBody("two words")) return 9;
    if (npvfit::ValidBody(std::string(65,'a'))) return 10;
    std::cout << "Body scope and input policy: 14 cases PASS\n";
}
