"""The NPV gets its own copy of every morphtarget kept on the original file (BUGS 93, 07/10/2026)."""
import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import runtime_npc
from runtime_resources import Resources

NAMESPACE = 'npvmaker\\generated\\97687c3213ab87e8'
HEAD = 'base\\characters\\head\\player_base_heads\\player_man_average\\h0_000_pma__morphs.morphtarget'
EYES = 'base\\characters\\head\\player_base_heads\\player_man_average\\he_000_pma__morphs.morphtarget'
BROWS = 'base\\characters\\head\\player_base_heads\\player_man_average\\heb_000_pma__morphs.morphtarget'
ARKHE = 'arkhe_copy\\characters\\head\\player_base_heads\\player_man_average\\heb_000_pma__morphs.morphtarget'


def morph_part(name, path):
    return {'$type': 'entMorphTargetSkinnedMeshComponent', 'name': {'$value': name},
            'morphResource': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': path},
                              'Flags': 'Default'}}


def reader(copies=None):
    found = Resources.__new__(Resources)
    found.copies = {k.lower(): v for k, v in (copies or {}).items()}
    return found


class PrivateMorphTests(unittest.TestCase):
    def test_kept_pieces_point_to_private_paths(self):
        parts = [morph_part('head', HEAD), morph_part('eyes', EYES)]
        copies = runtime_npc.private_morphs(reader(), parts, NAMESPACE)
        paths = [p['morphResource']['DepotPath']['$value'] for p in parts]
        self.assertEqual(sorted(copies.values()), sorted([HEAD, EYES]))
        for path in paths:
            self.assertTrue(path.startswith(NAMESPACE + '\\morphs\\'))
            self.assertNotIn(path, (HEAD, EYES))
        self.assertEqual(copies[paths[0]], HEAD)
        self.assertTrue(paths[0].endswith('_h0_000_pma__morphs.morphtarget'))

    def test_two_components_on_one_file_share_one_private_copy(self):
        parts = [morph_part('eyes', EYES), morph_part('eyes_lashes', EYES)]
        copies = runtime_npc.private_morphs(reader(), parts, NAMESPACE)
        self.assertEqual(len(copies), 1)
        self.assertEqual(parts[0]['morphResource'], parts[1]['morphResource'])

    def test_an_archivexl_copy_is_followed_to_its_archived_source(self):
        parts = [morph_part('brows', ARKHE)]
        copies = runtime_npc.private_morphs(reader({ARKHE: BROWS}), parts, NAMESPACE)
        self.assertEqual(list(copies.values()), [BROWS])

    def test_hash_only_and_other_components_are_untouched(self):
        hashed = morph_part('x', '11897495395662920209')
        hashed['morphResource']['DepotPath']['$storage'] = 'uint64'
        mesh = {'$type': 'entSkinnedMeshComponent', 'name': {'$value': 'm'},
                'mesh': {'DepotPath': {'$value': 'npvmaker\\generated\\x\\meshes\\a.mesh'}}}
        before = copy.deepcopy([hashed, mesh])
        self.assertEqual(runtime_npc.private_morphs(reader(), [hashed, mesh], NAMESPACE), {})
        self.assertEqual([hashed, mesh], before)

    def test_private_path_is_the_same_for_the_same_npv_and_differs_between_npvs(self):
        one = runtime_npc.private_morph_path(NAMESPACE, HEAD)
        self.assertEqual(one, runtime_npc.private_morph_path(NAMESPACE, HEAD))
        self.assertNotEqual(one, runtime_npc.private_morph_path('npvmaker\\generated\\0000000000000000', HEAD))


class ArchiveXlCopyTests(unittest.TestCase):
    def test_copy_section_lists_original_then_private(self):
        private = runtime_npc.private_morph_path(NAMESPACE, HEAD)
        text = runtime_npc.archive_xl_text({}, None, {}, {private: HEAD})
        self.assertIn('resource:\n  copy:\n    ' + HEAD + ':\n      - ' + private + '\n', text)

    def test_copy_beside_patch_and_names(self):
        private = runtime_npc.private_morph_path(NAMESPACE, HEAD)
        text = runtime_npc.archive_xl_text({'a\\patch.mesh': ['b.mesh']}, NAMESPACE + '\\names.json', {},
                                           {private: HEAD})
        self.assertEqual(text.count('resource:'), 1)
        self.assertIn('  copy:\n', text)
        self.assertIn('  patch:\n', text)

    def test_no_copy_section_without_copies(self):
        self.assertNotIn('copy:', runtime_npc.archive_xl_text({}, None, {}, {}))


if __name__ == '__main__':
    unittest.main()
