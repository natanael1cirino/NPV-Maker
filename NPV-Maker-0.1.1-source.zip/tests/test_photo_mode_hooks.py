import re
import sys
import unittest
from pathlib import Path


SOURCE = Path(__file__).resolve().parents[1] / 'src/redscript'


def photo_mode_wraps(folder):
    text = ''.join(path.read_text(encoding='utf8') for path in sorted(Path(folder).glob('*.reds')))
    return re.findall(r'@wrapMethod\(gameuiPhotoModeMenuController\)\s*\n\s*[^\n]*func (\w+)\(', text)


class PhotoModeHooksTest(unittest.TestCase):
    """Player log 07/10/2026 (0.1.0): another mod declares gameuiPhotoModeMenuController.OnUninitialize returning Void;
    NPV Maker's wrap "let result: Bool = wrappedMethod()" failed to compile (NPVMakerMorphs.reds:207:22) and redscript
    turned off every mod's scripts. Reproduced with the game's scc and a stub mod. Only OnShow, the standard hook of that
    screen, is wrapped; the end of photo mode is found through PhotoModeSystem."""

    def test_on_uninitialize_of_photo_mode_is_not_wrapped(self):
        self.assertNotIn('OnUninitialize', photo_mode_wraps(SOURCE))

    def test_photo_mode_exit_is_polled(self):
        text = (SOURCE / 'NPVMakerMorphs.reds').read_text(encoding='utf8')
        self.assertIn('GameInstance.GetPhotoModeSystem(GetGameInstance()).IsPhotoModeActive()', text)
        self.assertIn('NPVMakerMorphWatch.Get().WatchPhotoModeExit();', text)
        self.assertIn('this.RefreshAfterPhotoMode();', text)

    def test_pulse_does_not_animate_the_photo_mode_root(self):
        """Player report 07/10/2026 (0.1.0): Hide UI in photo mode came back at once. Vanilla OnFadeVisibility hides the UI
        with a transparency animation of the screen's root widget, and the pulse animated the same widget."""
        text = ''.join(path.read_text(encoding='utf8') for path in sorted(SOURCE.glob('*.reds')))
        starts = re.findall(r'NPVMakerMorphPulse\.Start\(([^)]*\)?)\)', text)
        self.assertTrue(starts)
        for argument in starts:
            self.assertNotIn('GetRootWidget', argument)
            self.assertNotIn('GetRootCompoundWidget', argument)
        self.assertIn('ticker.Reparent(this.GetRootCompoundWidget());', text)


if __name__ == '__main__':
    if len(sys.argv) > 1:
        SOURCE = Path(sys.argv.pop())
    unittest.main()
