"""Wardrobe outfit (ROUPAS) in the converted NPV: what the editor puppet wore becomes appearance options."""
import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import diagnostics
import i18n
import runtime_npc
from runtime_npc import collect_components, outfit_options, outfit_section
from runtime_resources import ResourceMissing, path_hash


def cname(name):
    return {'$type': 'CName', '$storage': 'string', '$value': name}


def garment(name, mesh, look='default'):
    return {'$type': 'entGarmentSkinnedMeshComponent', 'name': cname(name), 'id': name,
            'mesh': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': mesh},
                     'Flags': 'Default'}, 'meshAppearance': cname(look)}


def app(*appearances):
    return {'Data': {'RootChunk': {'appearances': [{'Data': {'name': cname(name), 'components': list(parts)}}
                                                   for name, parts in appearances]}}}


def ent(*entries):
    return {'Data': {'RootChunk': {'appearances': [
        {'$type': 'entTemplateAppearance', 'name': cname(name), 'appearanceName': cname(look),
         'appearanceResource': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': path},
                                'Flags': 'Default'}} for name, path, look in entries]}}}


class Reader:
    def __init__(self, resources, present=None):
        self.resources = resources
        self.present = present
        if present is not None:
            self.owners = lambda key: ['mod.archive'] if key in self.present else []
            self.base_owner = lambda key: None

    def read(self, path):
        if path not in self.resources:
            raise ResourceMissing('Recurso nao encontrado nos mods instalados: ' + path)
        return copy.deepcopy(self.resources[path])

    def register(self, value, suffix):
        return value + suffix

    def source(self, path):
        return path


SHIRT_APP = 'base\\characters\\garment\\player_equipment\\torso\\t1_024_shirt.app'
SHIRT_MESH = 'base\\characters\\garment\\player_equipment\\torso\\t1_024_pwa_shirt.mesh'
REFIT_MESH = 'mymod\\shirt\\ebbrb\\t1_mymod_shirt_w.mesh'


def row(name, mesh, owner_app=SHIRT_APP, owner_appearance='t1_024_shirt_basic_01', look='basic_01'):
    return {'name': name, 'type': 'entGarmentSkinnedMeshComponent', 'enabled': True,
            'owner_appearance': owner_appearance, 'owner_app': owner_app, 'field': 'mesh',
            'hash': path_hash(mesh), 'path': mesh, 'mesh_appearance': look, 'chunk_mask': '18446744073709551615'}


def project(*pieces, body='female'):
    return {'name': 'teste', 'body': body, 'outfit': {'schema': 1, 'pieces': list(pieces)}}


def piece(record='Items.Shirt_01', components=(), template='', appearance='', covers=False, body='ebbrb'):
    return {'record': record, 'slot': 'OutfitSlots.TorsoMiddle', 'name': 'Shirt', 'template': template,
            'appearance': appearance, 'body': body, 'covers_groin': covers, 'components': list(components)}


class OutfitSectionTests(unittest.TestCase):
    def test_project_without_wardrobe_has_no_outfit(self):
        self.assertEqual(outfit_section({'name': 'x'}), ([], ''))

    def test_unknown_schema_is_reported_not_used(self):
        pieces, reason = outfit_section({'outfit': {'schema': 9, 'pieces': []}})
        self.assertEqual(pieces, [])
        self.assertIn('formato desconhecido', reason)

    def test_bad_rows_are_dropped_and_names_kept(self):
        bad = dict(row('t1_shirt', SHIRT_MESH), field='rig')
        long_path = dict(row('t1_shirt', SHIRT_MESH), path='x' * 600)
        pieces, _ = outfit_section(project(piece(components=[row('t1_shirt', SHIRT_MESH), bad, long_path, 'junk'])))
        self.assertEqual(len(pieces), 1)
        self.assertEqual([r['name'] for r in pieces[0]['components']], ['t1_shirt'])
        self.assertEqual(pieces[0]['record'], 'Items.Shirt_01')
        self.assertEqual(pieces[0]['slot'], 'OutfitSlots.TorsoMiddle')


class OutfitOptionTests(unittest.TestCase):
    def test_observed_components_become_one_option_per_app_and_appearance(self):
        reader = Reader({SHIRT_APP: app(('t1_024_shirt_basic_01', [garment('t1_shirt', SHIRT_MESH)]))})
        options, records, reason = outfit_options(reader, project(piece(components=[row('t1_shirt', SHIRT_MESH)])))
        self.assertEqual(reason, '')
        self.assertEqual(len(options), 1)
        self.assertEqual(options[0]['name'], 'outfit:Items.Shirt_01')
        self.assertEqual((options[0]['resource_path'], options[0]['selected_name']), (SHIRT_APP, 't1_024_shirt_basic_01'))
        self.assertEqual(options[0]['body_part'], 'Outfit')
        self.assertEqual([r['name'] for r in options[0]['runtime_components']], ['t1_shirt'])
        self.assertEqual(records[0]['source'], 'observed')
        self.assertEqual(options[0]['path_tokens'], {'gender': 'w', 'camera': 'tpp', 'body': 'ebbrb', 'variant': ''})

    def test_entity_and_appearance_are_the_fallback_without_observed_owner(self):
        template = 'base\\gameplay\\items\\equipment\\torso\\t1_024_shirt.ent'
        reader = Reader({template: ent(('t1_024_shirt_basic_01&Female&TPP', SHIRT_APP, 't1_024_shirt_basic_01')),
                         SHIRT_APP: app(('t1_024_shirt_basic_01', [garment('t1_shirt', SHIRT_MESH)]))})
        options, records, _ = outfit_options(reader, project(piece(template=template,
                                                                   appearance='t1_024_shirt_basic_01&Female&TPP')))
        self.assertEqual((options[0]['resource_path'], options[0]['selected_name']), (SHIRT_APP, 't1_024_shirt_basic_01'))
        self.assertEqual(records[0]['source'], 'entity')

    def test_dynamic_appearance_uses_the_base_name_and_its_variant(self):
        dyn_app = 'mymod\\shirt\\shirt.app'
        reader = Reader({dyn_app: app(('mymod_shirt', [garment('t1_shirt', '*mymod\\shirt\\{body}\\t1_{gender}.mesh',
                                                               '{variant}')]))})
        observed = dict(row('t1_shirt', REFIT_MESH, dyn_app, 'mymod_shirt!red'), hash=None, path=None)
        options, _, _ = outfit_options(reader, project(piece(components=[observed], appearance='mymod_shirt!red')))
        self.assertEqual(options[0]['selected_name'], 'mymod_shirt')
        self.assertEqual(options[0]['path_tokens']['variant'], 'red')

    def test_piece_with_nothing_readable_is_recorded_as_none(self):
        options, records, _ = outfit_options(Reader({}), project(piece(appearance='x')))
        self.assertEqual(options, [])
        self.assertEqual(records[0]['source'], 'none')

    def test_male_body_and_vanilla_refit_tokens(self):
        _, records, _ = outfit_options(Reader({}), project(piece(body='BaseBody'), body='male'))
        tokens = runtime_npc.dynamic_tokens(piece(body='BaseBody'), 'male')
        self.assertEqual((tokens['gender'], tokens['body']), ('m', 'base_body'))


class OutfitComponentTests(unittest.TestCase):
    def test_observed_refit_mesh_replaces_the_app_mesh(self):
        reader = Reader({SHIRT_APP: app(('t1_024_shirt_basic_01', [garment('t1_shirt', SHIRT_MESH)]))})
        options, _, _ = outfit_options(reader, project(piece(components=[row('t1_shirt', REFIT_MESH)])))
        result = collect_components(reader, options, {})
        parts = list(result['selected'].values())
        self.assertEqual(len(parts), 1)
        self.assertEqual(parts[0]['mesh']['DepotPath']['$value'], REFIT_MESH)
        self.assertEqual(parts[0]['meshAppearance']['$value'], 'basic_01')
        self.assertEqual(result['used'][0]['name'], 'outfit:Items.Shirt_01')

    def test_dynamic_path_without_observed_mesh_resolves_tokens(self):
        dyn_app = 'mymod\\shirt\\shirt.app'
        dynamic = '*mymod\\shirt\\{body}\\t1_{gender}.mesh'
        reader = Reader({dyn_app: app(('mymod_shirt', [garment('t1_shirt', dynamic, '{variant}')]))},
                        present={'mymod\\shirt\\ebbrb\\t1_w.mesh'})
        options, _, _ = outfit_options(reader, project(piece(appearance='mymod_shirt!red',
                                                             components=[dict(row('t1_shirt', REFIT_MESH, dyn_app,
                                                                                  'mymod_shirt'), hash=None, path=None,
                                                                              mesh_appearance=None)])))
        part = list(collect_components(reader, options, {})['selected'].values())[0]
        self.assertEqual(part['mesh']['DepotPath']['$value'], 'mymod\\shirt\\ebbrb\\t1_w.mesh')
        self.assertEqual(part['meshAppearance']['$value'], 'red')

    def test_missing_refit_falls_back_to_base_body_like_archivexl(self):
        dyn_app = 'mymod\\shirt\\shirt.app'
        reader = Reader({dyn_app: app(('mymod_shirt', [garment('t1_shirt', '*mymod\\{body}\\t1.mesh')]))}, present=set())
        options, _, _ = outfit_options(reader, project(piece(template='', appearance='mymod_shirt', components=[
            dict(row('t1_shirt', REFIT_MESH, dyn_app, 'mymod_shirt'), hash=None, path=None, mesh_appearance=None)])))
        part = list(collect_components(reader, options, {})['selected'].values())[0]
        self.assertEqual(part['mesh']['DepotPath']['$value'], 'mymod\\base_body\\t1.mesh')

    def test_broken_piece_is_left_out_not_fatal(self):
        options = [dict(name='outfit:Items.Gone', body_part='Outfit', resource_path='gone.app', selected_name='x',
                        runtime_components=[], path_tokens={})]
        result = collect_components(Reader({}), options, {})
        self.assertEqual(result['selected'], {})
        self.assertEqual(result['skipped'][0]['name'], 'outfit:Items.Gone')
        self.assertEqual(result['diagnostics'][0]['slot'], 'Roupa')


class OutfitBuildTests(unittest.TestCase):
    def test_pants_from_the_wardrobe_hide_the_genitals_like_the_default_underwear(self):
        genitals = dict(name='genitals', active=True)
        options, hidden = runtime_npc.covered_genitals([genitals], 'none', True)
        self.assertEqual([o['active'] for o in options], [False])
        self.assertEqual(hidden[0]['name'], 'genitals')
        self.assertEqual(runtime_npc.covered_genitals([genitals], 'none')[1], [])
        self.assertTrue(runtime_npc.outfit_covers(project(piece(covers=True))))
        self.assertFalse(runtime_npc.outfit_covers(project(piece())))

    def test_build_adds_the_outfit_after_the_default_underwear(self):
        source = Path(runtime_npc.__file__).read_text(encoding='utf8')
        self.assertIn('outfit, outfit_records, outfit_reason = outfit_options(reader, project)', source)
        self.assertIn('options = options + outfit', source)
        self.assertIn('"outfit": outfit_records', source)

    def test_codes_are_registered_and_translated(self):
        for code in ('NPVM-OUTFIT-001', 'NPVM-OUTFIT-002'):
            self.assertIn(code, diagnostics.CODES)
            self.assertIn(code, i18n.CODES)
        self.assertIn('NPVM-OUTFIT-002', i18n.HINTS)
        self.assertIn('Roupa', i18n.SLOTS)


def drawn(name, mesh, app=r'6190507694667453790_0.app', look='black', kind='entGarmentSkinnedMeshComponent'):
    return {'name': name, 'type': kind, 'enabled': True, 'owner_appearance': 'AppearanceName0', 'owner_app': app,
            'field': 'mesh', 'hash': path_hash(mesh), 'path': mesh, 'mesh_appearance': look,
            'chunk_mask': '18446744073709551615', 'state': 'LOADED'}


UNDERWEAR = r'base\characters\appearances\player\items\legs\l1_underwear_01.app'
PANTIES = r'base\characters\garment\player_equipment\legs\l1_047_pwa_shorts__panties.mesh'
JACKET = r'base\characters\garment\citizen_formal\torso\t2_103_jacket__agent\t2_103_wa_jacket__agent.mesh'
GLASSES = r'base\characters\garment\player_equipment\head\h1_007_specs__aviators\h1_007_pwa_specs__aviators.mesh'


def dressed(*rows, pieces=()):
    project_doc = project(*pieces)
    project_doc['runtime_manifest'] = {'schema': 1, 'status': 'captured', 'components': list(rows)}
    return project_doc


class DrawnOutfitTests(unittest.TestCase):
    """MEDIDO 08/10/2026, project "roupa": the item entities came empty with appearance "default"; the puppet drew
    the pieces from appearances the game generated (<number>_<n>.app)."""

    def test_only_rows_of_generated_apps_are_worn(self):
        body = dict(drawn('t0_000_pwa_base__full', 'body.mesh'), owner_app=r'base\characters\t0_000_base__full.app')
        rows = runtime_npc.worn_rows(dressed(body, drawn('t2_103_wa_jacket__agent6815', JACKET),
                                             dict(drawn('x', 'x.mesh'), state='MISSING')))
        self.assertEqual([r['name'] for r in rows], ['t2_103_wa_jacket__agent6815'])

    def test_record_appearance_name_finds_the_entity_appearance(self):
        piece_doc = piece(template=r'base\gameplay\items\equipment\face\player_face_item.ent', appearance='default')
        piece_doc['appearance_name'] = 'h1_007_specs_aviators_01_'
        self.assertEqual(runtime_npc.appearance_candidates(piece_doc, 'female')[:2],
                         ['h1_007_specs_aviators_01_&Female&TPP', 'h1_007_specs_aviators_01_&Female'])
        self.assertNotIn('default', runtime_npc.appearance_candidates(piece_doc, 'female'))

    def test_a_piece_the_puppet_did_not_draw_adds_nothing(self):
        reader = Reader({SHIRT_APP: app(('t1_024_shirt_basic_01', [garment('t1_shirt', SHIRT_MESH)]))})
        doc = dressed(drawn('t2_103_wa_jacket__agent6815', JACKET),
                      pieces=[piece(components=[row('t1_shirt', SHIRT_MESH)])])
        options, _, _ = outfit_options(reader, doc)
        self.assertEqual(options[0]['drawn_only'], ['t2_103_wa_jacket__agent6815'])
        self.assertEqual(collect_components(reader, options, {})['selected'], {})

    def test_dangle_skeleton_of_a_drawn_piece_comes_along(self):
        # MEDIDO 10/10/2026 (NPV "60", Items.Q304_netrunner_outfit_ow): the pants and necklace move on the
        # giselle_dangle_skeleton.rig of two entAnimatedComponent; without them a strap hung to the floor.
        rig = 'ep1\\characters\\main_npc\\giselle\\giselle_dangle_skeleton.rig'
        dangle = {'$type': 'entAnimatedComponent', 'name': cname('Animated4171'), 'id': 'Animated4171',
                  'rig': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': rig},
                          'Flags': 'Obligatory'},
                  'facialSetup': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'uint64', '$value': '0'}}}
        face = dict(dangle, name=cname('face_rig'), id='face_rig',
                    facialSetup={'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': 'x.facialsetup'}})
        reader = Reader({SHIRT_APP: app(('t1_024_shirt_basic_01', [garment('t1_shirt', SHIRT_MESH), dangle, face,
                                                                   garment('t1_other', 'other.mesh')]))})
        doc = dressed(drawn('t1_shirt', SHIRT_MESH), pieces=[piece(components=[row('t1_shirt', SHIRT_MESH)])])
        options, _, _ = outfit_options(reader, doc)
        names = sorted(p['name']['$value'] for p in collect_components(reader, options, {})['selected'].values())
        self.assertEqual(names, ['Animated4171', 't1_shirt'])

    def test_dangle_skeleton_alone_adds_nothing(self):
        dangle = {'$type': 'entAnimatedComponent', 'name': cname('Animated4171'), 'id': 'Animated4171',
                  'rig': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string', '$value': 'd.rig'}}}
        self.assertEqual(runtime_npc.drawn_with_skeletons([garment('t1_shirt', SHIRT_MESH), dangle], ['other']), [])

    def test_drawn_piece_with_its_definition_keeps_the_definition(self):
        reader = Reader({SHIRT_APP: app(('t1_024_shirt_basic_01', [garment('t1_shirt', SHIRT_MESH)]))})
        doc = dressed(drawn('t1_shirt', REFIT_MESH, look='red'), pieces=[piece(components=[row('t1_shirt', SHIRT_MESH)])])
        options, _, _ = outfit_options(reader, doc)
        part = list(collect_components(reader, options, {})['selected'].values())[0]
        self.assertEqual((part['mesh']['DepotPath']['$value'], part['meshAppearance']['$value']), (REFIT_MESH, 'red'))

    def test_drawn_pieces_without_definition_are_built_on_the_underwear_component(self):
        reader = Reader({UNDERWEAR: app(('basic_01_w', [dict(garment('l1_047_pwa_shorts__panties7731', PANTIES),
                                                             autoHideDistance=500)]))})
        doc = dressed(drawn('t2_103_wa_jacket__agent6815', JACKET),
                      drawn('h1_007_pwa_specs__aviators2376', GLASSES, app=r'6190507694667453790_1.app',
                            kind='entSkinnedMeshComponent', look='default'),
                      drawn('t2_wa_jacket_shadow', 'shadow.mesh'))
        parts, failed = runtime_npc.drawn_outfit_parts(reader, doc, {})
        self.assertEqual(failed, [])
        self.assertEqual([(p['name']['$value'], p['$type'], p['mesh']['DepotPath']['$value'], p['meshAppearance']['$value'])
                          for p in parts],
                         [('t2_103_wa_jacket__agent6815', 'entGarmentSkinnedMeshComponent', JACKET, 'black'),
                          ('h1_007_pwa_specs__aviators2376', 'entSkinnedMeshComponent', GLASSES, 'default')])
        self.assertEqual(parts[0]['autoHideDistance'], 500)
        self.assertNotEqual(parts[0]['id'], parts[1]['id'])

    def test_drawn_piece_already_resolved_is_not_built_twice(self):
        reader = Reader({UNDERWEAR: app(('basic_01_w', [garment('l1_047_pwa_shorts__panties7731', PANTIES)]))})
        doc = dressed(drawn('t2_103_wa_jacket__agent6815', JACKET))
        selected = {('x',): garment('t2_103_wa_jacket__agent6815', JACKET)}
        self.assertEqual(runtime_npc.drawn_outfit_parts(reader, doc, selected), ([], []))

    def test_a_drawn_piece_removed_in_the_tab_stays_out_and_is_not_missing(self):
        hidden = dict(drawn('t1_082_pwa_tank__casual0270', JACKET), enabled=False)
        doc = dressed(hidden, drawn('l1_081_wa_pants__suit8780', JACKET))
        self.assertEqual([r['name'] for r in runtime_npc.worn_rows(doc)], ['l1_081_wa_pants__suit8780'])
        self.assertEqual(runtime_npc.runtime_missing(doc, {}), ['l1_081_wa_pants__suit8780'])

    def test_build_adds_the_drawn_pieces_before_checking_missing_ones(self):
        source = Path(runtime_npc.__file__).read_text(encoding='utf8')
        self.assertLess(source.index('drawn_outfit_parts(reader, project, collected["selected"])'),
                        source.index('missing_pieces = runtime_missing('))


if __name__ == '__main__':
    unittest.main()
