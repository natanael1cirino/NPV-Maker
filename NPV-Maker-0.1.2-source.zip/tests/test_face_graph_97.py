"""The NPV's world facial graph: base game NPC graph without the ragdoll Switch (BUGS 97, 07/10/2026)."""
import json
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import face_graph

REAL = Path(os.environ.get('NPV_TEST_GRAPHS', 'graphs-not-set'))


def anim(handle, name):
    return {'HandleId': handle, 'Data': {'$type': 'animAnimNode_SkAnim',
                                         'animation': {'$type': 'CName', '$value': name}}}


def ragdoll_switch(handle, first, second):
    weight = {'$type': 'animFloatLink', 'node': {'HandleId': handle + '1', 'Data': {
        '$type': 'animAnimNode_BoolToFloatConverter', 'inputNode': {'$type': 'animBoolLink', 'node': {
            'HandleId': handle + '2', 'Data': {'$type': 'animAnimNode_BoolInput',
                                               'group': {'$type': 'CName', '$value': 'ragdollState'}}}}}}}
    return {'HandleId': handle, 'Data': {'$type': 'animAnimNode_Switch', 'numInputs': 2, 'weightNode': weight,
                                         'inputNodes': [{'$type': 'animPoseLink', 'node': first},
                                                        {'$type': 'animPoseLink', 'node': second}]}}


def graph():
    switch = ragdoll_switch('10', anim('11', 'reactions'), anim('12', 'idle__dead__male'))
    state = {'$type': 'animAnimNode_State', 'node': {'$type': 'animPoseLink', 'node': {
        'HandleId': '2', 'Data': {'$type': 'animAnimNode_Output', 'node': {'$type': 'animPoseLink', 'node': switch}}}},
        'nodes': [{'HandleRefId': '2'}, {'HandleRefId': '10'}, {'HandleRefId': '101'}, {'HandleRefId': '102'},
                  {'HandleRefId': '11'}, {'HandleRefId': '12'}]}
    other = {'HandleId': '20', 'Data': {'$type': 'animAnimNode_Switch', 'numInputs': 2,
                                        'weightNode': {'node': None},
                                        'inputNodes': [{'node': anim('21', 'a')}, {'node': anim('22', 'b')}]}}
    return {'Data': {'RootChunk': {'$type': 'animAnimGraph', 'states': [state], 'other': other,
                                   'nodesToInit': [{'HandleRefId': '10'}, {'HandleRefId': '11'},
                                                   {'HandleRefId': '12'}, {'HandleRefId': '21'}]}}}


def handles(node, out):
    if isinstance(node, dict):
        if 'HandleId' in node:
            out.add(node['HandleId'])
        for v in node.values():
            handles(v, out)
    elif isinstance(node, list):
        for v in node:
            handles(v, out)
    return out


class WithoutRagdollTests(unittest.TestCase):
    def test_switch_replaced_by_its_first_input(self):
        doc, count = face_graph.without_ragdoll_switch(graph())
        self.assertEqual(count, 1)
        state = doc['Data']['RootChunk']['states'][0]
        output = state['node']['node']['Data']
        self.assertEqual(output['node']['node']['HandleId'], '11')
        self.assertNotIn('idle__dead__male', json.dumps(doc))

    def test_references_to_removed_nodes_are_dropped(self):
        doc, _ = face_graph.without_ragdoll_switch(graph())
        root = doc['Data']['RootChunk']
        self.assertEqual([r['HandleRefId'] for r in root['states'][0]['nodes']], ['2', '11'])
        self.assertEqual([r['HandleRefId'] for r in root['nodesToInit']], ['11', '21'])

    def test_other_switches_and_the_input_document_are_untouched(self):
        original = graph()
        doc, _ = face_graph.without_ragdoll_switch(original)
        self.assertEqual(doc['Data']['RootChunk']['other'], original['Data']['RootChunk']['other'])
        self.assertIn('idle__dead__male', json.dumps(original))

    def test_dangling_reference_is_refused(self):
        broken = graph()
        broken['Data']['RootChunk']['extra'] = {'node': {'HandleRefId': '12'}}
        with self.assertRaises(ValueError):
            face_graph.without_ragdoll_switch(broken)


class Reader:
    def __init__(self, doc, mods=()):
        self.doc, self.mods = doc, set(mods)

    def from_mod(self, path):
        return path in self.mods

    def read(self, path):
        return self.doc


class WorldGraphTests(unittest.TestCase):
    def face(self):
        return {'$type': 'entAnimatedComponent', 'graph': {'DepotPath': {'$type': 'ResourcePath', '$storage': 'string',
                '$value': 'base\\animations\\facial\\_facial_graphs\\pma_paperdoll_sermo.animgraph'}, 'Flags': 'Soft'}}

    def test_face_rig_points_to_the_private_graph(self):
        face = self.face()
        path, doc = face_graph.world_face_graph(Reader(graph()), face, 'male', 'npvmaker\\generated\\abc')
        self.assertEqual(path, 'npvmaker\\generated\\abc\\face_npc.animgraph')
        self.assertEqual(face['graph']['DepotPath']['$value'], path)
        self.assertEqual(face['graph']['Flags'], 'Soft')
        self.assertNotIn('idle__dead__male', json.dumps(doc))

    def test_graph_replaced_by_a_mod_keeps_the_editor_graph(self):
        face = self.face()
        mods = [face_graph.NPC_FACE_GRAPHS['male']]
        self.assertIsNone(face_graph.world_face_graph(Reader(graph(), mods), face, 'male', 'npvmaker\\generated\\abc'))
        self.assertIn('pma_paperdoll_sermo', face['graph']['DepotPath']['$value'])

    def test_no_face_rig(self):
        self.assertIsNone(face_graph.world_face_graph(Reader(graph()), None, 'male', 'x'))


@unittest.skipUnless((REAL / 'man_average_sermo.animgraph.json').is_file(), 'graphs of the game not extracted here')
class RealGraphTests(unittest.TestCase):
    def test_both_base_game_npc_graphs(self):
        for name in ('man_average_sermo', 'woman_average_sermo'):
            doc = json.loads((REAL / (name + '.animgraph.json')).read_text(encoding='utf8'))
            new, count = face_graph.without_ragdoll_switch(doc)
            self.assertEqual(count, 2, name)
            self.assertFalse(face_graph.is_ragdoll_switch(new))
            text = json.dumps(new)
            self.assertIn('facial_reactions_', text)
            self.assertIn('FacialReaction', text)
            self.assertNotIn(face_graph.RAGDOLL_INPUT + '"', json.dumps(
                [n for n in new['Data']['RootChunk']['nodesToInit'] if 'Data' in n]))


def mood_graph():
    """Idle state as in man_average_sermo: Switch <- FloatLatch <- FloatRandom 0..3; input 0 a mood, 1-3 neutral."""
    draw = {'HandleId': '50', 'Data': {'$type': 'animAnimNode_FloatRandom', 'min': 0, 'max': 3, 'cooldown': 0}}
    latch = {'HandleId': '51', 'Data': {'$type': 'animAnimNode_FloatLatch', 'input': {'$type': 'animFloatLink', 'node': draw}}}
    inputs = [anim('60', 'idle__anger__male')] + [anim(str(61 + i), 'idle__neutral__male') for i in range(3)]
    switch = {'HandleId': '52', 'Data': {'$type': 'animAnimNode_Switch', 'numInputs': 4,
                                         'weightNode': {'$type': 'animFloatLink', 'node': latch},
                                         'inputNodes': [{'$type': 'animPoseLink', 'node': n} for n in inputs]}}
    other = {'HandleId': '70', 'Data': {'$type': 'animAnimNode_FloatRandom', 'min': 0, 'max': 5, 'cooldown': 1.5}}
    return {'Data': {'RootChunk': {'$type': 'animAnimGraph', 'idle': switch, 'melee': other}}}


class NeutralMoodTests(unittest.TestCase):
    """Author decision 10/10/2026: the NPV rests on the neutral mood (the draw keeps only the neutral inputs)."""

    def test_the_draw_keeps_only_the_neutral_inputs(self):
        doc = mood_graph()
        self.assertEqual(face_graph.neutral_mood(doc), 1)
        draw = doc['Data']['RootChunk']['idle']['Data']['weightNode']['node']['Data']['input']['node']['Data']
        self.assertEqual((draw['min'], draw['max']), (1, 3))

    def test_other_random_nodes_are_untouched(self):
        doc = mood_graph()
        face_graph.neutral_mood(doc)
        self.assertEqual(doc['Data']['RootChunk']['melee']['Data']['max'], 5)

    def test_a_graph_without_the_mood_draw_is_left_alone(self):
        doc = graph()
        before = json.dumps(doc, sort_keys=True)
        self.assertEqual(face_graph.neutral_mood(doc), 0)
        self.assertEqual(json.dumps(doc, sort_keys=True), before)


@unittest.skipUnless((REAL / 'allgraphs').is_dir(), 'graphs of the game not extracted here')
class RealNeutralMoodTests(unittest.TestCase):
    def test_both_base_game_npc_graphs(self):
        folder = REAL / 'allgraphs/base/animations/facial/_facial_graphs'
        for name in ('man_average_sermo', 'woman_average_sermo'):
            doc, _ = face_graph.without_ragdoll_switch(json.loads((folder / (name + '.animgraph.json')).read_text(encoding='utf-8-sig')))
            self.assertEqual(face_graph.neutral_mood(doc), 1, name)
            draws = []
            def walk(n):
                if isinstance(n, dict):
                    if n.get('$type') == 'animAnimNode_FloatRandom':
                        draws.append((n.get('min'), n.get('max')))
                    for v in n.values():
                        walk(v)
                elif isinstance(n, list):
                    for v in n:
                        walk(v)
            walk(doc)
            self.assertEqual(sorted(draws), [(0, 1), (0, 5), (11, 21)], name)


if __name__ == '__main__':
    unittest.main()
