"""Facial graph of the NPV in the world (BUGS 97, 07/10/2026).

MEDIDO EM 07/10/2026 (graphs of the game read with WolvenKit): since package 38 the face rig of the NPV
keeps the character editor graph (pma_paperdoll_sermo / player_woman_paperdoll_sermo). On the author's game that file
comes from the PinkyDude FacialExpressions archives and holds the facial reaction machine; the base game file has no
reaction state, so without PinkyDude the NPV makes no expression when Night City Allies or AMM send FacialReaction.
The NPC graph of the base game (man/woman_average_sermo) holds the same machine and differs from the PinkyDude graph, at
rest, only by a Switch whose weight is ragdollState and whose second input is idle__dead__male/female; package 38
changed only the graph and fixed the face at rest (BUGS 82). The NPV gets its own copy of the base game NPC graph with
every ragdoll Switch replaced by its first input. References to the removed nodes live only in flat lists (the nodes of
each state, nodesToInit) and are dropped from them."""
from __future__ import annotations

import copy
import json

NPC_FACE_GRAPHS = {"male": "base\\animations\\facial\\_facial_graphs\\man_average_sermo.animgraph",
                   "female": "base\\animations\\facial\\_facial_graphs\\woman_average_sermo.animgraph"}
RAGDOLL_INPUT = "ragdollState"


def _data(holder: dict) -> dict:
    return holder["Data"] if isinstance(holder.get("Data"), dict) else holder


def is_ragdoll_switch(holder) -> bool:
    if not isinstance(holder, dict):
        return False
    data = _data(holder)
    return (data.get("$type") == "animAnimNode_Switch" and len(data.get("inputNodes") or []) == 2
            and RAGDOLL_INPUT in json.dumps(data.get("weightNode")))


def _handles(node, out: set) -> set:
    if isinstance(node, dict):
        if "HandleId" in node:
            out.add(str(node["HandleId"]))
        for value in node.values():
            _handles(value, out)
    elif isinstance(node, list):
        for value in node:
            _handles(value, out)
    return out


def _refs(node, out: set) -> set:
    if isinstance(node, dict):
        if "HandleRefId" in node:
            out.add(str(node["HandleRefId"]))
        for value in node.values():
            _refs(value, out)
    elif isinstance(node, list):
        for value in node:
            _refs(value, out)
    return out


def without_ragdoll_switch(doc: dict) -> tuple[dict, int]:
    """A copy of the graph document with every ragdoll Switch replaced by its first input, and how many."""
    doc = copy.deepcopy(doc)
    removed: set = set()
    count = 0

    def bypass(node):
        nonlocal count
        if isinstance(node, dict):
            for key in list(node):
                value = node[key]
                while key == "node" and is_ragdoll_switch(value):
                    first = _data(value)["inputNodes"][0]["node"]
                    removed.update(_handles(value, set()) - _handles(first, set()))
                    node[key] = value = first
                    count += 1
                bypass(value)
        elif isinstance(node, list):
            for value in node:
                bypass(value)

    def drop(node):
        if isinstance(node, dict):
            for value in node.values():
                drop(value)
        elif isinstance(node, list):
            node[:] = [v for v in node if not (isinstance(v, dict) and str(v.get("HandleRefId")) in removed)]
            for value in node:
                drop(value)

    bypass(doc)
    drop(doc)
    dangling = _refs(doc, set()) - _handles(doc, set())
    if dangling:
        raise ValueError("Grafo facial com referencias soltas: " + ", ".join(sorted(dangling)[:5]))
    return doc, count


NEUTRAL_IDLE = "idle__neutral__"


def _skanims(node, table: dict, seen: set) -> list:
    out = []
    node = table.get(str(node["HandleRefId"])) if isinstance(node, dict) and "HandleRefId" in node else node
    if isinstance(node, dict):
        data = _data(node)
        if id(data) in seen:
            return out
        seen.add(id(data))
        if data.get("$type") == "animAnimNode_SkAnim":
            out.append((data.get("animation") or {}).get("$value") or "")
        for value in data.values():
            out += _skanims(value, table, seen)
    elif isinstance(node, list):
        for value in node:
            out += _skanims(value, table, seen)
    return out


def neutral_mood(doc: dict) -> int:
    """Lock the resting mood on neutral; returns how many mood draws were locked.

    BUGS 97, pesquisa de 09/10/2026 (documentacao/script/mapa-piscar-e-expressoes.md): in man/woman_average_sermo the
    Idle state picks the resting mood with a Switch whose weight is a FloatLatch of FloatRandom 0..21; inputs 0-10 are
    moods (anger, bored, tiredness...) and 11-21 are idle__neutral. Every NPC draws one when it appears. The author
    chose neutral for the NPV (the face at rest stays the editor face): the draw is narrowed to the neutral inputs, so
    the idle animation, its blinks and the reactions stay."""
    table: dict = {}

    def index(node):
        if isinstance(node, dict):
            if "HandleId" in node and isinstance(node.get("Data"), dict):
                table[str(node["HandleId"])] = node["Data"]
            for value in node.values():
                index(value)
        elif isinstance(node, list):
            for value in node:
                index(value)

    def resolve(link):
        node = (link or {}).get("node")
        if isinstance(node, dict) and "HandleRefId" in node:
            return table.get(str(node["HandleRefId"]))
        return _data(node) if isinstance(node, dict) else None

    index(doc)
    locked, done = 0, set()
    for data in list(table.values()):
        if data.get("$type") != "animAnimNode_Switch":
            continue
        latch = resolve(data.get("weightNode"))
        if not latch or latch.get("$type") != "animAnimNode_FloatLatch":
            continue
        draw = resolve(latch.get("input"))
        if not draw or draw.get("$type") != "animAnimNode_FloatRandom" or id(draw) in done:
            continue
        inputs = [_skanims(link.get("node"), table, set()) for link in data.get("inputNodes") or []]
        neutral = [i for i, names in enumerate(inputs) if len(names) == 1 and names[0].startswith(NEUTRAL_IDLE)]
        if not neutral or neutral != list(range(neutral[0], neutral[-1] + 1)) or neutral[-1] != len(inputs) - 1:
            continue
        draw["min"], draw["max"] = neutral[0], neutral[-1]
        done.add(id(draw))
        locked += 1
    return locked


def world_face_graph(reader, face: dict | None, body: str, namespace: str) -> tuple[str, dict] | None:
    """(private path, graph document) for the face rig of the NPV in the world; None leaves the editor graph."""
    graph = NPC_FACE_GRAPHS.get(body)
    if face is None or graph is None:
        return None
    if hasattr(reader, "from_mod") and reader.from_mod(graph):
        return None
    doc, count = without_ragdoll_switch(reader.read(graph))
    if count == 0:
        return None
    neutral_mood(doc)
    path = namespace + "\\face_npc.animgraph"
    link = face.get("graph") or {}
    face["graph"] = {"DepotPath": {"$type": "ResourcePath", "$storage": "string", "$value": path},
                     "Flags": link.get("Flags", "Default")}
    return path, doc
