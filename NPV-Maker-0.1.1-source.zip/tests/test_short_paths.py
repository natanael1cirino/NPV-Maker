"""BUGS item 87 (confirmed 07/10/2026 by the player): with the game in a deep folder and the Windows LongPathsEnabled key
off, the cached copy of a game file went over 260 characters and the converter could not see it after WolvenKit
extracted it. The cache stays in the job folder; the converter and WolvenKit reach it through a short junction.
Checked 07/10/2026 with a small program built without longPathAware (as a process on a PC with the key off): the file
at 395 characters failed with error 3 (path not found), the same file through the junction (253 characters) opened."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))

import runtime_resources  # noqa: E402
from runtime_resources import Resources, short_folder  # noqa: E402

DEEP = 'Program Files (x86)/Steam/steamapps/common/Cyberpunk 2077/red4ext/plugins/NPVMaker/data/jobs/' \
       '8b8eb606dc3c26c3-0f517d75/npc/installed-resources'


@unittest.skipUnless(os.name == 'nt', 'NTFS junctions')
class ShortFolderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.env = patch.dict(os.environ, {'NPV_TOOLS_ROOT': str(self.base / 'NPVMaker' / 'tools')})
        self.env.start()
        self.deep = self.base / DEEP
        self.deep.mkdir(parents=True)

    def tearDown(self):
        self.env.stop()
        links = self.base / 'NPVMaker' / 'p'
        if links.is_dir():
            for link in links.iterdir():
                if os.path.isjunction(link):
                    os.rmdir(link)
        self.temp.cleanup()

    def test_a_deep_cache_is_reached_through_a_short_junction(self):
        link = short_folder(self.deep)
        self.assertTrue(os.path.isjunction(link))
        self.assertEqual(link.parent, self.base / 'NPVMaker' / 'p')
        self.assertLess(len(str(link)), len(str(self.deep)) - 20)
        (link / 'base').mkdir()
        (link / 'base' / 'file.mesh').write_bytes(b'mesh')
        self.assertEqual((self.deep / 'base' / 'file.mesh').read_bytes(), b'mesh')
        self.assertEqual(short_folder(self.deep), link)

    def test_removing_the_junction_keeps_the_cache(self):
        link = short_folder(self.deep)
        (self.deep / 'kept.json').write_text('{}')
        os.rmdir(link)
        self.assertTrue((self.deep / 'kept.json').is_file())

    def test_a_junction_to_a_deleted_job_is_pruned(self):
        other = self.base / DEEP.replace('0f517d75', 'deadbeef')
        other.mkdir(parents=True)
        old = short_folder(other)
        other.rmdir()
        short_folder(self.deep)
        self.assertFalse(os.path.lexists(old))

    def test_a_short_folder_is_used_as_it_is(self):
        folder = self.base / 'c'
        folder.mkdir()
        self.assertEqual(short_folder(folder), folder)

    def test_a_missing_folder_or_a_real_folder_in_the_way_is_used_as_it_is(self):
        self.assertEqual(short_folder(self.base / DEEP / 'missing'), self.base / DEEP / 'missing')
        link = short_folder(self.deep)
        os.rmdir(link)
        link.mkdir()
        self.assertEqual(short_folder(self.deep), self.deep)
        link.rmdir()

    def test_the_reader_works_in_the_short_folder(self):
        game = self.base / 'game'
        (game / 'archive/pc/content').mkdir(parents=True)
        reader = Resources(game, game / 'WolvenKit.CLI.exe', self.deep)
        self.assertTrue(os.path.isjunction(reader.cache))
        path = reader.path('base\\characters\\head\\a.mesh')
        self.assertEqual(path.parents[3], reader.cache)


if __name__ == '__main__':
    unittest.main()
