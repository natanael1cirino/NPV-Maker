"""castShadows and castLocalShadows in the old format, inside compiled appearance data (BUGS items 8 and 89).

MEDIDO EM 07/10/2026 (hh_047_pwa__hairs_143.app of WINGDEER hair 47; player reports of l0_000_base__full.app from a body
mod): some mod .app files store castShadows and castLocalShadows of their components as Bool (1 byte), the format of
older game versions. The game loads them; WolvenKit 8.19 and 8.20 refuse the whole file ("Invalid in wolven rtti:
...castShadows [Expected: shadowsShadowCastingMode | Got: Bool]") and write an empty JSON, so the piece was skipped
(item 8) or, for a body file, the whole conversion stopped (item 89). Current files store the enum
shadowsShadowCastingMode as the index of its value's name in the package name pool (vanilla l0_000_base__full.app:
castShadows Never, castLocalShadows Always; the same hair file has 70 fields in the new format and 210 in the old one).
upgrade() rewrites the copy in the job cache with false -> Never and true -> Always, so WolvenKit can read it. The game
files and the mod archives are never touched.

Layout (checked against the file and its stored CRCs): CR2W header of 40 bytes, 10 tables of (offset, count, crc32);
table 5 lists the buffers (flags, index, offset, disk size, memory size, crc32 of the disk bytes), each a "KARK" + memory
size + Kraken stream. The header crc32 covers the header and the tables with the crc field set to 0xDEADBEEF.
A buffer holds a package: version 4 and 7 sections, component count, 6 section offsets relative to the data start (after
the cruid list), name descriptors (offset relative to the data start in 24 bits, length with the terminator in the top
byte), chunk descriptors (type name, offset), and chunks of field count + (name, type, offset in the chunk) + values."""
from __future__ import annotations
import ctypes
import struct
import zlib
from pathlib import Path

OLD_FIELDS = (b"castShadows", b"castLocalShadows")
ENUM = b"shadowsShadowCastingMode"
CR2W_HEADER = "<4sIIQIIIII"


class Kraken:
    """kraken.dll of the WolvenKit download (next to WolvenKit.CLI.exe); NPV Maker ships none."""

    def __init__(self, cli: Path):
        library = ctypes.CDLL(str(Path(cli).with_name("kraken.dll")))
        self.decompress_call = library.Kraken_Decompress
        self.decompress_call.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p, ctypes.c_size_t]
        self.decompress_call.restype = ctypes.c_int
        self.compress_call = library.Kraken_Compress
        self.compress_call.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p, ctypes.c_int]
        self.compress_call.restype = ctypes.c_int

    def decompress(self, data: bytes, size: int) -> bytes:
        out = ctypes.create_string_buffer(size)
        if self.decompress_call(data, len(data), out, size) != size:
            raise ValueError("Kraken: decompressao incompleta")
        return out.raw

    def compress(self, data: bytes) -> bytes:
        out = ctypes.create_string_buffer(len(data) + 274 * ((len(data) + 0x3FFFF) // 0x40000) + 64)
        size = self.compress_call(data, len(data), out, 4)
        if size <= 0:
            raise ValueError("Kraken: compressao falhou")
        packed = out.raw[:size]
        if self.decompress(packed, len(data)) != data:
            raise ValueError("Kraken: compressao nao confere")
        return packed


def upgrade_package(package: bytes) -> tuple[bytes, int]:
    """The package with every old Bool castShadows/castLocalShadows as shadowsShadowCastingMode, and how many."""
    if len(package) < 0x24 or not any(name in package for name in OLD_FIELDS):
        return package, 0
    version, sections, components = struct.unpack_from("<HHI", package, 0)
    if version != 4 or sections != 7:
        return package, 0
    offsets = list(struct.unpack_from("<6I", package, 8))
    _, cruids = struct.unpack_from("<hH", package, 0x20)
    base = 0x24 + 8 * cruids
    _, _, name_desc, name_data, chunk_desc, chunk_data = offsets
    if offsets != sorted(offsets) or base + chunk_data > len(package):
        return package, 0
    names = []
    for i in range((name_data - name_desc) // 4):
        value, = struct.unpack_from("<I", package, base + name_desc + 4 * i)
        start, length = value & 0xFFFFFF, value >> 24
        names.append((start, package[base + start:base + start + length - 1]))
    index = {name: i for i, (_, name) in reversed(list(enumerate(names)))}
    count = (chunk_data - chunk_desc) // 8
    descs = [struct.unpack_from("<II", package, base + chunk_desc + 8 * i) for i in range(count)]
    if [offset for _, offset in descs] != sorted(offset for _, offset in descs) or \
            (descs and descs[0][1] != chunk_data):
        return package, 0
    old_types = {index[b"Bool"]} if b"Bool" in index else set()
    old_names = {index[name] for name in OLD_FIELDS if name in index}
    if not old_types or not old_names:
        return package, 0
    added = []

    def name_index(name: bytes) -> int:
        if name not in index:
            index[name] = len(names) + len(added)
            added.append(name)
        return index[name]

    chunks, changed = [], 0
    for i, (_, offset) in enumerate(descs):
        start = base + offset
        end = base + descs[i + 1][1] if i + 1 < count else len(package)
        chunk = bytearray(package[start:end])
        fields, = struct.unpack_from("<H", chunk, 0)
        for k in range(fields):
            name, kind, at = struct.unpack_from("<HHI", chunk, 2 + 8 * k)
            if name not in old_names or kind not in old_types:
                continue
            value = name_index(b"Always" if chunk[at] else b"Never")
            struct.pack_into("<H", chunk, 2 + 8 * k + 2, name_index(ENUM))
            chunk[at:at + 1] = struct.pack("<H", value)
            for j in range(fields):
                other, = struct.unpack_from("<I", chunk, 2 + 8 * j + 4)
                if other > at:
                    struct.pack_into("<I", chunk, 2 + 8 * j + 4, other + 1)
            changed += 1
        chunks.append(bytes(chunk))
    if not changed:
        return package, 0
    grow = 4 * len(added)
    pool = package[base + name_data:base + chunk_desc]
    new_pool = bytearray(pool)
    new_descs = [struct.pack("<I", (start + grow) | (len(name) + 1) << 24) for start, name in names]
    for name in added:
        if len(name) + 1 > 255:
            return package, 0
        new_descs.append(struct.pack("<I", (name_data + grow + len(new_pool)) | (len(name) + 1) << 24))
        new_pool += name + b"\0"
    new_chunk_desc = name_data + grow + len(new_pool)
    new_chunk_data = new_chunk_desc + 8 * count
    table, position = [], new_chunk_data
    for (kind, _), chunk in zip(descs, chunks):
        table.append(struct.pack("<II", kind, position))
        position += len(chunk)
    head = bytearray(package[:base + name_desc])
    struct.pack_into("<6I", head, 8, offsets[0], offsets[1], name_desc, name_data + grow, new_chunk_desc,
                     new_chunk_data)
    return bytes(head) + b"".join(new_descs) + bytes(new_pool) + b"".join(table) + b"".join(chunks), changed


def upgrade(path: Path, cli: Path) -> int:
    """Rewrite the cached file at `path` when it has old castShadows fields; returns how many were changed (0 leaves
    the file as it was)."""
    path = Path(path)
    data = path.read_bytes()
    if len(data) < 160 or data[:4] != b"CR2W" or not any(name in data for name in OLD_FIELDS + (b"KARK",)):
        return 0
    header = list(struct.unpack_from(CR2W_HEADER, data, 0))
    objects_end, buffers_end = header[5], header[6]
    table_offset, table_count, _ = struct.unpack_from("<III", data, 40 + 12 * 5)
    entries = [list(struct.unpack_from("<IIIIII", data, table_offset + 24 * i)) for i in range(table_count)]
    position = objects_end
    for entry in entries:
        if entry[2] != position:
            return 0
        position += entry[3]
    if position != buffers_end or buffers_end > len(data):
        return 0
    kraken, changed, blobs = None, 0, []
    for entry in entries:
        raw = data[entry[2]:entry[2] + entry[3]]
        packed = raw[:4] == b"KARK"
        if packed:
            if kraken is None:
                kraken = Kraken(cli)
            package = kraken.decompress(raw[8:], struct.unpack_from("<I", raw, 4)[0])
        else:
            package = raw
        new, count = upgrade_package(package)
        if count:
            raw = b"KARK" + struct.pack("<I", len(new)) + kraken.compress(new) if packed else new
            entry[4] = len(new)
            entry[5] = zlib.crc32(raw)
            changed += count
        blobs.append(raw)
    if not changed:
        return 0
    out = bytearray(data[:objects_end])
    position = objects_end
    for i, (entry, raw) in enumerate(zip(entries, blobs)):
        entry[2], entry[3] = position, len(raw)
        position += len(raw)
        struct.pack_into("<IIIIII", out, table_offset + 24 * i, *entry)
    struct.pack_into("<I", out, 40 + 12 * 5 + 8, zlib.crc32(bytes(out[table_offset:table_offset + 24 * table_count])))
    header[6] = position
    header[7] = 0xDEADBEEF
    struct.pack_into(CR2W_HEADER, out, 0, *header)
    struct.pack_into("<I", out, 32, zlib.crc32(bytes(out[:160])))
    temporary = path.with_name(path.name + ".upgrade")
    temporary.write_bytes(bytes(out) + b"".join(blobs) + data[buffers_end:])
    temporary.replace(path)
    return changed
