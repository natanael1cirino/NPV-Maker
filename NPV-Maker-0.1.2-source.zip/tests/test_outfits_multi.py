"""Several outfits per NPV (author request 08/10/2026): one appearance each, registered in NCA and AMM."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import adapters
import runtime_npc
from test_outfit_wardrobe import Reader, app, garment, drawn, JACKET, GLASSES, PANTIES, UNDERWEAR, cname

BODY = r'base\characters\common\player_base_bodies\player_female_average\t0_000_pwa_base__full.mesh'


def body_row(mask):
    return dict(drawn('t0_000_pwa_base__full', BODY, app=r'base\characters\common\t0_000_base__full.app'),
                type='entSkinnedMeshComponent', chunk_mask=str(mask))


class ExtraOutfitTests(unittest.TestCase):
    def test_saved_outfits_are_checked(self):
        project = {'outfits': [{'id': 'outfit_1', 'name': ' Praia ', 'pieces': [], 'drawn': []},
                               {'id': 'outfit_1', 'name': 'repetido'}, {'id': 'default'}, {'id': '../x'}, 'junk',
                               {'id': 'outfit_2'}]}
        result = runtime_npc.extra_outfits(project)
        self.assertEqual([(o['id'], o['name']) for o in result], [('outfit_1', 'Praia'), ('outfit_2', 'outfit_2')])
        self.assertEqual(runtime_npc.extra_outfits({}), [])

    def test_variant_takes_the_drawn_pieces_and_body_masks_of_its_snapshot(self):
        reader = Reader({UNDERWEAR: app(('basic_01_w', [garment('l1_047_pwa_shorts__panties7731', PANTIES)]))})
        outfit = {'id': 'outfit_1', 'name': 'Agente', 'pieces': [],
                  'drawn': [drawn('t2_103_wa_jacket__agent6815', JACKET), body_row(31)]}
        parts, masks, notes = runtime_npc.outfit_variant(reader, {'name': 'x', 'body': 'female'}, outfit, {})
        self.assertEqual([p['name']['$value'] for p in parts], ['t2_103_wa_jacket__agent6815'])
        self.assertEqual(masks, {'t0_000_pwa_base__full': '31'})

    def test_extra_appearance_drops_nothing_of_the_base_and_uses_its_own_masks(self):
        base = [dict(garment('t0_000_pwa_base__full', BODY), chunkMask='255', autoHideDistance=200),
                dict(garment('l1_047_pwa_shorts__panties7731', PANTIES), autoHideDistance=500)]
        jacket = dict(garment('t2_103_wa_jacket__agent6815', JACKET), autoHideDistance=0,
                      renderingPlaneAnimationParam=cname('renderPlane'))
        result = runtime_npc.outfit_appearance_components(base, [jacket], {'t0_000_pwa_base__full': '31'})
        self.assertEqual([p['name']['$value'] for p in result],
                         ['t0_000_pwa_base__full', 'l1_047_pwa_shorts__panties7731', 't2_103_wa_jacket__agent6815'])
        self.assertEqual(result[0]['chunkMask'], '31')
        self.assertEqual(base[0]['chunkMask'], '255')
        self.assertEqual(result[2]['autoHideDistance'], 500)
        self.assertEqual(result[2]['renderingPlaneAnimationParam']['$value'], 'None')

    def test_definition_has_its_name_and_component_directory(self):
        parts = [garment('a', JACKET), garment('b', GLASSES)]
        definition = runtime_npc.appearance_definition('outfit_3', parts)
        self.assertEqual(definition['name']['$value'], 'outfit_3')
        directory = definition['compiledData']['Data']['CruidDict']
        self.assertEqual((directory['0'], directory['1']), ('a', 'b'))
        # BUGS 97 (10/10/2026): every appearance carries the VisualController of its own meshes.
        last = definition['components'][-1]
        self.assertEqual(last['$type'], 'entVisualControllerComponent')
        self.assertEqual(len(directory), 3)
        self.assertEqual([d['componentName']['$value'] for d in last['appearanceDependency']], ['a', 'b'])

    def test_build_writes_one_entity_appearance_per_outfit(self):
        source = Path(runtime_npc.__file__).read_text(encoding='utf8')
        self.assertIn('for name in appearance_names_out]', source)
        self.assertIn('"appearances": appearance_names_out', source)
        self.assertIn('"outfit_components": outfit_components', source)


class AdapterOutfitTests(unittest.TestCase):
    TOKEN, RECORD = '0123456789abcdef', 'Character.NPVMaker_0123456789abcdef'

    def test_nca_registers_every_outfit_in_the_casual_list(self):
        text = adapters.nca_module(self.TOKEN, self.RECORD, 'Thai', 'default', appearances=['default', 'outfit_1', 'outfit_2'])
        self.assertIn('.Outfit(n"casual", [n"default", n"outfit_1", n"outfit_2"]);', text)

    def test_nca_with_one_appearance_is_unchanged(self):
        self.assertIn('.Outfit(n"casual", n"default");', adapters.nca_module(self.TOKEN, self.RECORD, 'Thai', 'default'))
        self.assertIn('.Outfit(n"casual", n"default");',
                      adapters.nca_module(self.TOKEN, self.RECORD, 'Thai', 'default', appearances=['default', 'x"; bad']))

    def test_amm_lists_every_appearance(self):
        text = adapters.amm_entity('npv_thai_01234567', self.RECORD, 'Thai', '', r'npvmaker\generated\x\character.ent',
                                   'default', ['default', 'outfit_1'])
        self.assertIn('    "default",\n    "outfit_1",\n', text)

    def test_requirements_read_the_outfit_pieces(self):
        for name in ('npv_package.py', 'material_chain.py'):
            text = (Path(runtime_npc.__file__).parent / name).read_text(encoding='utf8')
            self.assertIn('manifest.get("outfit_components")', text)


if __name__ == '__main__':
    unittest.main()
