# NPV Maker 0.2.0

Turn a character you design in Cyberpunk 2077's character creator into an NPC ("NPV") that lives in the world, and
export it as a mod ZIP that other players can install.

Version 0.2.0 adds the WARDROBE tab (dress your character in the editor and save outfits as NPV appearances), NPVs that
blink and change expression in the open world, CREATE NPV with More Body Meshes, male poses in photo mode, sharper
lashes and fixes to export and reports (internal build 0.5.0).

## Requirements (tested with)

- Cyberpunk 2077 2.31
- RED4ext 1.30.0
- redscript
- Codeware 1.20.5
- TweakXL 1.11.4
- ArchiveXL 1.27.3
- RedFileSystem 0.15.1

Cyber Engine Tweaks is not used by NPV Maker.

### WolvenKit (downloaded on first use, not included)

NPV Maker converts characters with WolvenKit Console 8.19.0, which needs .NET 8. Neither is included in this ZIP (at
the request of the WolvenKit team). On first use, open NPV MAKER > TOOLS > WOLVENKIT and let NPV Maker download the
official release from the WolvenKit GitHub (fixed version, checked by SHA256). It is installed under
`%LOCALAPPDATA%\NPVMaker\tools`, outside the game folder. You can also point to a WolvenKit Console 8.19.0 you already
have, or install the official ZIP manually from the same screen.

### Optional

- PhotoMode-EX: needed for the PHOTO MODE option (without it the NPV does not show in photo mode).
- Night City Allies, AppearanceMenuMod (AMM), Companion Expansion: used only when you tick them on export.
- Appearance Change Unlocker (ACU): its preset list keeps working inside the NPV Maker editor.
- EquipmentEx: when installed, the WARDROBE tab also uses its extra outfit slots.

## How to use

1. Main menu > **NPV maker**. This opens the game's character creator in an isolated session: it never starts a new
   game and never touches your saves.
2. Design the character (or load a preset / a saved NPV Maker project).
3. Optional: **WARDROBE**. Pick clothes from the game and from your clothing mods; the character wears them in the
   editor. What is worn when you create the NPV is its default look; **+ SAVE WHAT IS WORN AS AN OUTFIT** keeps more
   looks (up to 9), each one an extra appearance of the NPV (switch them in Night City Allies and AMM). In
   **OUTFITS**, **NAME** renames a saved outfit.
4. **CREATE NPV**. Conversion runs in the background and usually takes a few minutes (3 to 5 in our tests; characters with many modded parts can take longer).
   The screen stays on the conversion while it runs. Do not close the game until it finishes.
5. Restart the game. The NPV is now available (Night City Allies phone menu, AMM, photo mode, depending on what you
   ticked).
6. **MANAGE > NPVs > EXPORT** on the NPV, fill in the form and **EXPORT MOD**: this builds a ZIP of your NPV that can
   be installed with Vortex.

## Things to know

- An NPV made with pieces from other mods (hair, eyes, makeup, body, clothes...) does not copy those mods' files. It
  points to them. Whoever installs your exported NPV needs the same mods; the export lists them as requirements. If
  one is missing, that piece is missing on the NPV.
- The NPV wears what is worn in WARDROBE. There is no automatic underwear any more: with nothing worn, the NPV has no
  clothes. NPVs created before 0.2.0 keep the outfit they had.
- NPVs created before 0.2.0 do not blink or change expression in the open world. Remove them and create them again.
- Restart the game after creating or removing an NPV.
- Mods that change the eyes or head of the player change the NPV the same way (for example, 3D eye mods).
- Mod files that store `castShadows` in an old format are converted in NPV Maker's working copy (the mod itself
  is not changed). A file WolvenKit 8.19 still cannot read is left out with a message in the report.
- NPV Maker reaches its working folder through a short link in `%LOCALAPPDATA%\NPVMaker\p`, so a game
  installed in a deep folder stays under the Windows path limit. The files stay in the game folder.
- The NPV gets its own copy of the face and head shape files it would share with your V. ArchiveXL builds it in
  game from the files you have installed; nothing is copied into the NPV.
- With a very large clothing collection (many thousands of modded items) the WARDROBE tab can be slow, and a crash was
  reported with about 17,000 items. A lighter catalog is planned.
- Interface languages: English, Portuguese and Spanish (follows the game language).

## Credits

- WolvenKit team: WolvenKit Console, used to convert files (downloaded from the official release, not redistributed).
- The authors of RED4ext, redscript, Codeware, TweakXL, ArchiveXL and RedFileSystem.
- RED4ext SDK (MIT), Python and PyInstaller: licenses in `red4ext/plugins/NPVMaker/third-party`.

The NPV Maker source code is provided alongside this release (`NPV-Maker-0.2.0-source.zip`).

---

# NPV Maker 0.2.0 (Portugues)

Transforma o personagem que voce cria no editor de personagem do Cyberpunk 2077 em um NPC ("NPV") no mundo, e exporta
esse NPV como um ZIP de mod que outros jogadores podem instalar.

Novidades da 0.2.0: aba ROUPAS (vista o personagem no editor e salve outfits como aparencias do NPV), NPV que pisca e
faz expressao no mundo, CRIAR NPV com o More Body Meshes, poses masculinas no modo foto, cilios mais nitidos e
correcoes no export e nos relatorios.

Requisitos (testado com): Cyberpunk 2077 2.31, RED4ext 1.30.0, redscript, Codeware 1.20.5, TweakXL 1.11.4,
ArchiveXL 1.27.3, RedFileSystem 0.15.1. Nao usa o Cyber Engine Tweaks.

WolvenKit: o NPV Maker usa o WolvenKit Console 8.19.0 (com .NET 8), que NAO vem no ZIP. No primeiro uso, va em
NPV MAKER > TOOLS > WOLVENKIT e deixe o NPV Maker baixar a versao oficial do GitHub do WolvenKit (versao fixa,
conferida por SHA256). Fica em `%LOCALAPPDATA%\NPVMaker\tools`, fora da pasta do jogo.

Opcionais: PhotoMode-EX (para o MODO FOTO), Night City Allies, AMM e Companion Expansion (so quando marcados no
export), ACU (a lista de presets continua funcionando no editor), EquipmentEx (a aba ROUPAS usa os slots extras dele).

Como usar: menu do jogo > **NPV maker** > crie o personagem > (opcional) **ROUPAS**: vista roupas do jogo e dos seus
mods; o que estiver vestido vira a aparencia padrao do NPV e **+ SALVAR O QUE ESTA VESTIDO COMO OUTFIT** guarda outras
(ate 9), cada uma uma aparencia do NPV no NCA e no AMM; **NOME** renomeia um outfit > **CRIAR NPV** (alguns minutos,
de 3 a 5 nos nossos testes; nao feche o jogo) > reinicie o jogo > chame o NPV. **GERENCIAR > NPVs > EXPORTAR** no NPV
e depois **EXPORTAR MOD** gera o ZIP para o Vortex.

Bom saber: pecas de outros mods (inclusive roupas) nao sao copiadas, o NPV aponta para elas (quem baixar precisa dos
mesmos mods); o NPV veste o que estiver em ROUPAS e nao ganha mais roupa intima automatica (sem nada vestido, sai sem
roupa; NPVs antigos continuam como estavam); NPVs criados antes da 0.2.0 nao piscam nem fazem expressao no mundo:
remova e crie de novo; reinicie o jogo depois de criar ou remover um NPV; mods de olho ou cabeca do V mudam o NPV do
mesmo jeito; com uma colecao enorme de roupas de mod (milhares de itens) a aba ROUPAS pode ficar lenta, e houve relato
de travamento com cerca de 17 mil itens (catalogo mais leve planejado).
A pasta de trabalho e acessada por um atalho curto em `%LOCALAPPDATA%\NPVMaker\p` (limite de caminho do
Windows); os arquivos continuam na pasta do jogo.
O NPV ganha a propria copia dos arquivos de forma do rosto que dividiria com o seu V (o ArchiveXL monta no jogo a
partir dos arquivos instalados; nada e copiado para o NPV).
