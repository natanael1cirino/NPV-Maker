"""BUGS item 100 (09/10/2026): the conversion stopped at "converting N file(s) for reading" with More Body Meshes.

Its t0_000_base__full.app and t0_000_fpp__full.app (2022) keep castShadows as Bool, so legacy_shadows rewrites them; the
Kraken decoder was given an output buffer of exactly the unpacked size, wrote past it and the heap check killed the
converter (0xc0000374, 6 of 6 runs on the real files; 6 of 6 pass with the spare bytes). The older tests use
uncompressed buffers and never reached the decoder."""
import ctypes
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))

import legacy_shadows  # noqa: E402


class FakeDecoder:
    """Writes the unpacked bytes and then scratch bytes past them, as the real decoder does, inside the buffer only."""

    def __init__(self, payload):
        self.payload = payload
        self.buffer_sizes = []

    def __call__(self, data, length, out, size):
        room = ctypes.sizeof(out)
        self.buffer_sizes.append(room)
        ctypes.memmove(out, self.payload, size)
        spare = min(64, room - size)
        if spare > 0:
            ctypes.memmove(ctypes.addressof(out) + size, b'\xAA' * spare, spare)
        return size


def kraken_with(decoder):
    kraken = legacy_shadows.Kraken.__new__(legacy_shadows.Kraken)
    kraken.decompress_call = decoder
    return kraken


class SafeSpaceTests(unittest.TestCase):
    def test_the_decoder_gets_spare_bytes_after_the_output(self):
        payload = bytes(range(256)) * 4
        decoder = FakeDecoder(payload)
        kraken_with(decoder).decompress(b'packed', len(payload))
        self.assertGreaterEqual(decoder.buffer_sizes[0], len(payload) + 64)

    def test_the_result_is_only_the_unpacked_bytes(self):
        payload = b'castShadows' * 50
        result = kraken_with(FakeDecoder(payload)).decompress(b'packed', len(payload))
        self.assertEqual(result, payload)

    def test_a_short_decode_is_still_refused(self):
        kraken = kraken_with(lambda data, length, out, size: size - 1)
        with self.assertRaises(ValueError):
            kraken.decompress(b'packed', 100)


def wolvenkit_cli():
    found = os.environ.get('NPV_TEST_WOLVENKIT_CLI')
    if found and Path(found).with_name('kraken.dll').is_file():
        return Path(found)
    return None


@unittest.skipUnless(wolvenkit_cli(), 'NPV_TEST_WOLVENKIT_CLI with kraken.dll next to it not set')
class RealDecoderTests(unittest.TestCase):
    def test_round_trip_with_the_wolvenkit_kraken(self):
        kraken = legacy_shadows.Kraken(wolvenkit_cli())
        data = b''.join(i.to_bytes(4, 'little') * 3 for i in range(20000))
        self.assertEqual(kraken.decompress(kraken.compress(data), len(data)), data)


if __name__ == '__main__':
    unittest.main()
