// Wardrobe+ refit and coverage adapted to the isolated CC player preview.
public class NPVWardrobeBodyMesh extends IScriptable {
  public let mesh: wref<entSkinnedMeshComponent>;
  public let original: Uint64;
  public let enabled: Bool;
  public let kind: Int32;
}

public class NPVWardrobeFit extends IScriptable {
  private let puppet: wref<gamePuppet>;
  private let meshes: array<ref<NPVWardrobeBodyMesh>>;
  public let body: String;
  public let hookReady: Bool;
  public let hiddenParts: Uint64;
  public let revision: Int32;

  public static func Create(p: ref<gamePuppet>) -> ref<NPVWardrobeFit> {
    let fit = new NPVWardrobeFit(); fit.puppet = p;
    // Capture BEFORE any trial item exists. Never operate on garment components
    // added later, even if the garment has 'body' in its component name.
    for c in p.GetComponents() {
      let sk = c as entSkinnedMeshComponent;
      if IsDefined(sk) && !ResourceAsyncRef.IsEmpty(sk.mesh) {
        let name = StrLower(NameToString(sk.GetName()));
        let kind = 0;
        if StrBeginsWith(name, "t0") || Equals(name, "body") || StrBeginsWith(name, "body_") { kind = 1; };
        if StrBeginsWith(name, "a0") || StrBeginsWith(name, "an0") { kind = 2; };
        if StrBeginsWith(name, "l0") { kind = 3; };
        if StrBeginsWith(name, "s0") { kind = 4; };
        if StrBeginsWith(name, "n0") { kind = 5; };
        if kind > 0 {
          let state = new NPVWardrobeBodyMesh(); state.mesh = sk;
          state.original = sk.chunkMask; state.enabled = sk.IsEnabled(); state.kind = kind;
          ArrayPush(fit.meshes, state);
        };
      };
    };
    return fit;
  }

  private func AutoBody() -> String {
    let resolved = this.GameBody();
    if StrLen(resolved) > 0 && NotEquals(StrLower(resolved), "basebody") && NotEquals(resolved, "base_body") { return resolved; };
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    // Authored Body:<type> metadata takes precedence over naming heuristics.
    for tag in ts.GetVisualTags(this.puppet) {
      let name = NameToString(tag);
      if StrBeginsWith(name, "Body:") { return StrAfterFirst(name, "Body:"); };
    };
    let known: array<String> = ["ebbprb", "ebbrb", "ebbp", "ebb", "rb", "angel", "lush", "vhd", "elegy", "atlas", "adonis"];
    for state in this.meshes {
      if IsDefined(state.mesh) && state.enabled {
        let text = StrLower(NameToString(state.mesh.GetName())) + "_" + StrLower(ResRef.ToString(ResourceAsyncRef.GetPath(state.mesh.mesh)));
        for token in StrSplit(text, "_") { if ArrayContains(known, token) { return token; }; };
      };
    };
    // Empty means preserve the game's own BodyType resolver, not force vanilla.
    return "";
  }
  @if(ModuleExists("ArchiveXL.DynamicAppearance"))
  private func GameBody() -> String { return NameToString(ArchiveXL.GetBodyType(this.puppet)); }
  @if(!ModuleExists("ArchiveXL.DynamicAppearance"))
  private func GameBody() -> String { return ""; }

  public func Select(requested: String) -> Bool {
    let value = StrLower(requested);
    if Equals(value, "auto") || StrLen(value) == 0 { value = this.AutoBody(); };
    if Equals(value, "base_body") || Equals(value, "basebody") { value = "BaseBody"; };
    if Equals(value, this.body) { return false; };
    this.hookReady = NPVMakerWardrobeSetBody(this.puppet, value);
    if !this.hookReady { return false; };
    this.body = value;
    this.revision += 1;
    return true;
  }

  private func TagsBits(tags: array<CName>) -> Uint64 {
    let bits = 0ul;
    for tag in tags {
      switch tag {
        case n"hide_CollarBone": bits = bits | 2ul; break;
        case n"hide_Chest": bits = bits | 4ul; break;
        case n"hide_UpperAbdomen": bits = bits | 8ul; break;
        case n"hide_LowerAbdomen": bits = bits | 16ul; break;
        case n"hide_Torso": bits = bits | 30ul; break;
        case n"hide_Thighs": bits = bits | 32ul; break;
        case n"hide_Calves": bits = bits | 64ul; break;
        case n"hide_Ankles": bits = bits | 128ul; break;
        case n"hide_Feet": bits = bits | 256ul; break;
        case n"hide_Legs": bits = bits | 480ul; break;
        case n"hide_Arms": bits = bits | 3584ul; break;
      };
    };
    return bits;
  }

  @if(ModuleExists("NCAWardrobe.GuardAlturas"))
  private func MeasuredMask(mesh: ref<entSkinnedMeshComponent>, parts: Uint64) -> Uint64 {
    return NCAWGuardChunksPorPartes(ResourceAsyncRef.GetPath(mesh.mesh), parts);
  }
  @if(!ModuleExists("NCAWardrobe.GuardAlturas"))
  private func MeasuredMask(mesh: ref<entSkinnedMeshComponent>, parts: Uint64) -> Uint64 { return 0ul; }
  @if(ModuleExists("NCAWardrobe.GuardAlturas"))
  private func MeasuredAvailable(mesh: ref<entSkinnedMeshComponent>) -> Bool {
    return NCAWGuardMedirMalha(ResourceAsyncRef.GetPath(mesh.mesh)) >= 0;
  }
  @if(!ModuleExists("NCAWardrobe.GuardAlturas"))
  private func MeasuredAvailable(mesh: ref<entSkinnedMeshComponent>) -> Bool { return false; }

  private func PlayerTorso(mesh: ref<entSkinnedMeshComponent>) -> Bool {
    let token = GameInstance.GetResourceDepot().LoadResource(ResourceAsyncRef.GetPath(mesh.mesh));
    if !IsDefined(token) || !token.IsLoaded() { return false; };
    let resource = token.GetResource() as CMesh;
    let blob = IsDefined(resource) ? resource.renderResourceBlob as rendRenderMeshBlob : null;
    if !IsDefined(blob) { return false; };
    let counts: array<Int32>;
    for chunk in blob.header.renderChunkInfos {
      if Cast<Int32>(chunk.lodMask) % 2 == 1 { ArrayPush(counts, Cast<Int32>(chunk.numVertices)); };
    };
    let expected: array<Int32> = [1011, 257, 367, 514, 988, 260, 396];
    if ArraySize(counts) != 8 { return false; };
    let i = 0;
    while i < 7 { if counts[i] != expected[i] { return false; }; i += 1; };
    return true;
  }

  private func Mask(state: ref<NPVWardrobeBodyMesh>, parts: Uint64) -> Uint64 {
    let mesh = state.mesh;
    if parts == 0ul { return 0ul; };
    if this.MeasuredAvailable(mesh) { return this.MeasuredMask(mesh, parts); };
    let name = StrLower(NameToString(mesh.GetName()));
    let path = StrLower(ResRef.ToString(ResourceAsyncRef.GetPath(mesh.mesh)));
    // The measured Wardrobe+ V chunk layout is only a fallback for positively
    // recognized player base meshes. Other layouts use measured geometry.
    let player = StrContains(name, "_pwa_base") || StrContains(name, "_pma_base")
      || StrContains(path, "player_base_bodies");
    if !player || (state.kind == 1 && !this.PlayerTorso(mesh)) { return 0ul; };
    let mask = 0ul;
    if state.kind == 1 {
      if (parts & 4ul) != 0ul { mask = mask | 1ul; };
      if (parts & 2ul) != 0ul { mask = mask | 2ul; };
      if (parts & 8ul) != 0ul { mask = mask | 4ul; };
      if (parts & 16ul) != 0ul { mask = mask | 8ul; };
      if (parts & 32ul) != 0ul { mask = mask | 16ul; };
      if (parts & 64ul) != 0ul { mask = mask | 32ul; };
      if (parts & 128ul) != 0ul { mask = mask | 64ul; };
      if (parts & 256ul) != 0ul { mask = mask | 128ul; };
    } else if state.kind == 2 {
      if (parts & 512ul) != 0ul { mask = mask | 1ul; };
      if (parts & 1024ul) != 0ul { mask = mask | 2ul | 8ul; };
      if (parts & 2048ul) != 0ul { mask = mask | 4ul; };
    } else { return this.MeasuredMask(mesh, parts); };
    return mask;
  }

  private func SetMask(state: ref<NPVWardrobeBodyMesh>, value: Uint64) -> Void {
    if !IsDefined(state.mesh) || state.mesh.chunkMask == value { return; };
    state.mesh.chunkMask = value; state.mesh.Toggle(false);
    state.mesh.TemporaryHide(false); state.mesh.Toggle(state.enabled);
  }

  public func Apply(slots: array<TweakDBID>) -> Void {
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let parts = 0ul;
    for slot in slots {
      let obj = ts.GetItemInSlot(this.puppet, slot);
      if IsDefined(obj) {
        parts = parts | this.TagsBits(ts.GetVisualTags(obj));
        parts = parts | this.TagsBits(ts.GetVisualTagsByItemID(obj.GetItemID(), this.puppet));
      };
    };
    this.hiddenParts = parts;
    for state in this.meshes {
      if IsDefined(state.mesh) {
        this.SetMask(state, state.original & ~this.Mask(state, parts));
      };
    };
    NPVFiles.Write("wardrobe-w06-refit.tsv", "body\t" + this.body + "\nhook_ready\t" + ToString(this.hookReady) + "\ncoverage_parts\t" + ToString(parts) + "\ntracked_body_meshes\t" + ToString(ArraySize(this.meshes)) + "\nvisual_runtime\tunverified\nend\t1\n");
  }
  public func Close() -> Void {
    for state in this.meshes { this.SetMask(state, state.original); };
    // Keep the result: a discarded native result reaches the plugin as a null slot (crash 08/10/2026).
    let cleared = NPVMakerWardrobeSetBody(this.puppet, "");
    if !cleared { ModLog(n"NPVMaker", "W09 refit registration was not cleared"); };
  }
}
