// Adapted from the production Wardrobe+ BodyType suffix mechanism, read-only
// to game records. Only a preview explicitly registered by our session can
// receive an override. Every other suffix/entity retains the original answer.
#include <RED4ext/RED4ext.hpp>
#include <RED4ext/Scripting/Natives/entEntity.hpp>
#include <RED4ext/Scripting/Utils.hpp>
#include <mutex>
#include <string>
#include <filesystem>
#include <Windows.h>
#include "BodyPolicy.hpp"
#include "RecordOrigin.hpp"
#include <fstream>

namespace {
const RED4ext::v1::Sdk* sdk = nullptr;
RED4ext::v1::PluginHandle plugin = nullptr;
using Suffix = bool (*)(const void*, uint64_t, RED4ext::Handle<RED4ext::ent::Entity>&,
    RED4ext::TweakDBID, RED4ext::CString&);
Suffix original = nullptr;
void* suffixAddress = nullptr;
std::mutex lock;
const RED4ext::ent::Entity* registered = nullptr;
uint64_t registeredId = 0;
std::string body;
bool active = false;
bool reported = false;
std::unordered_set<uint64_t> baseRecords;
bool originReady = false;

void LoadOrigins() {
    wchar_t path[32768]{};
    if (!GetModuleFileNameW(nullptr, path, 32768)) return;
    const auto cache = std::filesystem::path(path).parent_path().parent_path().parent_path() / L"r6" / L"cache";
    std::ifstream base(cache / L"tweakdb.bin", std::ios::binary);
    originReady = npvorigin::Read(base, baseRecords);
    const auto dlcPath = cache / L"tweakdb_ep1.bin";
    std::error_code error;
    if (originReady && std::filesystem::exists(dlcPath, error)) {
        std::ifstream dlc(dlcPath, std::ios::binary);
        originReady = npvorigin::Read(dlc, baseRecords);
    }
    sdk->logger->InfoF(plugin, "Wardrobe origin index: ready=%d records=%zu", originReady, baseRecords.size());
}
void Origin(RED4ext::IScriptable*, RED4ext::CStackFrame* frame, int32_t* out, int64_t) {
    RED4ext::TweakDBID id;
    RED4ext::GetParameter(frame, &id); frame->code++;
    // A script call that discards the result passes no output slot (MEDIDO 08/10/2026).
    if (out) *out = npvorigin::Classify(id.value, originReady, baseRecords);
}

bool Override(const void* item, uint64_t context, RED4ext::Handle<RED4ext::ent::Entity>& owner,
    RED4ext::TweakDBID suffix, RED4ext::CString& answer) {
    const bool ok = original(item, context, owner, suffix, answer);
    static const RED4ext::TweakDBID bodySuffix("itemsFactoryAppearanceSuffix.BodyType");
    std::lock_guard<std::mutex> guard(lock);
    if (!npvfit::MayOverride(context, suffix.value == bodySuffix.value, registered, registeredId,
        owner.GetPtr(), owner.GetPtr() ? owner->entityID.hash : 0, !body.empty())) return ok;
    if (!reported) {
        sdk->logger->InfoF(plugin, "NPV preview BodyType: '%s' -> '%s'", ok ? answer.c_str() : "(none)", body.c_str());
        reported = true;
    }
    answer = RED4ext::CString(body.c_str());
    return true;
}

void SetBody(RED4ext::IScriptable*, RED4ext::CStackFrame* frame, bool* out, int64_t) {
    RED4ext::Handle<RED4ext::ent::Entity> owner;
    RED4ext::CString value;
    RED4ext::GetParameter(frame, &owner);
    RED4ext::GetParameter(frame, &value);
    frame->code++;
    // MEDIDO 08/10/2026: NPVWardrobeFit.Close() discards the result, so `out` is null. Writing it crashed the game
    // at NPVMakerWardrobe.dll+0x8DDA (five dumps, 07/10 and 08/10). Every write goes through `result`.
    bool ignored = false;
    bool* result = out ? out : &ignored;
    *result = false;
    if (!owner.GetPtr()) return;
    const std::string requested = value.c_str();
    if (!npvfit::ValidBody(requested)) return;
    std::lock_guard<std::mutex> guard(lock);
    if (requested.empty()) {
        if (registered == owner.GetPtr() && registeredId == owner->entityID.hash) {
            registered = nullptr; registeredId = 0; body.clear();
        }
        *result = true;
        return;
    }
    if (!active || !owner->entityID.hash) return;
    if (registered != owner.GetPtr() || registeredId != owner->entityID.hash || body != requested) reported = false;
    registered = owner.GetPtr(); registeredId = owner->entityID.hash; body = requested;
    *result = true;
}
void Register() {
    auto* rtti = RED4ext::CRTTISystem::Get();
    auto* fn = RED4ext::CGlobalFunction::Create("NPVMakerWardrobeSetBody", "NPVMakerWardrobeSetBody", &SetBody);
    fn->flags.isNative = true;
    fn->flags.isStatic = true;
    fn->AddParam("handle:entEntity", "preview");
    fn->AddParam("String", "body");
    fn->SetReturnType("Bool");
    rtti->RegisterFunction(fn);
    auto* originFn = RED4ext::CGlobalFunction::Create("NPVMakerWardrobeOrigin", "NPVMakerWardrobeOrigin", &Origin);
    originFn->flags.isNative = true; originFn->flags.isStatic = true;
    originFn->AddParam("TweakDBID", "item"); originFn->SetReturnType("Int32");
    rtti->RegisterFunction(originFn);
}
}
extern "C" __declspec(dllexport) bool __cdecl Main(RED4ext::v1::PluginHandle handle,
    RED4ext::v1::EMainReason reason, const RED4ext::v1::Sdk* api) {
    if (reason == RED4ext::v1::EMainReason::Load) {
        sdk = api; plugin = handle;
        LoadOrigins();
        suffixAddress = reinterpret_cast<void*>(RED4ext::UniversalRelocBase::Resolve(1003499294));
        active = suffixAddress && sdk->hooking->Attach(plugin, suffixAddress, reinterpret_cast<void*>(&Override),
            reinterpret_cast<void**>(&original));
        if (!active) sdk->logger->Error(plugin, "Wardrobe BodyType hook unavailable; preview uses game body resolution");
        RED4ext::CRTTISystem::Get()->AddPostRegisterCallback(&Register);
        HMODULE module = nullptr;
        if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&SetBody), &module)) {
            wchar_t path[32768]{};
            if (GetModuleFileNameW(module, path, 32768)) {
                const auto scripts = std::filesystem::path(path).parent_path() / L"Scripts";
                if (!sdk->scripts->Add(plugin, scripts.c_str()))
                    sdk->logger->Error(plugin, "Could not register wardrobe native scripts");
            }
        }
    } else if (reason == RED4ext::v1::EMainReason::Unload) {
        if (active) sdk->hooking->Detach(plugin, suffixAddress);
        active = false; registered = nullptr; registeredId = 0; body.clear();
    }
    return true;
}
extern "C" __declspec(dllexport) void __cdecl Query(RED4ext::v1::PluginInfo* info) {
    info->name = L"NPV Maker Wardrobe Refit"; info->author = L"NPV Maker";
    info->version = {0, 1, 0, {0, 0}};
    info->sdk = {RED4EXT_VER_MAJOR, RED4EXT_VER_MINOR, RED4EXT_VER_PATCH, {0, 0}};
    info->runtime = {0xffff, 0xffff, 0xffff, 0xffff};
}
extern "C" __declspec(dllexport) uint32_t __cdecl Supports() { return RED4EXT_API_VERSION_1; }
