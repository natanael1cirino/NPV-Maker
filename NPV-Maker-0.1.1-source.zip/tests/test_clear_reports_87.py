"""BUGS item 87, messages (07/10/2026, player report on Nexus). The conversion stopped with "Unexpected converter error"
(NPVM-INTERNAL-001) for a game file the converter could not find, and the report reached an English player in
Portuguese. A missing or unreadable file now names itself with the codes the options use, and the report and the
summary are built again in the game's language where the texts leave for the game (storage_bridge)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import diagnostics  # noqa: E402
import runtime_entry  # noqa: E402
import storage_bridge  # noqa: E402
from runtime_resources import ResourceMissing, UnreadableResource  # noqa: E402

SLOT = "base\\characters\\head\\player_base_heads\\player_female_average\\h0_000_pwa_c__basehead\\" \
       "hx_000_pwa_c__basehead_personal_slot_dec.mesh"


def keep(text):
    return text


class ClassifyTest(unittest.TestCase):
    def test_a_missing_game_file_names_itself(self):
        error = ResourceMissing("Recurso nao encontrado nos mods instalados: " + SLOT)
        record = runtime_entry.classify(error, "conversion", "FV", keep)
        self.assertEqual(record["code"], "NPVM-RESOURCE-002")
        self.assertEqual(record["resource"], SLOT)
        self.assertEqual(record["action"], "stopped")

    def test_an_unreadable_file_names_itself(self):
        error = UnreadableResource("base\\characters\\common\\player_base_bodies\\appearances\\l0_000_base__full.app",
                                   "WolvenKit: [ 0: Error ] Invalid in wolven rtti")
        record = runtime_entry.classify(error, "conversion", "FV", keep)
        self.assertEqual(record["code"], "NPVM-WK-APP-002")
        self.assertTrue(record["resource"].endswith("l0_000_base__full.app"))
        self.assertEqual(record["tool"], "WolvenKit")

    def test_other_errors_stay_internal(self):
        self.assertEqual(runtime_entry.classify(KeyError("x"), "conversion", "FV", keep)["code"], "NPVM-INTERNAL-001")

    def test_export_keeps_its_own_code(self):
        record = runtime_entry.classify(ResourceMissing("x: y"), "export", "FV", keep)
        self.assertEqual(record["code"], "NPVM-PACKAGE-001")


class ReportLanguageTest(unittest.TestCase):
    def records(self):
        record = diagnostics.make("NPVM-RESOURCE-002", character="FV", option="tpp_head_face_rig", resource=SLOT,
                                  action="stopped", result="failed")
        record["project"] = "npv-20261007T133543Z-0001"
        return [record]

    def test_portuguese_report_is_unchanged(self):
        text = diagnostics.report("FV", self.records(), "error")
        self.assertTrue(text.startswith("NPV Maker " + diagnostics.NPV_VERSION + " - relatorio de diagnostico\n"
                                        "resultado: Importacao falhou"))

    def test_english_report(self):
        text = diagnostics.report("FV", self.records(), "error", "en")
        self.assertIn(" - diagnostic report\nresult: Import failed (NPVM-RESOURCE-002).", text)
        self.assertIn("\ndiagnostics: 1\n", text)
        self.assertIn("[1] A required body or head file is missing.", text)
        self.assertIn("hint=Enable the body and head mods used on V and try again.", text)
        self.assertIn("resource=" + SLOT, text)
        self.assertNotIn("relatorio", text)

    def test_the_game_gets_the_report_and_summary_in_its_language(self):
        records = self.records()
        with tempfile.TemporaryDirectory() as root:
            folder, storage = Path(root) / "data", Path(root) / "storage"
            exports = folder / "exports"
            exports.mkdir(parents=True)
            storage.mkdir()
            project = records[0]["project"]
            report = diagnostics.report("FV", records, "error")
            (exports / (project + ".json")).write_text(json.dumps({
                "format": "npv-maker-companion-job", "stage": "error",
                "message": diagnostics.headline("FV", records, "error"), "diagnostics": records,
                "summary": diagnostics.summary("FV", records, "error"), "report": report}), encoding="utf8")
            (exports / (project + ".report.txt")).write_text(report + "\n", encoding="utf8")
            (storage / "language.txt").write_text("lang\ten-us\nend\t1\n", encoding="utf8")
            storage_bridge.outbound(folder, storage, {})
            mirrored = (storage / (project + ".report.txt")).read_text(encoding="utf8")
            status = (storage / (project + ".txt")).read_text(encoding="utf8")
        self.assertEqual(mirrored, diagnostics.report("FV", records, "error", "en") + "\n")
        self.assertIn("summary\tNPV Maker " + diagnostics.NPV_VERSION + " - Import failed (NPVM-RESOURCE-002).", status)

    def test_a_report_not_built_from_the_status_is_copied(self):
        with tempfile.TemporaryDirectory() as root:
            folder, storage = Path(root) / "data", Path(root) / "storage"
            (folder / "exports").mkdir(parents=True)
            storage.mkdir()
            (folder / "exports" / "npv-1.json").write_text(json.dumps({
                "format": "npv-maker-companion-job", "stage": "error", "message": "x", "diagnostics": []}),
                encoding="utf8")
            (folder / "exports" / "npv-1.report.txt").write_text("texto livre\n", encoding="utf8")
            (storage / "language.txt").write_text("lang\ten\nend\t1\n", encoding="utf8")
            storage_bridge.outbound(folder, storage, {})
            self.assertEqual((storage / "npv-1.report.txt").read_text(encoding="utf8"), "texto livre\n")


if __name__ == "__main__":
    unittest.main()
