"""Nexus reports triaged on 09/10/2026, one class per BUGS item (91, 96, 98, 102, 103)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT / 'tests'))

import adapters  # noqa: E402
import companion_expansion  # noqa: E402
import npv_package as pkg  # noqa: E402
import runtime_npc  # noqa: E402
import runtime_resources  # noqa: E402
import storage_bridge  # noqa: E402
from test_npv_package import Fixture, form, seila_recipe  # noqa: E402

FRECKLES = 'base\\characters\\head\\player_base_heads\\player_female_average\\h0_000_pwa_c__basehead\\' \
           'hx_000_pwa__morphs_makeup_freckles_01.morphtarget'


def makeup_part(appearance, mask='18446744073709551615'):
    return {'$type': 'entMorphTargetSkinnedMeshComponent', 'name': {'$value': 'hx_000_pwa__morphs_makeup_freckles_01'},
            'id': '1234', 'morphResource': {'DepotPath': {'$value': FRECKLES}},
            'meshAppearance': {'$value': appearance}, 'chunkMask': mask}


class SameComponentTests(unittest.TestCase):
    """Item 96: blush and facial cyberware 5 share the component, each with its own mesh appearance."""

    KEY = ('hx_000_pwa__morphs_makeup_freckles_01', 'entMorphTargetSkinnedMeshComponent', '1234', FRECKLES, '')

    def test_another_appearance_keeps_both(self):
        selected = {}
        runtime_npc.add_component(selected, self.KEY, makeup_part('blush_01'))
        runtime_npc.add_component(selected, self.KEY, makeup_part('cyberware_05'))
        appearances = sorted(p['meshAppearance']['$value'] for p in selected.values())
        self.assertEqual(appearances, ['blush_01', 'cyberware_05'])

    def test_same_appearance_still_unites_the_masks(self):
        selected = {}
        runtime_npc.add_component(selected, self.KEY, makeup_part('01_ca_pale', '18446744073709551391'))
        runtime_npc.add_component(selected, self.KEY, makeup_part('01_ca_pale', '18446744073709551584'))
        self.assertEqual(len(selected), 1)
        self.assertEqual(int(next(iter(selected.values()))['chunkMask']),
                         18446744073709551391 | 18446744073709551584)


def big_project(size):
    def option(i):
        return dict(name='ccxl_option_' + str(i), body_part='Head', kind='appearance', selected_name='choice_' + str(i),
                    resource_path='mod\\ccxl\\option_' + str(i) + '.app', selected_index=0, choice_count=3,
                    active=True, editable=True, censored=False)
    project = seila_recipe()
    each = len(json.dumps([option(100000)], indent=2))
    project['options'] = [option(i) for i in range(size // each + 1)]
    return project


class ProjectSizeTests(unittest.TestCase):
    """Item 91: a project the save accepted (1-2 MB) was refused by the conversion ("Project exceeds 1 MB")."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)

    def test_a_saved_project_over_1_mb_converts(self):
        storage = Path(self.temp.name) / 'storage'
        projects = Path(self.temp.name) / 'projects'
        storage.mkdir()
        projects.mkdir()
        draft = storage / 'save-big91.draft.json'
        draft.write_text(json.dumps({'format': 'npv-maker-save-request', 'schema_version': 1, 'after_save': 'none',
                                     'body_strategy': 'selected_tpp', 'project': big_project(1_400_000)}),
                         encoding='utf8')
        saved = storage_bridge.save_project(draft, projects, storage, 1790000000.0)
        path = projects / (saved['id'] + '.npv.json')
        self.assertGreater(path.stat().st_size, 1024 * 1024)
        project, _ = companion_expansion.project_info(path)
        self.assertGreater(len(project['options']), 2900)

    def test_export_finds_a_project_over_1_mb(self):
        fx = Fixture(Path(self.temp.name), big_project(1_400_000))
        self.assertGreater(fx.project.stat().st_size, 1024 * 1024)
        self.assertEqual(pkg.find_project(fx.projects, fx.source), fx.project)


class ToolVersionTests(unittest.TestCase):
    """Item 98: with long paths off, WolvenKit prints a warning and a URL after the version."""

    def reader(self):
        reader = runtime_resources.Resources.__new__(runtime_resources.Resources)
        reader.version, reader.cli = None, Path('WolvenKit.CLI.exe')
        return reader

    def test_the_version_line_is_taken(self):
        output = ('8.19.0\r\nLong path support is disabled. Some files may fail.\r\n'
                  'https://wiki.redmodding.org/wolvenkit/getting-started/long-paths\r\n')
        with patch.object(runtime_resources, 'cli_run', return_value=output):
            self.assertEqual(self.reader().tool_version(), '8.19.0')

    def test_no_version_line_is_unknown(self):
        with patch.object(runtime_resources, 'cli_run', return_value='https://wiki.redmodding.org/\n'):
            self.assertEqual(self.reader().tool_version(), 'desconhecida')


class RenameRefusedTests(unittest.TestCase):
    """Item 103: Windows refused the .tmp -> .zip rename of a finished export (another program held the file)."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.fx = Fixture(Path(self.temp.name))
        self.real = Path.replace
        self.refusals = 0

    def export(self):
        draft = self.fx.draft()
        deps = [{'name': d['name'], 'author': '', 'url': d['url'], 'nexus_mod_id': d['nexus_mod_id'],
                 'required_for_rebuild': d['required_for_rebuild'], 'include': True, 'reason': d['reason'],
                 'detected': i} for i, d in enumerate(draft['dependencies'])]
        return pkg.export(self.fx.plugin, self.fx.projects, self.fx.token,
                          {'fields': form('1.0.0'), 'dependencies': deps}, draft, self.fx.exports)

    def refusing(self, times):
        test = self

        def replace(source, target):
            if Path(target).suffix == '.zip' and test.refusals < times:
                test.refusals += 1
                raise PermissionError(5, 'Accès refusé', str(source), None, str(target))
            return test.real(source, target)
        return replace

    def test_a_short_refusal_is_waited_out(self):
        with patch.object(Path, 'replace', self.refusing(3)), patch.object(pkg.time, 'sleep'):
            done = self.export()
        self.assertEqual(self.refusals, 3)
        self.assertTrue(done['zip'].is_file())

    def test_a_lasting_refusal_says_why(self):
        with patch.object(Path, 'replace', self.refusing(10 ** 6)), patch.object(pkg.time, 'sleep'):
            with self.assertRaises(pkg.PackageError) as caught:
                self.export()
        self.assertEqual(caught.exception.code, 'NPVM-PACKAGE-008')
        self.assertFalse(any(self.fx.exports.rglob('*.tmp')))
        self.assertIn('NPVM-PACKAGE-008', pkg.diagnostics.HINTS)
        self.assertIn('NPVM-PACKAGE-008', pkg.diagnostics.CODES)


class PhotoModePoseTests(unittest.TestCase):
    """Item 102: PhotoMode-EX gives a new character Panam's poses unless its record has visualTags ManAverage."""

    PHOTO = {'entity': 'npvmaker\\generated\\abc\\photomode.ent', 'atlas': 'npvmaker\\generated\\abc\\icon.inkatlas'}

    def record(self, body):
        out = adapters.files({'photomode': True}, 'abc', 'Character.NPVMaker_abc', 'x.ent', 'default', 'Hihi', '',
                             'npv_hihi', self.PHOTO, 'NPVMaker-abc-name', body)
        return out['r6/tweaks/NPVMaker/generated_abc_photomode.yaml']

    def test_a_male_npv_asks_for_the_male_poses(self):
        self.assertIn('  visualTags: [ ManAverage ]\n', self.record('male'))

    def test_a_female_npv_keeps_the_default(self):
        self.assertNotIn('visualTags', self.record('female'))


if __name__ == '__main__':
    unittest.main()
