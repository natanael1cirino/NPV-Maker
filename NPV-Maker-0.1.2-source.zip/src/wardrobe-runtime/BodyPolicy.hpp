#pragma once
#include <cstdint>
#include <string_view>
namespace npvfit {
inline bool ValidBody(std::string_view name) {
    if (name.size() > 64) return false;
    for (const unsigned char c : name) {
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_')) return false;
    }
    return true;
}
inline bool MayOverride(uint64_t context, bool bodySuffix, const void* registered,
    uint64_t registeredId, const void* owner, uint64_t ownerId, bool hasBody) {
    return context && bodySuffix && registered && owner == registered && registeredId &&
        ownerId == registeredId && hasBody;
}
}
