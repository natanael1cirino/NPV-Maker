#include "RecordOrigin.hpp"
#include <sstream>
#include <fstream>
#include <iostream>

std::string Fixture(uint32_t magic=0x0BB1DB47, uint32_t version=8, uint32_t offset=32, uint32_t count=2) {
    std::ostringstream data(std::ios::binary);
    uint32_t header[8]{magic,version,4,0,32,offset,0,0};
    data.write(reinterpret_cast<char*>(header),sizeof(header));
    data.write(reinterpret_cast<char*>(&count),4);
    for (uint64_t id : {0x123456789Aull,0x23456789ABull}) {
        uint32_t type=7;
        data.write(reinterpret_cast<char*>(&id),8); data.write(reinterpret_cast<char*>(&type),4);
    }
    return data.str();
}
int main(int argc, char** argv) {
    std::unordered_set<uint64_t> records;
    std::istringstream valid(Fixture(),std::ios::binary);
    if (!npvorigin::Read(valid,records) || records.size()!=2) return 1;
    if (npvorigin::Classify(0x123456789Aull,true,records)!=1 ||
        npvorigin::Classify(0xFF0000123456789Aull,true,records)!=1 ||
        npvorigin::Classify(0x3456789ABCull,true,records)!=2 ||
        npvorigin::Classify(0x3456789ABCull,false,records)!=0 ||
        npvorigin::Classify(0,true,records)!=0) return 2;
    for (auto bad : {Fixture(0),Fixture(0x0BB1DB47,9),Fixture(0x0BB1DB47,8,1000),
                     Fixture(0x0BB1DB47,8,32,2000001),Fixture().substr(0,40)}) {
        std::istringstream input(bad,std::ios::binary);
        if (npvorigin::Read(input,records) || records.size()!=2) return 3;
    }
    for (int i=1;i<argc;++i) {
        std::ifstream blob(argv[i],std::ios::binary);
        if (!npvorigin::Read(blob,records)) return 4;
    }
    // CRC32 + string length (TweakDBID): Items.Shorts_03_basic_03.
    if (argc>1 && npvorigin::Classify(0x1806031C17ull,true,records)!=1) return 5;
    std::cout << "Record origin malformed-input and classification checks PASS; local records=" << records.size() << '\n';
}
