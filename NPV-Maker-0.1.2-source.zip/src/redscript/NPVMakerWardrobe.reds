import Codeware.UI.*

public class NPVWardrobeEntry extends IScriptable {
  public let id: TweakDBID;
  public let key: String;
  public let name: String;
  public let search: String;
  public let category: Int32;
  public let factory: CName;
  // 0 unknown, 1 base/DLC record, 2 record added by a mod.
  public let origin: Int32;
}

// Discover installed records once per running editor process, in bounded batches.
// The Wardrobe+ factory restriction is for NPC garments. Here we dress the
// customized player preview, so player Clothing records are appropriate.
public class NPVWardrobeCatalog extends IScriptable {
  public let entries: array<ref<NPVWardrobeEntry>>;
  public let done: Bool;
  private let records: array<ref<TweakDBRecord>>;
  private let cursor: Int32;
  private let phase: Int32;
  // W14 (QA W12 1): one row per visual. Loot tiers, crafting, set and quest records repeat the same entity and
  // appearance (MEDIDO 08/10/2026, VHard_50_RefBody_Feet, Weak_20_Cool_Feet, Q000_Nomad_Boots...).
  private let visuals: ref<inkHashMap>;
  public static func Create() -> ref<NPVWardrobeCatalog> {
    let c = new NPVWardrobeCatalog();
    c.records = TweakDBInterface.GetRecords(n"Item_Record");
    return c;
  }
  public static func Placement(id: TweakDBID) -> TweakDBID {
    let rec = TweakDBInterface.GetItemRecord(id);
    if !IsDefined(rec) { return TDBID.None(); };
    // EquipmentEx places its extended slots last. Prefer that explicit slot
    // when present, allowing accessories to coexist instead of replacing tops.
    let i = rec.GetPlacementSlotsCount() - 1;
    while i >= 0 {
      let slot = rec.GetPlacementSlotsItem(i).GetID();
      if StrBeginsWith(TDBID.ToStringDEBUG(slot), "OutfitSlots.") { return slot; };
      i -= 1;
    };
    return EquipmentSystem.GetPlacementSlot(ItemID.FromTDBID(id));
  }
  public static func Category(id: TweakDBID) -> Int32 {
    let slot = NPVWardrobeCatalog.Placement(id);
    if Equals(slot, t"AttachmentSlots.Head") { return 0; };
    if Equals(slot, t"AttachmentSlots.Eyes") { return 1; };
    if Equals(slot, t"AttachmentSlots.Chest") { return 2; };
    if Equals(slot, t"AttachmentSlots.Torso") { return 3; };
    if Equals(slot, t"AttachmentSlots.Legs") { return 4; };
    if Equals(slot, t"AttachmentSlots.Feet") { return 5; };
    // An extended placement slot can still be a normal clothing category.
    let rec = TweakDBInterface.GetItemRecord(id);
    if IsDefined(rec) && IsDefined(rec.ItemType()) {
      switch rec.ItemType().Type() {
        case gamedataItemType.Clo_Head: return 0;
        case gamedataItemType.Clo_Face: return 1;
        case gamedataItemType.Clo_InnerChest: return 2;
        case gamedataItemType.Clo_OuterChest: return 3;
        case gamedataItemType.Clo_Legs: return 4;
        case gamedataItemType.Clo_Feet: return 5;
      };
    };
    return 6;
  }
  public static func CategoryLabel(i: Int32) -> String {
    switch i {
      case 0: return NPVWardrobeView.Text("CABECA", "HEAD", "CABEZA");
      case 1: return NPVWardrobeView.Text("ROSTO", "FACE", "ROSTRO");
      case 2: return NPVWardrobeView.Text("BLUSAS", "TOPS", "CAMISAS");
      case 3: return NPVWardrobeView.Text("CASACOS", "JACKETS", "CHAQUETAS");
      case 4: return NPVWardrobeView.Text("PERNAS", "LEGS", "PIERNAS");
      case 5: return NPVWardrobeView.Text("CALCADOS", "SHOES", "CALZADO");
    };
    return NPVWardrobeView.Text("EXTRAS", "EXTRAS", "EXTRAS");
  }

  private func Wearable(rec: ref<Item_Record>) -> Bool {
    if !IsDefined(rec) || !IsDefined(rec.ItemType()) { return false; };
    switch rec.ItemType().Type() {
      case gamedataItemType.Clo_Head: return true;
      case gamedataItemType.Clo_Face: return true;
      case gamedataItemType.Clo_InnerChest: return true;
      case gamedataItemType.Clo_OuterChest: return true;
      case gamedataItemType.Clo_Legs: return true;
      case gamedataItemType.Clo_Feet: return true;
      case gamedataItemType.Clo_Outfit: return true;
    };
    return StrBeginsWith(TDBID.ToStringDEBUG(NPVWardrobeCatalog.Placement(rec.GetID())), "OutfitSlots.");
  }
  // Lower is cleaner: the plain record wins over its loot, crafting and quest copies.
  private static func Rank(key: String, named: Bool) -> Int32 {
    let score = StrLen(key);
    if !named { score += 300; };
    if StrContains(key, "Crafting") || StrContains(key, "Proficiency") { score += 200; };
    if StrBeginsWith(key, "Items.VHard_") || StrBeginsWith(key, "Items.Hard_") || StrBeginsWith(key, "Items.Avg_")
      || StrBeginsWith(key, "Items.Weak_") || StrBeginsWith(key, "Items.VWeak_") || StrBeginsWith(key, "Items.Normal_") { score += 100; };
    if StrBeginsWith(key, "Items.Q") && StringToInt(StrMid(key, 7, 1), -1) >= 0 { score += 50; };
    return score;
  }

  public func Step() -> Void {
    if this.done { return; };
    if !IsDefined(this.visuals) { this.visuals = new inkHashMap(); };
    let stop = Min(this.cursor + 128, ArraySize(this.records));
    while this.cursor < stop {
      let rec = this.records[this.cursor] as Item_Record;
      this.cursor += 1;
      if (this.phase == 1 || !IsDefined(rec as Clothing_Record)) && this.Wearable(rec) && TDBID.IsValid(NPVWardrobeCatalog.Placement(rec.GetID())) && IsNameValid(rec.EntityName()) {
        let e = new NPVWardrobeEntry();
        e.id = rec.GetID(); e.key = TDBID.ToStringDEBUG(e.id);
        e.name = GetLocalizedTextByKey(rec.DisplayName());
        if StrLen(e.name) == 0 { e.name = e.key; };
        e.search = StrLower(e.name + " " + e.key + " " + NameToString(rec.EntityName()));
        e.category = NPVWardrobeCatalog.Category(e.id);
        e.factory = rec.EntityName();
        e.origin = NPVMakerWardrobeOrigin(e.id);
        // MEDIDO 08/10/2026 (695 records of the Aiko wardrobe): records a mod adds as NPC copies of vanilla clothes
        // have no appearance suffix and no ArchiveXL dynamic name. On V the game drops them from the slot and keeps
        // their meshes drawn. They are not clothes for V and stay out of the catalog.
        let named = NotEquals(e.name, e.key);
        // W14 (QA W12 2): base templates (FootClothingBase, ArmoredOuterChestClothing) and TEST records are not clothes.
        let template = StrBeginsWith(e.key, "TEST.") || (e.origin == 1 && !named);
        if !template && !(e.origin == 2 && rec.GetAppearanceSuffixesCount() == 0 && !StrContains(NameToString(rec.AppearanceName()), "!")) {
          let look = NameToString(rec.AppearanceName());
          if StrLen(look) == 0 || Equals(look, "None") {
            ArrayPush(this.entries, e);
          } else {
            let hash = TDBID.ToNumber(TDBID.Create(ToString(e.origin) + "|" + NameToString(e.factory) + "|" + look));
            if this.visuals.KeyExist(hash) {
              let kept = this.visuals.Get(hash) as NPVWardrobeEntry;
              if IsDefined(kept) && NPVWardrobeCatalog.Rank(e.key, named) < NPVWardrobeCatalog.Rank(kept.key, NotEquals(kept.name, kept.key)) {
                kept.id = e.id; kept.key = e.key; kept.name = e.name; kept.search = e.search; kept.category = e.category;
              };
            } else {
              this.visuals.Insert(hash, e);
              ArrayPush(this.entries, e);
            };
          };
        };
      };
    };
    this.done = this.cursor >= ArraySize(this.records);
    // TweakXL record enumeration can be exact-type rather than polymorphic.
    // Discover both base Item records used by mods and Clothing records without
    // adding Clothing instances twice when the first query included subclasses.
    if this.done && this.phase == 0 {
      this.records = TweakDBInterface.GetRecords(n"Clothing_Record");
      this.cursor = 0; this.phase = 1; this.done = false;
    };
    if this.done { ArrayClear(this.records); this.visuals = null; };
  }
}

// W07: icon + label category tab. The icon is the piece worn in that category,
// or the game's own empty-slot silhouette, at a size this tab controls.
public class NPVWardrobeTab extends NPVMakerCompactButton {
  private let icon: ref<inkImage>;
  private let bar: ref<inkRectangle>;
  protected func CreateWidgets() {
    super.CreateWidgets();
    this.m_root.SetSize(128.0, 132.0);
    this.m_label.SetFontSize(22);
    this.m_label.SetVerticalAlignment(textVerticalAlignment.Bottom);
    this.m_label.SetMargin(new inkMargin(2.0, 0.0, 2.0, 10.0));
    this.icon = new inkImage();
    this.icon.SetSize(68.0, 68.0);
    this.icon.SetAnchor(inkEAnchor.TopCenter);
    this.icon.SetAnchorPoint(new Vector2(0.5, 0.0));
    this.icon.SetMargin(new inkMargin(0.0, 14.0, 0.0, 0.0));
    this.icon.SetFitToContent(false);
    this.icon.SetInteractive(false);
    this.icon.Reparent(this.m_root);
    this.bar = new inkRectangle();
    this.bar.SetSize(112.0, 4.0);
    this.bar.SetMargin(new inkMargin(8.0, 126.0, 0.0, 0.0));
    this.bar.SetTintColor(ThemeColors.ElectricBlue());
    this.bar.SetInteractive(false);
    this.bar.Reparent(this.m_root);
  }
  public func Paint(atlas: ResRef, part: CName, selected: Bool, worn: Bool) -> Void {
    this.icon.SetVisible(ResRef.IsValid(atlas) && IsNameValid(part));
    if ResRef.IsValid(atlas) && IsNameValid(part) {
      this.icon.SetAtlasResource(atlas);
      this.icon.SetTexturePart(part);
    };
    this.icon.SetTintColor(worn ? new HDRColor(1.0, 1.0, 1.0, 1.0) : ThemeColors.Bittersweet());
    this.icon.SetOpacity(worn ? 1.0 : 0.45);
    this.m_label.UnbindProperty(n"tintColor");
    this.m_label.SetTintColor(selected ? ThemeColors.ElectricBlue() : ThemeColors.Bittersweet());
    this.m_fill.SetOpacity(selected ? 0.25 : 0.0);
    this.bar.SetVisible(selected);
  }
  public static func Make() -> ref<NPVWardrobeTab> {
    let button = new NPVWardrobeTab();
    button.CreateInstance();
    return button;
  }
}

// W07: filter chip whose state is shown, not only spelled in its text.
public class NPVWardrobeChip extends NPVMakerCompactButton {
  private let bar: ref<inkRectangle>;
  protected func CreateWidgets() {
    super.CreateWidgets();
    this.m_label.SetFontSize(26);
    this.bar = new inkRectangle();
    this.bar.SetSize(4.0, 44.0);
    this.bar.SetMargin(new inkMargin(0.0, 10.0, 0.0, 0.0));
    this.bar.SetTintColor(ThemeColors.ElectricBlue());
    this.bar.SetInteractive(false);
    this.bar.Reparent(this.m_root);
  }
  public func Mark(selected: Bool) -> Void {
    this.m_label.UnbindProperty(n"tintColor");
    this.m_label.SetTintColor(selected ? ThemeColors.ElectricBlue() : ThemeColors.Bittersweet());
    this.m_fill.SetOpacity(selected ? 0.25 : 0.0);
    this.bar.SetVisible(selected);
  }
  public static func Make() -> ref<NPVWardrobeChip> {
    let button = new NPVWardrobeChip();
    button.CreateInstance();
    return button;
  }
}

// W07: one whole clickable row per piece, in the shape of the approved UI10
// appearance list (NPVChoiceButton): thumbnail, name, second line, marker.
public class NPVWardrobeRow extends NPVMakerCompactButton {
  private let selection: ref<inkRectangle>;
  private let thumb: ref<inkImage>;
  private let divider: ref<inkRectangle>;
  protected func CreateWidgets() {
    super.CreateWidgets();
    this.m_root.SetSize(856.0, 108.0);
    this.m_bg.SetVisible(false);
    this.m_frame.SetVisible(false);
    this.m_label.SetFontSize(28);
    this.m_label.SetWrapping(true, 692.0);
    this.m_label.SetHorizontalAlignment(textHorizontalAlignment.Left);
    this.m_label.SetMargin(new inkMargin(136.0, 0.0, 12.0, 0.0));
    this.divider = new inkRectangle();
    this.divider.SetSize(856.0, 1.0);
    this.divider.SetMargin(new inkMargin(0.0, 107.0, 0.0, 0.0));
    this.divider.SetTintColor(ThemeColors.RedOxide());
    this.divider.SetInteractive(false);
    this.divider.Reparent(this.m_root);
    let back = new inkRectangle();
    back.SetSize(104.0, 104.0);
    back.SetMargin(new inkMargin(14.0, 2.0, 0.0, 0.0));
    back.SetTintColor(new HDRColor(0.10, 0.03, 0.05, 1.0));
    back.SetInteractive(false);
    back.Reparent(this.m_root);
    this.thumb = new inkImage();
    this.thumb.SetSize(100.0, 100.0);
    this.thumb.SetMargin(new inkMargin(16.0, 4.0, 0.0, 0.0));
    this.thumb.SetFitToContent(false);
    this.thumb.SetInteractive(false);
    this.thumb.Reparent(this.m_root);
    this.selection = new inkRectangle();
    this.selection.SetSize(4.0, 92.0);
    this.selection.SetMargin(new inkMargin(0.0, 8.0, 0.0, 0.0));
    this.selection.SetTintColor(ThemeColors.ElectricBlue());
    this.selection.SetInteractive(false);
    this.selection.Reparent(this.m_root);
  }
  // W24: outfit rows are narrower to leave room for the rename and delete buttons.
  public func SetRowWidth(width: Float) -> Void {
    this.m_root.SetSize(width, 108.0);
    this.m_label.SetWrapping(true, width - 164.0);
    this.divider.SetSize(width, 1.0);
  }
  public func Mark(worn: Bool, favorite: Bool) -> Void {
    this.m_label.UnbindProperty(n"tintColor");
    this.m_label.SetTintColor(worn ? ThemeColors.ElectricBlue() : (favorite ? new HDRColor(1.0, 0.78, 0.24, 1.0) : ThemeColors.Bittersweet()));
    this.m_fill.SetOpacity(worn ? 0.25 : 0.0);
    this.selection.SetVisible(worn);
  }
  public func SetIcon(atlas: ResRef, part: CName, silhouette: Bool) -> Void {
    this.thumb.SetVisible(ResRef.IsValid(atlas) && IsNameValid(part));
    if !ResRef.IsValid(atlas) || !IsNameValid(part) { return; };
    this.thumb.SetAtlasResource(atlas);
    this.thumb.SetTexturePart(part);
    this.thumb.SetTintColor(silhouette ? ThemeColors.Bittersweet() : new HDRColor(1.0, 1.0, 1.0, 1.0));
    this.thumb.SetOpacity(silhouette ? 0.45 : 1.0);
  }
  public static func Make() -> ref<NPVWardrobeRow> {
    let button = new NPVWardrobeRow();
    button.CreateInstance();
    return button;
  }
}

// DEV W07: wardrobe on the existing character-creation puppet.
// No WardrobeSystem, player inventory, saved sets, or finalization requests.
// Dressing path (W03), camera (W02) and refit/coverage (W05) are unchanged.
// W08: what the puppet wears is the NPV's outfit. Closing the panel keeps it on;
// the save records each piece (OutfitJson) and the converter dresses the NPV.
public class NPVWardrobeView extends IScriptable {
  public static func Text(pt: String, en: String, es: String) -> String {
    let lang = NPVText.GameLanguage();
    return Equals(lang, "pt") ? pt : (Equals(lang, "es") ? es : en);
  }
  // W21 (author 08/10/2026, "the icons are too small"): 6 rows of 112 px with a 100 px thumbnail fill the same 672 px
  // as the 8 rows of 84 px with a 68 px one.
  public static func Rows() -> Int32 = 6
  public static func Pitch() -> Float = 112.0
  // Build label of the logs and diagnostic files (wardrobe-<label>*.tsv). Comments keep the build that wrote them.
  public static func Label() -> String = "W24"
  public static func File(suffix: String) -> String = "wardrobe-" + StrLower(NPVWardrobeView.Label()) + suffix

  // The six base clothing slots and every EquipmentEx outfit slot in TweakDB.
  public static func AllSlots() -> array<TweakDBID> {
    let list = [t"AttachmentSlots.Head", t"AttachmentSlots.Eyes", t"AttachmentSlots.Chest", t"AttachmentSlots.Torso", t"AttachmentSlots.Legs", t"AttachmentSlots.Feet"];
    for rec in TweakDBInterface.GetRecords(n"AttachmentSlot") {
      let id = rec.GetID();
      if StrBeginsWith(TDBID.ToStringDEBUG(id), "OutfitSlots.") && !ArrayContains(list, id) { ArrayPush(list, id); };
    };
    return list;
  }
  private let menu: wref<characterCreationBodyMorphMenu>;
  private let root: ref<inkCanvas>;
  private let rows: ref<inkVerticalPanel>;
  private let status: ref<inkText>;
  private let countLabel: ref<inkText>;
  private let pageLabel: ref<inkText>;
  private let refitLabel: ref<inkText>;
  private let scrollTrack: ref<inkRectangle>;
  private let scrollThumb: ref<inkRectangle>;
  private let previousButton: ref<SimpleButton>;
  private let nextButton: ref<SimpleButton>;
  private let clearButton: ref<SimpleButton>;
  private let tabs: array<ref<NPVWardrobeTab>>;
  private let chips: array<ref<NPVWardrobeChip>>;
  private let puppet: wref<gamePuppet>;
  private let slots: array<TweakDBID>;
  private let originals: array<ItemID>;
  private let trial: array<ItemID>;
  private let given: array<ItemID>;
  private let changed: array<Bool>;
  private let desired: array<TweakDBID>;
  private let worn: array<TweakDBID>;
  // W10: what the puppet draws. MEDIDO 08/10/2026: one outfit item drew six meshes from one slot, and NPC-made
  // records leave meshes drawn after their slot empties. The tab shows and removes these, not slot readback.
  private let drawnNames: array<CName>;
  private let drawnStamp: String;
  // W15 (QA W14 1): a switched-off piece is that component, not its name. The same piece worn again comes back.
  private let hiddenParts: array<wref<IComponent>>;
  // W15 (QA W14 5): which slot draws a piece is MEASURED: what turned on after that slot was dressed.
  private let ownNames: array<CName>;
  private let ownSlots: array<Int32>;
  private let beforeWear: array<CName>;
  private let cardDrawn: array<CName>;
  private let listTotal: Int32;
  // W11 (QA W10 1-3, 08/10/2026): hiding a drawn piece left its item equipped (cap still in the slot, body squeezed,
  // every hidden piece flashing back on each change). A piece is now taken off for real; only what the game still
  // draws a moment later, with no item behind it, is switched off.
  private let pendingNames: array<CName>;
  private let pendingUntil: Int32;
  private let sweepAll: Bool;
  // W11 (QA W10 4): the scroll bar can be dragged and clicked.
  private let trackHit: ref<inkRectangle>;
  private let dragging: Bool;
  private let wornStamp: String;
  private let cardIDs: array<TweakDBID>;
  // W14 (QA W12 4): the worn block a list opened with stays put while the list is open, so rows never move under
  // the mouse; rows carry their record key, so a click wears what the row says.
  private let pinned: array<TweakDBID>;
  private let pinnedView: String;
  // W14 (QA W12 3): only the piece just chosen is retried; one the game refuses leaves the outfit once.
  private let watched: array<Bool>;
  // W14 (QA W12 5): body and piece components per change, to measure the body left deformed after taking clothes off.
  private let bodyNames: array<String>;
  private let bodyStates: array<String>;
  private let bodyLog: String;
  private let lastAction: String;
  private let category: Int32;
  // 0 everything in the tab, 1 every favorite, 2 everything worn now.
  private let mode: Int32;
  // Catalog origin, never both (author 08/10/2026, thousands of mod clothes): 0/1 game, 2 mods.
  private let source: Int32;
  private let ticks: Int32;
  private let retries: Int32;
  private let watchUntil: Int32;
  private let watchName: String;
  private let marker: wref<entSkinnedMeshComponent>;
  private let hadMarker: Bool;
  private let cameraTicks: Int32;
  private let search: wref<HubTextInput>;
  // W24 (author 10/10/2026): outfit being renamed in OUTFITS, as index + 1 (0 = none), and its text field.
  private let renameIndex: Int32;
  private let renameInput: wref<HubTextInput>;
  private let fit: ref<NPVWardrobeFit>;
  private let fitRevision: Int32;
  private let refitIndex: Int32;
  private let query: String;
  private let catalog: ref<NPVWardrobeCatalog>;
  private let filtered: array<ref<NPVWardrobeEntry>>;
  private let offset: Int32;
  private let favorites: array<String>;
  private let favoritesLoaded: Bool;
  private let lastEquippedSlot: Int32;
  private let lastCatalogSize: Int32;
  private let lastCatalogDone: Bool;
  private let slotsInitialized: Bool;
  // W16 (QA W15, MEDIDO 08/10/2026 13:10): initializing every slot again when a new one was used emptied the others
  // (the vest left OutfitSlots.TorsoInner when the dress went to TorsoOuter, and stayed drawn). Only new slots are
  // initialized now, and a piece the game drops from its slot goes back in.
  private let initSlots: array<TweakDBID>;
  // W22: preview items waiting to leave the inventory, and the tick they leave on.
  private let dropQueue: array<ItemID>;
  // W23: editor underwear switched off because a worn piece covers it, and which regions are covered now.
  private let underwearOff: array<wref<IComponent>>;
  private let legsCovered: Bool;
  private let torsoCovered: Bool;
  private let dropAt: array<Int32>;
  private let operations: String;
  private let closeRequested: Bool;
  private let lastDiagnostic: String;
  private let open: Bool;

  public static func Create(menu: ref<characterCreationBodyMorphMenu>, show: Bool) -> ref<NPVWardrobeView> {
    let s = NPVMakerSession.GetInstance();
    if !IsDefined(s) || !s.active || !IsDefined(s.system) { return null; };
    let host = s.system.GetPuppetPreviewGameController();
    if !IsDefined(host) || !IsDefined(host.GetGamePuppet()) { return null; };
    let p = host.GetGamePuppet();
    // Even if a loaded session exists, never operate on its controlled player.
    if p == GetPlayer(GetGameInstance()) { return null; };
    let ts = GameInstance.GetTransactionSystem(p.GetGame());
    if !IsDefined(ts) { return null; };
    let v = new NPVWardrobeView();
    v.menu = menu;
    v.lastEquippedSlot = -1;
    v.puppet = p;
    v.slots = [t"AttachmentSlots.Head", t"AttachmentSlots.Eyes", t"AttachmentSlots.Chest", t"AttachmentSlots.Torso", t"AttachmentSlots.Legs", t"AttachmentSlots.Feet"];
    let i = 0;
    while i < 6 {
      let obj = ts.GetItemInSlot(p, v.slots[i]);
      let original: ItemID;
      if IsDefined(obj) { original = obj.GetItemID(); };
      ArrayPush(v.originals, original);
      ArrayPush(v.trial, original);
      ArrayPush(v.changed, false);
      ArrayPush(v.watched, false);
      ArrayPush(v.desired, ItemID.GetTDBID(original));
      i += 1;
    };
    if !IsDefined(s.wardrobeCatalog) { s.wardrobeCatalog = NPVWardrobeCatalog.Create(); };
    v.catalog = s.wardrobeCatalog;
    v.fit = NPVWardrobeFit.Create(p);
    v.refitIndex = s.wardrobeRefit;
    v.category = 3;
    v.Build();
    v.RememberBody();
    v.lastAction = "open";
    v.ReadBody();
    s.wardrobe = v;
    // A puppet the editor rebuilt gets the outfit back: it is part of the NPV.
    let look = s.wardrobeLook;
    for id in look { v.TryItem(id); };
    v.ReadWorn();
    if show { v.Show(); } else {
      v.root.SetVisible(false);
      v.menu.NPVWardrobeCamera(false);
    };
    ModLog(n"NPVMaker", NPVWardrobeView.Label() + " created: shown=" + ToString(show) + ", outfit restored=" + ToString(ArraySize(look)));
    return v;
  }

  public func IsOpen() -> Bool { return this.open && IsDefined(this.root); }

  public func Valid() -> Bool {
    let s = NPVMakerSession.GetInstance();
    if !IsDefined(s) || !s.active || !IsDefined(s.system) || !IsDefined(this.puppet) { return false; };
    let host = s.system.GetPuppetPreviewGameController();
    return IsDefined(host) && host.GetGamePuppet() == this.puppet && this.puppet != GetPlayer(GetGameInstance());
  }

  public func Show() -> Void {
    if !IsDefined(this.root) { return; };
    this.open = true;
    this.closeRequested = false;
    this.pinnedView = "";
    this.root.SetVisible(true);
    this.menu.NPVWardrobeCamera(true);
    NPVMakerSession.GetInstance().wardrobePreviewActive = true;
    this.ReadWorn();
    this.RefreshTabs();
    this.Render();
  }

  // Closing the panel keeps the outfit on the puppet (it goes to the NPV). With
  // nothing chosen, the preview is restored and the view ends (returns false).
  public func Hide() -> Bool {
    this.ReadWorn();
    this.SyncLook();
    if ArraySize(NPVMakerSession.GetInstance().wardrobeLook) == 0 {
      this.Close();
      return false;
    };
    this.open = false;
    this.watchUntil = 0;
    this.root.SetVisible(false);
    this.menu.NPVWardrobeCamera(false);
    NPVMakerSession.GetInstance().wardrobePreviewActive = false;
    NPVMakerSession.GetInstance().SetStatus(NPVWardrobeView.Text("A roupa ficou no personagem e vai para o NPV quando voce salvar ou criar.", "The clothes stay on the character and go to the NPV when you save or create it.", "La ropa queda en el personaje y pasa al NPV al guardar o crearlo."));
    ModLog(n"NPVMaker", NPVWardrobeView.Label() + " panel closed: outfit kept=" + ToString(ArraySize(NPVMakerSession.GetInstance().wardrobeLook)));
    return true;
  }

  // The pieces chosen in this tab that the puppet still wears.
  private func SyncLook() -> Void {
    let s = NPVMakerSession.GetInstance();
    ArrayClear(s.wardrobeLook);
    let k = 0;
    while k < ArraySize(this.slots) {
      // MEDIDO 08/10/2026: a piece can be drawn on the puppet while its slot reads back empty (Aiko wardrobe
      // records). What was chosen stays chosen; the converter keeps only what the puppet drew.
      if this.changed[k] && TDBID.IsValid(this.desired[k]) { ArrayPush(s.wardrobeLook, this.desired[k]); };
      k += 1;
    };
    s.wardrobeRefit = this.refitIndex;
  }

  private static func ComponentJson(c: ref<IComponent>) -> String {
    let skinned = c as entSkinnedMeshComponent;
    let morph = c as entMorphTargetSkinnedMeshComponent;
    let mesh = c as MeshComponent;
    let field = "mesh";
    let reference: ResourceAsyncRef;
    let look: CName;
    let chunk: Uint64;
    if IsDefined(skinned) { reference = skinned.mesh; look = skinned.meshAppearance; chunk = skinned.chunkMask; }
    else if IsDefined(morph) { field = "morphResource"; reference = morph.morphResource; look = morph.meshAppearance; chunk = morph.chunkMask; }
    else if IsDefined(mesh) { reference = mesh.mesh; look = mesh.meshAppearance; chunk = mesh.chunkMask; }
    else { return ""; };
    if ResourceAsyncRef.IsEmpty(reference) { return ""; };
    return "{\"name\": " + NPVFiles.Json(NameToString(c.GetName())) + ", \"type\": " + NPVFiles.Json(NameToString(c.GetClassName()))
      + ", \"enabled\": " + NPVFiles.JsonBool(c.IsEnabled()) + ", \"owner_appearance\": " + NPVFiles.Json(NameToString(c.GetAppearanceName()))
      + ", \"owner_app\": " + NPVFiles.Json(ResRef.ToString(c.appearancePath)) + ", \"field\": " + NPVFiles.Json(field)
      + ", \"hash\": " + NPVFiles.Json(ToString(ResourceAsyncRef.GetHash(reference))) + ", \"path\": " + NPVFiles.Json(ResRef.ToString(ResourceAsyncRef.GetPath(reference)))
      + ", \"mesh_appearance\": " + NPVFiles.Json(NameToString(look)) + ", \"chunk_mask\": " + NPVFiles.Json(ToString(chunk))
      + ", \"state\": \"LOADED\"}";
  }

  // Vanilla player clothing entities by factory entry name (clothing.csv of the base game, MEDIDO 07/10/2026).
  public static func FactoryTemplate(rec: ref<Item_Record>) -> String {
    if !IsDefined(rec) { return ""; };
    let name = NameToString(rec.EntityName());
    if !StrBeginsWith(name, "player_") || !StrEndsWith(name, "_item") && !StrEndsWith(name, "_item_ep1") { return ""; };
    let folder = "";
    if StrContains(name, "face") { folder = "face"; }
    else if StrContains(name, "head") { folder = "hat"; }
    else if StrContains(name, "torso") { folder = "torso"; }
    else if StrContains(name, "legs") { folder = "legs"; }
    else if StrContains(name, "feet") { folder = "feet"; }
    else if StrContains(name, "outfit") { folder = "outfit"; }
    else if StrContains(name, "underwear") { folder = "underwear"; };
    if StrLen(folder) == 0 { return ""; };
    return (StrEndsWith(name, "_ep1") ? "ep1" : "base") + "\\gameplay\\items\\equipment\\" + folder + "\\" + name + ".ent";
  }

  // Read-only: each chosen piece the puppet wears, with the item entity, the
  // appearance the game resolved and the mesh components it mounted.
  public func OutfitJson() -> String {
    let pieces = this.PiecesJson();
    NPVFiles.Write(NPVWardrobeView.File("-outfit.json"), "{\"schema\": 1, \"pieces\": [" + pieces + "]}");
    return "{\"schema\": 1, \"pieces\": [" + pieces + "]}";
  }

  private func PiecesJson() -> String {
    let pieces = "";
    let count = 0;
    if this.Valid() {
      let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
      let i = 0;
      while i < ArraySize(this.slots) {
        let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
        let id: TweakDBID;
        if IsDefined(obj) { id = ItemID.GetTDBID(obj.GetItemID()); };
        if this.changed[i] && TDBID.IsValid(this.desired[i]) {
          // The item entity may be missing or empty (MEDIDO 08/10/2026): the record still names the piece.
          id = this.desired[i];
          let rec = TweakDBInterface.GetItemRecord(id);
          let name = IsDefined(rec) ? GetLocalizedTextByKey(rec.DisplayName()) : "";
          let outfit = IsDefined(rec) && IsDefined(rec.ItemType()) && Equals(rec.ItemType().Type(), gamedataItemType.Clo_Outfit);
          let components = "";
          let template = "";
          let current = "";
          if IsDefined(obj) && Equals(ItemID.GetTDBID(obj.GetItemID()), id) {
            template = ResRef.ToString(obj.GetTemplatePath());
            current = NameToString(obj.GetCurrentAppearanceName());
            for c in obj.GetComponents() {
              let row = NPVWardrobeView.ComponentJson(c);
              if StrLen(row) > 0 { components += (StrLen(components) > 0 ? ", " : "") + row; };
            };
          };
          pieces += (count > 0 ? ", " : "") + "{\"record\": " + NPVFiles.Json(TDBID.ToStringDEBUG(id))
            + ", \"slot\": " + NPVFiles.Json(TDBID.ToStringDEBUG(this.slots[i])) + ", \"name\": " + NPVFiles.Json(name)
            + ", \"category\": " + ToString(NPVWardrobeCatalog.Category(id))
            + ", \"covers_groin\": " + NPVFiles.JsonBool(outfit || NPVWardrobeCatalog.Category(id) == 4)
            + ", \"template\": " + NPVFiles.Json(StrLen(template) > 0 ? template : NPVWardrobeView.FactoryTemplate(rec))
            + ", \"appearance\": " + NPVFiles.Json(current)
            + ", \"appearance_name\": " + NPVFiles.Json(IsDefined(rec) ? NameToString(rec.AppearanceName()) : "")
            + ", \"body\": " + NPVFiles.Json(this.fit.body) + ", \"components\": [" + components + "]}";
          count += 1;
        };
        i += 1;
      };
    };
    return pieces;
  }

  public func Typing() -> Bool { return IsDefined(this.search) && this.search.IsFocused(); }
  public func CloseRequested() -> Bool { return this.closeRequested; }

  // Wardrobe+ v68/v91: watch weak body components, then reattach only missing
  // pieces. Slot inventory alone does not prove that a piece survived a rebuild.
  private func BodyMarker() -> wref<entSkinnedMeshComponent> {
    for c in this.puppet.GetComponents() {
      let mesh = c as entSkinnedMeshComponent;
      if IsDefined(mesh) && !ResourceAsyncRef.IsEmpty(mesh.mesh) { return mesh; };
    };
    return null;
  }

  private func RememberBody() -> Void {
    this.marker = this.BodyMarker();
    this.hadMarker = IsDefined(this.marker);
  }

  // Wardrobe+ appearance/component normalization (v70/v73). Keep complete
  // piece names: a shared clothing family must not count as the selected piece.
  private func Prefix(value: String) -> String {
    let s = StrLower(value);
    let cut = StrFindFirst(s, "!");
    let amp = StrFindFirst(s, "&");
    if amp >= 0 && (cut < 0 || amp < cut) { cut = amp; };
    if cut >= 0 { s = StrLeft(s, cut); };
    while StrLen(s) > 0 && StrEndsWith(s, "_") { s = StrLeft(s, StrLen(s) - 1); };
    return s;
  }

  private func PieceNames(tdb: TweakDBID) -> array<String> {
    let names: array<String>;
    let rec = TweakDBInterface.GetItemRecord(tdb);
    if !IsDefined(rec) { return names; };
    let pre = this.Prefix(NameToString(rec.AppearanceName()));
    if StrLen(pre) >= 4 { ArrayPush(names, pre); };
    let id = StrLower(TDBID.ToStringDEBUG(tdb));
    let dot = StrFindFirst(id, ".");
    if dot >= 0 { id = StrRight(id, StrLen(id) - dot - 1); };
    if StrLen(id) >= 10 { ArrayPush(names, id); };
    let factory = StrLower(NameToString(rec.EntityName()));
    if StrLen(factory) >= 10 { ArrayPush(names, factory); };
    return names;
  }

  private func PieceMesh(i: Int32) -> Bool {
    if !TDBID.IsValid(this.desired[i]) { return false; };
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let item = ts.GetItemInSlot(this.puppet, this.slots[i]);
    // Item objects can expose their meshes directly; merged preview meshes are
    // observed on the puppet using the Wardrobe+ complete-name matching below.
    if IsDefined(item) && Equals(ItemID.GetTDBID(item.GetItemID()), this.desired[i]) {
      for c in item.GetComponents() {
        let mesh = c as entSkinnedMeshComponent;
        if IsDefined(mesh) && !ResourceAsyncRef.IsEmpty(mesh.mesh) { return true; };
      };
    };
    let names = this.PieceNames(this.desired[i]);
    for c in this.puppet.GetComponents() {
      let mesh = c as entSkinnedMeshComponent;
      if IsDefined(mesh) && !ResourceAsyncRef.IsEmpty(mesh.mesh) && this.NameMatches(names, mesh.GetName()) { return true; };
    };
    return false;
  }

  private func NameMatches(names: array<String>, raw: CName) -> Bool {
    let name = this.Prefix(NameToString(raw));
    for pre in names {
      if StrBeginsWith(name, pre)
        || (StrLen(name) >= 6 && StrBeginsWith(pre + "_", name + "_"))
        || (StrLen(name) >= 10 && StrContains("_" + pre + "_", "_" + name + "_"))
        || (StrLen(pre) >= 10 && StrContains("_" + name + "_", "_" + pre + "_")) { return true; };
    };
    return false;
  }

  // Mesh components of the appearances the game generates for worn items ("<number>_<n>.app", MEDIDO 08/10/2026).
  private static func GeneratedPiece(c: ref<IComponent>) -> Bool {
    if !IsDefined(c as entSkinnedMeshComponent) && !IsDefined(c as MeshComponent) { return false; };
    let app = ResRef.ToString(c.appearancePath);
    return StrEndsWith(app, ".app") && StrFindFirst(app, "\\") < 0 && StrFindFirst(app, "_") > 0
      && StringToInt(StrLeft(app, 1), -1) >= 0;
  }

  // Category of a drawn mesh by the game's naming (h1 head, f1 face, t0/t1 tops, t2 jackets, l1 legs, s1 shoes).
  private static func DrawnCategory(name: CName) -> Int32 {
    let n = StrLower(NameToString(name));
    let first = StrLeft(n, 1);
    if Equals(first, "h") { return 0; };
    if Equals(first, "f") { return 1; };
    if Equals(first, "t") { return Equals(StrMid(n, 1, 1), "2") ? 3 : 2; };
    if Equals(first, "l") { return 4; };
    if Equals(first, "s") { return 5; };
    return 6;
  }

  private static func DrawnLabel(name: CName) -> String {
    let n = StrLower(NameToString(name));
    while StrLen(n) > 0 && StringToInt(StrRight(n, 1), -1) >= 0 { n = StrLeft(n, StrLen(n) - 1); };
    let label = "";
    for token in StrSplit(n, "_") {
      if StrLen(token) > 0 && !Equals(token, "pwa") && !Equals(token, "pma") && !Equals(token, "wa") && !Equals(token, "ma") {
        label += (StrLen(label) > 0 ? " " : "") + token;
      };
    };
    return StrLen(label) > 0 ? label : NameToString(name);
  }

  private func IsHidden(c: ref<IComponent>) -> Bool {
    for part in this.hiddenParts {
      if IsDefined(part) && part == c { return true; };
    };
    return false;
  }

  private func HidePart(c: ref<IComponent>) -> Void {
    if this.IsUnderwear(c.GetName()) { return; };
    if !this.IsHidden(c) { ArrayPush(this.hiddenParts, c); };
    if c.IsEnabled() { c.Toggle(false); };
  }

  // W15 (QA W14 6): the game turns every piece back on when it remounts the puppet; switched-off parts go off again
  // on the very next frame instead of 7 frames later.
  // W20 (audit): the game may reuse a component it once drew for a removed piece when a piece of the same family is
  // worn; held off by identity it would never show. While slots are being dressed, a held part the game turns back
  // on and whose name a dressed record names is released (measured as that piece).
  private func KeepHidden() -> Void {
    let open = this.OpenSlots();
    let h = ArraySize(this.hiddenParts) - 1;
    while h >= 0 {
      let part = this.hiddenParts[h];
      if !IsDefined(part) { ArrayErase(this.hiddenParts, h); } else {
        if part.IsEnabled() {
          let release = false;
          for s in open {
            if this.NameMatches(this.PieceNames(this.desired[s]), part.GetName()) { release = true; };
          };
          if release {
            ArrayErase(this.hiddenParts, h);
            this.operations += "release\t" + NameToString(part.GetName()) + "\n";
          } else { part.Toggle(false); };
        };
      };
      h -= 1;
    };
  }

  // Meshes of the editor's own underwear (UnderwearTop/UnderwearBottom items): drawn with the clothes, never a loose
  // piece and never switched off here (QA W14 4 and 5: the panties went off and the character stayed naked).
  private func IsUnderwear(raw: CName) -> Bool {
    let lower = StrLower(NameToString(raw));
    if StrContains(lower, "panties") || StrContains(lower, "underwear") || StrContains(lower, "__bra") { return true; };
    let parts = StrSplit(lower, "_");
    let code = ArraySize(parts) >= 2 ? parts[0] + "_" + parts[1] : lower;
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    for slot in [t"AttachmentSlots.UnderwearTop", t"AttachmentSlots.UnderwearBottom"] {
      let obj = ts.GetItemInSlot(this.puppet, slot);
      if IsDefined(obj) {
        let rec = TweakDBInterface.GetItemRecord(ItemID.GetTDBID(obj.GetItemID()));
        if IsDefined(rec) && (StrBeginsWith(StrLower(NameToString(rec.AppearanceName())), code) || this.NameMatches(this.PieceNames(rec.GetID()), raw)) { return true; };
      };
    };
    return false;
  }

  // W23 (author 08/10/2026, print: the editor's panties showing through veegee pt26 pants): the game hides the
  // player's underwear under clothes through its equipment system, which the editor puppet does not run, and the
  // pants' tags (hide_LowerAbdomen hide_Thighs hide_Calves, MEDIDO 16:55) hide body parts only. The tab now does it:
  // the bottom (l1) goes off under a legs piece, a whole outfit or a hide_L1/hide_Legs tag; the top (t1) under an
  // inner top, a whole outfit or a hide_T1/hide_Torso/hide_Chest tag. Uncovered, the tab turns its own back on.
  private func Covers(region: Int32) -> Bool {
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let i = 0;
    while i < ArraySize(this.slots) {
      let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
      if IsDefined(obj) {
        let id = ItemID.GetTDBID(obj.GetItemID());
        let rec = TweakDBInterface.GetItemRecord(id);
        if NPVWardrobeCatalog.Category(id) == region { return true; };
        if IsDefined(rec) && IsDefined(rec.ItemType()) && Equals(rec.ItemType().Type(), gamedataItemType.Clo_Outfit) { return true; };
        let tags = ts.GetVisualTagsByItemID(obj.GetItemID(), this.puppet);
        if region == 4 && (ArrayContains(tags, n"hide_L1") || ArrayContains(tags, n"hide_Legs")) { return true; };
        if region == 2 && (ArrayContains(tags, n"hide_T1") || ArrayContains(tags, n"hide_Torso") || ArrayContains(tags, n"hide_Chest")) { return true; };
      };
      i += 1;
    };
    return false;
  }

  private func IsUnderwearOff(c: ref<IComponent>) -> Bool {
    for part in this.underwearOff {
      if IsDefined(part) && part == c { return true; };
    };
    return false;
  }

  private func SyncUnderwear() -> Void {
    this.legsCovered = this.Covers(4);
    this.torsoCovered = this.Covers(2);
    for c in this.puppet.GetComponents() {
      if NPVWardrobeView.GeneratedPiece(c) && this.IsUnderwear(c.GetName()) {
        let region = NPVWardrobeView.DrawnCategory(c.GetName());
        if region == 2 || region == 4 {
          let covered = region == 4 ? this.legsCovered : this.torsoCovered;
          if covered {
            if !this.IsUnderwearOff(c) {
              ArrayPush(this.underwearOff, c);
              this.operations += "underwear_off\t" + NameToString(c.GetName()) + "\n";
            };
            if c.IsEnabled() { c.Toggle(false); };
          } else {
            if this.IsUnderwearOff(c) {
              ArrayRemove(this.underwearOff, c);
              this.operations += "underwear_back\t" + NameToString(c.GetName()) + "\n";
              c.Toggle(true);
            } else {
              if !c.IsEnabled() {
                // The game switched it off with nothing covering it (QA W14 5): it comes back.
                c.Toggle(true);
                this.operations += "underwear_back\t" + NameToString(c.GetName()) + "\n";
              };
            };
          };
        };
      };
    };
  }

  // Every frame: the game turns everything back on when it remounts the puppet.
  private func KeepUnderwear() -> Void {
    let h = ArraySize(this.underwearOff) - 1;
    while h >= 0 {
      let part = this.underwearOff[h];
      if !IsDefined(part) { ArrayErase(this.underwearOff, h); } else {
        let region = NPVWardrobeView.DrawnCategory(part.GetName());
        if (region == 4 ? this.legsCovered : this.torsoCovered) && part.IsEnabled() { part.Toggle(false); };
      };
      h -= 1;
    };
  }

  // Slots dressed in the open watch window.
  private func OpenSlots() -> array<Int32> {
    let open: array<Int32>;
    if this.watchUntil <= 0 || this.ticks > this.watchUntil { return open; };
    let k = 0;
    while k < ArraySize(this.slots) {
      if this.watched[k] && TDBID.IsValid(this.desired[k]) { ArrayPush(open, k); };
      k += 1;
    };
    return open;
  }

  // Pieces that turned on after a slot was dressed belong to it. W20 (audit 08/10/2026): an outfit, TIRAR TUDO + wear,
  // or the look restored on a rebuilt puppet dress several slots in one burst; W15-W19 credited every new piece to
  // the LAST slot, so taking that one off switched the others off. With several slots open, a piece goes to the slot
  // whose record names it; one nobody's name matches stays unmeasured (the name rules of OwnerSlot decide).
  private func MeasureOwners() -> Void {
    let open = this.OpenSlots();
    if ArraySize(open) == 0 { return; };
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    for c in this.puppet.GetComponents() {
      if NPVWardrobeView.GeneratedPiece(c) && c.IsEnabled() && !ArrayContains(this.beforeWear, c.GetName()) && !this.IsHidden(c) && !this.IsUnderwear(c.GetName()) {
        let owner = -1;
        if ArraySize(open) == 1 { owner = open[0]; } else {
          for s in open {
            if owner < 0 && this.NameMatches(this.PieceNames(this.desired[s]), c.GetName()) { owner = s; };
          };
        };
        if owner >= 0 {
          let m = ArrayFindFirst(this.ownNames, c.GetName());
          if m < 0 { ArrayPush(this.ownNames, c.GetName()); ArrayPush(this.ownSlots, owner); }
          else {
            // A piece another worn slot already owns keeps its owner.
            let held = this.ownSlots[m];
            if held != owner && (held < 0 || held >= ArraySize(this.slots) || !IsDefined(ts.GetItemInSlot(this.puppet, this.slots[held])) || ArrayContains(open, held)) {
              this.ownSlots[m] = owner;
            };
          };
        };
      };
    };
  }

  // Drawn pieces; the ones removed in this tab are switched off again if the game shows them.
  private func ReadDrawn() -> Bool {
    let stamp = "";
    ArrayClear(this.drawnNames);
    for c in this.puppet.GetComponents() {
      if NPVWardrobeView.GeneratedPiece(c) && !StrContains(StrLower(NameToString(c.GetName())), "shadow") && !this.IsUnderwear(c.GetName()) {
        if this.IsHidden(c) {
          if c.IsEnabled() { c.Toggle(false); };
        } else {
          if c.IsEnabled() && !ArrayContains(this.drawnNames, c.GetName()) {
            ArrayPush(this.drawnNames, c.GetName());
            stamp += NameToString(c.GetName()) + ";";
          };
        };
      };
    };
    if Equals(stamp, this.drawnStamp) { return false; };
    this.drawnStamp = stamp;
    return true;
  }

  // Switch off a drawn piece and its shadow mesh (same appearance, "shadow" in the name, same category).
  private func HideDrawn(name: CName) -> Void {
    let category = NPVWardrobeView.DrawnCategory(name);
    let others = 0;
    for other in this.drawnNames {
      if NotEquals(other, name) && NPVWardrobeView.DrawnCategory(other) == category { others += 1; };
    };
    for c in this.puppet.GetComponents() {
      if NPVWardrobeView.GeneratedPiece(c) {
        let shadow = StrContains(StrLower(NameToString(c.GetName())), "shadow")
          && NPVWardrobeView.DrawnCategory(c.GetName()) == category && others == 0;
        if Equals(c.GetName(), name) || shadow { this.HidePart(c); };
      };
    };
    NPVMakerSession.GetInstance().wardrobePreviewTouched = true;
  }

  // Every mesh component of the puppet: generated (worn piece) or not (body, head, hair), enabled, chunk mask.
  private func ReadBody() -> Void {
    let lines = "";
    let seen: array<String>;
    for c in this.puppet.GetComponents() {
      let skinned = c as entSkinnedMeshComponent;
      let morph = c as entMorphTargetSkinnedMeshComponent;
      let mesh = c as MeshComponent;
      let chunk: Uint64;
      let look: CName;
      let path = "";
      if IsDefined(skinned) { chunk = skinned.chunkMask; look = skinned.meshAppearance; path = ResRef.ToString(ResourceAsyncRef.GetPath(skinned.mesh)); }
      else if IsDefined(morph) { chunk = morph.chunkMask; look = morph.meshAppearance; path = ResRef.ToString(ResourceAsyncRef.GetPath(morph.morphResource)); }
      else if IsDefined(mesh) { chunk = mesh.chunkMask; look = mesh.meshAppearance; path = ResRef.ToString(ResourceAsyncRef.GetPath(mesh.mesh)); };
      if IsDefined(skinned) || IsDefined(morph) || IsDefined(mesh) {
        let key = NameToString(c.GetName()) + "@" + ResRef.ToString(c.appearancePath);
        let twin = 0;
        while ArrayContains(seen, key + (twin > 0 ? "#" + ToString(twin) : "")) { twin += 1; };
        if twin > 0 { key += "#" + ToString(twin); };
        let state = (NPVWardrobeView.GeneratedPiece(c) ? "piece" : "own") + "\t" + ToString(c.IsEnabled()) + "\t" + ToString(chunk)
          + "\t" + NameToString(look) + "\t" + path;
        ArrayPush(seen, key);
        let k = ArrayFindFirst(this.bodyNames, key);
        if k < 0 {
          ArrayPush(this.bodyNames, key); ArrayPush(this.bodyStates, state);
          lines += "add\t" + key + "\t" + state + "\n";
        } else {
          if NotEquals(this.bodyStates[k], state) {
            lines += "change\t" + key + "\t" + this.bodyStates[k] + "\t->\t" + state + "\n";
            this.bodyStates[k] = state;
          };
        };
      };
    };
    let k = ArraySize(this.bodyNames) - 1;
    while k >= 0 {
      if !ArrayContains(seen, this.bodyNames[k]) {
        lines += "gone\t" + this.bodyNames[k] + "\t" + this.bodyStates[k] + "\n";
        ArrayErase(this.bodyNames, k); ArrayErase(this.bodyStates, k);
      };
      k -= 1;
    };
    if StrLen(lines) == 0 || StrLen(this.bodyLog) > 400000 { return; };
    this.bodyLog += "step\t" + ToString(this.ticks) + "\t" + this.lastAction + "\n" + lines;
    NPVFiles.Write(NPVWardrobeView.File("-body.tsv"), "probe\t" + NPVWardrobeView.Label() + "\nvisual_runtime\tunverified\n" + this.bodyLog + "end\t1\n");
  }

  // Readback of every tracked slot: the single source for marks, tabs and WEARING.
  private func ReadWorn() -> Bool {
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let stamp = "";
    ArrayClear(this.worn);
    let i = 0;
    while i < ArraySize(this.slots) {
      let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
      if IsDefined(obj) && TDBID.IsValid(ItemID.GetTDBID(obj.GetItemID())) {
        ArrayPush(this.worn, ItemID.GetTDBID(obj.GetItemID()));
        stamp += TDBID.ToStringDEBUG(ItemID.GetTDBID(obj.GetItemID())) + ";";
      };
      if this.changed[i] && TDBID.IsValid(this.desired[i]) && !ArrayContains(this.worn, this.desired[i]) {
        ArrayPush(this.worn, this.desired[i]);
        stamp += TDBID.ToStringDEBUG(this.desired[i]) + "?;";
      };
      i += 1;
    };
    if Equals(stamp, this.wornStamp) { return false; };
    this.wornStamp = stamp;
    return true;
  }

  public func Tick() -> Void {
    this.ticks += 1;
    if this.Valid() { this.KeepHidden(); this.KeepUnderwear(); this.ProcessDrops(); };
    if !this.open {
      // Panel closed, outfit on: keep refit and body coverage as the capture will read them.
      if this.ticks % 7 != 0 || !this.Valid() { return; };
      this.fit.Select(this.RefitValue());
      if this.fit.revision != this.fitRevision {
        let r = 0;
        while r < ArraySize(this.slots) {
          if this.changed[r] && TDBID.IsValid(this.desired[r]) { this.Attach(r); };
          r += 1;
        };
        this.fitRevision = this.fit.revision;
      };
      this.fit.Apply(this.slots);
      if this.ReadWorn() { this.SyncLook(); };
      this.ResolvePending();
      this.SyncUnderwear();
      this.ReadDrawn();
      return;
    };
    this.catalog.Step();
    if !this.favoritesLoaded && NPVFiles.Ready() {
      this.favorites = NPVFiles.Values(NPVFiles.Rows(NPVFiles.Read("wardrobe-favorites.txt")), "favorite");
      this.favoritesLoaded = true;
      this.Render();
    };
    if this.ticks % 7 == 0 {
      let query = StrLower(this.search.GetText());
      if NotEquals(query, this.query) || ArraySize(this.catalog.entries) != this.lastCatalogSize || !Equals(this.catalog.done, this.lastCatalogDone) {
        if NotEquals(query, this.query) {
          this.offset = 0;
          // Typing searches every category; WEARING would hide the results.
          if StrLen(query) > 0 && this.mode == 2 { this.mode = 0; };
        };
        this.query = query;
        this.RefreshTabs();
        this.Render();
      };
    };
    let s = NPVMakerSession.GetInstance();
    if !IsDefined(s) || !s.active || !IsDefined(s.system) { return; };
    let host = s.system.GetPuppetPreviewGameController();
    if !IsDefined(host) || host.GetGamePuppet() != this.puppet || this.puppet == GetPlayer(GetGameInstance()) {
      this.Say(NPVWardrobeView.Text("O personagem foi recriado pelo editor. Feche ROUPAS e abra de novo.", "The editor rebuilt the character. Close WARDROBE and open it again.", "El editor recreo el personaje. Cierra ROPA y vuelve a abrirla."));
      return;
    };
    // ACU/native focus can request the head camera while this tab is open.
    // Reassert the native full-body camera at the low-frequency UI tick.
    this.cameraTicks += 1;
    if this.cameraTicks % 7 == 0 { this.menu.NPVWardrobeCamera(true); };
    if this.ticks % 7 != 0 { return; };
    this.fit.Select(this.RefitValue());
    if this.fit.revision != this.fitRevision {
      let k = 0;
      while k < ArraySize(this.slots) {
        if this.changed[k] && TDBID.IsValid(this.desired[k]) { this.Attach(k); };
        k += 1;
      };
      this.fitRevision = this.fit.revision;
      this.RefreshRefit();
    };
    this.fit.Apply(this.slots);
    let rebuilt = (this.hadMarker && !IsDefined(this.marker))
      || (!this.hadMarker && IsDefined(this.BodyMarker()));
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let missing = false;
    let lines = "probe\t" + NPVWardrobeView.Label() + "\nvisual_runtime\tunverified\n";
    let i = 0;
    while i < ArraySize(this.slots) {
      let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
      let actual: ItemID;
      if IsDefined(obj) { actual = obj.GetItemID(); };
      let matches = Equals(ItemID.GetTDBID(actual), this.desired[i]);
      if this.changed[i] && TDBID.IsValid(this.desired[i]) && (rebuilt || (!matches && !this.PieceMesh(i))) { missing = true; };
      lines += "slot\t" + TDBID.ToStringDEBUG(this.slots[i]) + "\t" + TDBID.ToStringDEBUG(this.desired[i]) + "\t" + TDBID.ToStringDEBUG(ItemID.GetTDBID(actual)) + "\t" + (matches ? "readback_match" : "readback_mismatch") + "\n";
      if IsDefined(obj) {
        let tags = "";
        for tag in ts.GetVisualTags(obj) { tags += NameToString(tag) + " "; };
        tags += "| ";
        for tag in ts.GetVisualTagsByItemID(obj.GetItemID(), this.puppet) { tags += NameToString(tag) + " "; };
        lines += "tags\t" + TDBID.ToStringDEBUG(this.slots[i]) + "\t" + tags + "\n";
      };
      i += 1;
    };
    if this.watchUntil > 0 && this.ticks <= this.watchUntil && missing && this.retries < 3 {
      this.retries += 1;
      i = 0;
      while i < ArraySize(this.slots) {
        if this.changed[i] && TDBID.IsValid(this.desired[i]) && (rebuilt || (this.watched[i] && !ts.HasItemInSlot(this.puppet, this.slots[i], this.trial[i]) && !this.PieceMesh(i))) { this.Attach(i); };
        i += 1;
      };
      this.RememberBody();
    };
    if this.watchUntil > 0 && this.ticks > this.watchUntil {
      this.watchUntil = 0;
      let refused = false;
      i = 0;
      while i < ArraySize(this.slots) {
        if this.watched[i] && TDBID.IsValid(this.desired[i]) && !ts.HasItemInSlot(this.puppet, this.slots[i], this.trial[i]) && !this.PieceMesh(i) {
          this.operations += "refused\t" + TDBID.ToStringDEBUG(this.desired[i]) + "\tslot=" + TDBID.ToStringDEBUG(this.slots[i]) + "\n";
          this.Drop(ts.CreatePreviewItemID(ItemID.FromTDBID(this.desired[i])));
          this.desired[i] = TDBID.None();
          let empty: ItemID;
          this.trial[i] = empty;
          refused = true;
        };
        this.watched[i] = false;
        i += 1;
      };
      if refused {
        this.Say(NPVWardrobeView.Text("O jogo nao aceitou " + this.watchName + " neste personagem. Tente outra peca ou troque o CORPO DAS ROUPAS.", "The game did not accept " + this.watchName + " on this character. Try another piece or change CLOTHES BODY.", "El juego no acepto " + this.watchName + " en este personaje. Prueba otra prenda o cambia CUERPO DE LA ROPA."));
      };
    };
    let diagnostic = lines + "retries\t" + ToString(this.retries) + "\nrefit\t" + this.RefitValue() + "\tresolved=" + this.fit.body + "\tready=" + ToString(this.fit.hookReady) + "\npuppet_record\t" + TDBID.ToStringDEBUG(this.puppet.GetRecordID()) + "\n";
    if NotEquals(diagnostic, this.lastDiagnostic) {
      this.lastDiagnostic = diagnostic;
      NPVFiles.Write(NPVWardrobeView.File(".tsv"), diagnostic + this.operations + "end\t1\n");
    };
    this.MeasureOwners();
    this.ResolvePending();
    this.SyncUnderwear();
    this.ReadBody();
    let drawnChanged = this.ReadDrawn();
    if this.ReadWorn() || drawnChanged {
      this.SyncLook();
      this.RefreshTabs();
      this.Render();
    };
  }

  public func Close() -> Void {
    this.watchUntil = 0;
    let s = NPVMakerSession.GetInstance();
    this.open = false;
    if s.wardrobe == this { s.wardrobe = null; };
    this.fit.Close();
    this.menu.NPVWardrobeCamera(false);
    // Restore only the captured preview, never a replacement puppet or the player.
    let ts = GameInstance.GetTransactionSystem(GetGameInstance());
    let restored = false;
    if IsDefined(this.puppet) && this.puppet != GetPlayer(GetGameInstance()) && IsDefined(ts) {
      restored = true;
      let i = 0;
      while i < ArraySize(this.slots) {
        if this.changed[i] {
          ts.RemoveItemFromSlot(this.puppet, this.slots[i], true);
          if ItemID.IsValid(this.originals[i]) {
            if !ts.AddItemToSlot(this.puppet, this.slots[i], this.originals[i]) {
              ts.AddItemToSlot(this.puppet, this.slots[i], this.originals[i], true);
            };
          };
          let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
          let actual: ItemID;
          if IsDefined(obj) { actual = obj.GetItemID(); };
          restored = restored && Equals(ItemID.GetTDBID(actual), ItemID.GetTDBID(this.originals[i]));
        };
        i += 1;
      };
      for id in this.given { ts.RemoveItem(this.puppet, id, 1); };
    };
    s.wardrobePreviewActive = false;
    ModLog(n"NPVMaker", NPVWardrobeView.Label() + " ended: original slot readback=" + (restored ? "match" : "mismatch"));
    NPVFiles.Write(NPVWardrobeView.File("-close.tsv"), "probe\t" + NPVWardrobeView.Label() + "\nrestored_readback\t" + (restored ? "match" : "mismatch") + "\nvisual_runtime\tunverified\nend\t1\n");
    if IsDefined(this.root) { this.menu.GetRootCompoundWidget().RemoveChild(this.root); };
    this.root = null;
  }

  private func Area(i: Int32) -> gamedataEquipmentArea {
    switch i {
      case 0: return gamedataEquipmentArea.Head;
      case 1: return gamedataEquipmentArea.Face;
      case 2: return gamedataEquipmentArea.InnerChest;
      case 3: return gamedataEquipmentArea.OuterChest;
      case 4: return gamedataEquipmentArea.Legs;
      case 5: return gamedataEquipmentArea.Feet;
    };
    return gamedataEquipmentArea.Outfit;
  }

  private func Male() -> Bool {
    let s = NPVMakerSession.GetInstance();
    return IsDefined(s) && IsDefined(s.system) && IsDefined(s.system.GetState()) && s.system.GetState().IsBodyGenderMale();
  }

  // Inventory icon of the record (UIIcon.<IconPath>, or the game's resolver), as
  // the UI10 thumbnails do: atlas and part straight from the UIIcon record.
  private func ItemIcon(id: TweakDBID, out atlas: ResRef, out part: CName) -> Bool {
    let rec = TweakDBInterface.GetItemRecord(id);
    if !IsDefined(rec) { return false; };
    let icon: TweakDBID;
    if StrLen(rec.IconPath()) > 0 { icon = TDBID.Create("UIIcon." + rec.IconPath()); } else {
      let resolver = IconsNameResolver.GetIconsNameResolver();
      if IsDefined(resolver) { icon = resolver.TranslateItemToIconTweak(id, this.Male()); };
    };
    return this.IconRecord(icon, atlas, part);
  }

  private func ShadowIcon(category: Int32, out atlas: ResRef, out part: CName) -> Bool {
    return this.IconRecord(TDBID.Create(NameToString(UIItemsHelper.GetSlotShadowIcon(this.Area(category)))), atlas, part);
  }

  private func IconRecord(icon: TweakDBID, out atlas: ResRef, out part: CName) -> Bool {
    if !TDBID.IsValid(icon) { return false; };
    let record = TweakDBInterface.GetUIIconRecord(icon);
    if !IsDefined(record) { return false; };
    atlas = record.AtlasResourcePath();
    part = record.AtlasPartName();
    return ResRef.IsValid(atlas) && IsNameValid(part);
  }

  private func Label(parent: ref<inkCompoundWidget>, text: String, size: Int32, strong: Bool, width: Float) -> ref<inkText> {
    let label = new inkText();
    label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    label.SetFontStyle(strong ? n"Semi-Bold" : n"Medium");
    label.SetFontSize(size);
    label.SetTintColor(strong ? ThemeColors.Bittersweet() : ThemeColors.ElectricBlue());
    label.SetWrapping(true, width);
    label.SetFitToContent(true);
    label.SetInteractive(false);
    label.SetText(text);
    label.Reparent(parent);
    return label;
  }

  private func Button(parent: ref<inkCompoundWidget>, text: String, name: CName, width: Float, icon: CName, onlyIcon: Bool) -> ref<NPVIconButton> {
    let button = NPVIconButton.Make();
    button.SetName(name);
    button.SetText(text);
    button.SetIcon(icon, onlyIcon);
    button.SetWidth(width);
    button.SetFlipped(true);
    button.ToggleAnimations(true);
    button.ToggleSounds(true);
    button.Reparent(parent, this.menu);
    button.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
    button.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
    return button;
  }

  private func Row(parent: ref<inkCompoundWidget>, gap: Float) -> ref<inkHorizontalPanel> {
    let row = new inkHorizontalPanel();
    row.SetChildMargin(new inkMargin(0.0, 0.0, gap, 0.0));
    row.SetFitToContent(true);
    row.Reparent(parent);
    return row;
  }

  // Same surface as the approved UI10 picker: dark shade and native sorting frame.
  private func Build() -> Void {
    this.root = new inkCanvas();
    this.root.SetName(n"NPVWardrobeView");
    this.root.SetAnchor(inkEAnchor.TopRight);
    this.root.SetAnchorPoint(new Vector2(1.0, 0.0));
    this.root.SetMargin(new inkMargin(0.0, 270.0, 330.0, 0.0));
    this.root.SetSize(1000.0, 1470.0);
    this.root.SetInteractive(true);
    this.root.Reparent(this.menu.GetRootCompoundWidget());
    let shade = new inkRectangle();
    shade.SetAnchor(inkEAnchor.Fill);
    shade.SetTintColor(new HDRColor(0.045, 0.009, 0.018, 1.0));
    shade.SetOpacity(0.98);
    shade.SetInteractive(true);
    shade.Reparent(this.root);
    let frame = new inkImage();
    frame.SetAtlasResource(r"base\\gameplay\\gui\\common\\shapes\\atlas_shapes_sync.inkatlas");
    frame.SetTexturePart(n"sorting_fg");
    frame.SetNineSliceScale(true);
    frame.SetNineSliceGrid(new inkMargin(50.0, 30.0, 100.0, 30.0));
    frame.SetAnchor(inkEAnchor.Fill);
    frame.SetTintColor(ThemeColors.Bittersweet());
    frame.SetInteractive(false);
    frame.Reparent(this.root);

    this.Label(this.root, NPVWardrobeView.Text("ROUPAS", "WARDROBE", "ROPA"), 46, true, 440.0).SetMargin(new inkMargin(24.0, 16.0, 0.0, 0.0));
    let top = this.Row(this.root, 12.0);
    top.SetMargin(new inkMargin(484.0, 16.0, 0.0, 0.0));
    this.clearButton = this.Button(top, NPVWardrobeView.Text("TIRAR TUDO", "REMOVE ALL", "QUITAR TODO"), n"npvw_clear", 270.0, n"", false);
    this.Button(top, NPVWardrobeView.Text("FECHAR", "CLOSE", "CERRAR"), n"npvw_close", 210.0, n"close", false);
    this.Label(this.root, NPVWardrobeView.Text("O que o personagem estiver vestindo vai para o NPV quando voce salvar ou criar. Fechar mantem a roupa.", "What the character wears goes to the NPV when you save or create it. Closing keeps the clothes on.", "Lo que lleve puesto el personaje pasa al NPV al guardar o crearlo. Cerrar mantiene la ropa."), 26, false, 936.0).SetMargin(new inkMargin(24.0, 84.0, 0.0, 0.0));

    let tabRow = this.Row(this.root, 8.0);
    tabRow.SetMargin(new inkMargin(24.0, 156.0, 0.0, 0.0));
    let c = 0;
    while c < 7 {
      let tab = NPVWardrobeTab.Make();
      tab.SetName(StringToName("npvw_tab_" + ToString(c)));
      tab.SetText(NPVWardrobeCatalog.CategoryLabel(c));
      tab.SetFlipped(true);
      tab.ToggleAnimations(true);
      tab.ToggleSounds(true);
      tab.Reparent(tabRow, this.menu);
      tab.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
      tab.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
      ArrayPush(this.tabs, tab);
      c += 1;
    };

    NPVIcons.Add(this.root, n"search", 30.0).SetMargin(new inkMargin(24.0, 304.0, 0.0, 0.0));
    this.Label(this.root, NPVWardrobeView.Text("BUSCAR EM TODAS AS ROUPAS", "SEARCH ALL CLOTHES", "BUSCAR EN TODA LA ROPA"), 28, false, 880.0).SetMargin(new inkMargin(68.0, 304.0, 0.0, 0.0));
    let search = HubTextInput.Create();
    search.SetWidth(936.0);
    search.SetMaxLength(120);
    search.Reparent(this.root, this.menu);
    search.GetRootWidget().SetMargin(new inkMargin(24.0, 342.0, 0.0, 0.0));
    this.search = search;

    let chipRow = this.Row(this.root, 12.0);
    chipRow.SetMargin(new inkMargin(24.0, 424.0, 0.0, 0.0));
    let labels: array<String> = [
      NPVWardrobeView.Text("TODAS", "ALL", "TODAS"),
      NPVWardrobeView.Text("FAVORITAS", "FAVORITES", "FAVORITAS"),
      NPVWardrobeView.Text("VESTINDO", "WEARING", "PUESTA"),
      "OUTFITS",
      NPVWardrobeView.Text("ORIGEM: JOGO", "SOURCE: GAME", "ORIGEN: JUEGO")];
    let widths: array<Float> = [140.0, 180.0, 180.0, 170.0, 220.0];
    let k = 0;
    while k < 5 {
      let chip = NPVWardrobeChip.Make();
      chip.SetName(StringToName("npvw_chip_" + ToString(k)));
      chip.SetText(labels[k]);
      chip.SetWidth(widths[k]);
      chip.SetFlipped(true);
      chip.ToggleAnimations(true);
      chip.ToggleSounds(true);
      chip.Reparent(chipRow, this.menu);
      chip.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
      chip.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
      ArrayPush(this.chips, chip);
      k += 1;
    };

    this.countLabel = this.Label(this.root, "", 30, false, 936.0);
    this.countLabel.SetMargin(new inkMargin(24.0, 502.0, 0.0, 0.0));
    this.rows = new inkVerticalPanel();
    this.rows.SetChildMargin(new inkMargin(0.0, 0.0, 0.0, 4.0));
    this.rows.SetFitToContent(true);
    this.rows.SetMargin(new inkMargin(24.0, 548.0, 0.0, 0.0));
    this.rows.Reparent(this.root);
    this.scrollTrack = new inkRectangle();
    this.scrollTrack.SetMargin(new inkMargin(970.0, 548.0, 0.0, 0.0));
    this.scrollTrack.SetSize(3.0, NPVWardrobeView.Pitch() * Cast<Float>(NPVWardrobeView.Rows()));
    this.scrollTrack.SetTintColor(ThemeColors.RedOxide());
    this.scrollTrack.Reparent(this.root);
    this.scrollThumb = new inkRectangle();
    this.scrollThumb.SetTintColor(ThemeColors.ElectricBlue());
    this.scrollThumb.SetInteractive(false);
    this.scrollThumb.Reparent(this.root);
    this.trackHit = new inkRectangle();
    this.trackHit.SetMargin(new inkMargin(952.0, 548.0, 0.0, 0.0));
    this.trackHit.SetSize(36.0, NPVWardrobeView.Pitch() * Cast<Float>(NPVWardrobeView.Rows()));
    this.trackHit.SetOpacity(0.01);
    this.trackHit.SetInteractive(true);
    this.trackHit.RegisterToCallback(n"OnPress", this.menu, n"NPVOnScrollPress");
    this.trackHit.RegisterToCallback(n"OnRelease", this.menu, n"NPVOnScrollRelease");
    this.trackHit.Reparent(this.root);

    let footer = this.Row(this.root, 12.0);
    footer.SetMargin(new inkMargin(24.0, 1232.0, 0.0, 0.0));
    this.previousButton = this.Button(footer, "^", n"npvw_previous", 90.0, n"up", true);
    this.pageLabel = this.Label(footer, "", 28, false, 732.0);
    this.pageLabel.SetSize(732.0, 64.0);
    this.pageLabel.SetFitToContent(false);
    this.pageLabel.SetHorizontalAlignment(textHorizontalAlignment.Center);
    this.pageLabel.SetVerticalAlignment(textVerticalAlignment.Center);
    this.nextButton = this.Button(footer, "v", n"npvw_next", 90.0, n"down", true);

    // Wardrobe+ v121 refit as a visible stepper instead of a typed body name.
    let refit = this.Row(this.root, 12.0);
    refit.SetMargin(new inkMargin(24.0, 1310.0, 0.0, 0.0));
    this.Button(refit, "<", n"npvw_refit_prev", 90.0, n"", false);
    this.refitLabel = this.Label(refit, "", 28, true, 732.0);
    this.refitLabel.SetSize(732.0, 64.0);
    this.refitLabel.SetFitToContent(false);
    this.refitLabel.SetHorizontalAlignment(textHorizontalAlignment.Center);
    this.refitLabel.SetVerticalAlignment(textVerticalAlignment.Center);
    this.Button(refit, ">", n"npvw_refit_next", 90.0, n"", false);

    this.status = this.Label(this.root, "", 26, false, 936.0);
    this.status.SetMargin(new inkMargin(24.0, 1390.0, 0.0, 0.0));
    this.Say(NPVWardrobeView.Text("Clique numa peca para vestir. Clique de novo para tirar.", "Click a piece to put it on. Click it again to take it off.", "Pulsa una prenda para ponerla. Pulsa otra vez para quitarla."));
    this.RefreshRefit();
    this.BindWheel(this.root);
  }

  private func Say(text: String) -> Void {
    if IsDefined(this.status) { this.status.SetText(text); };
  }

  private func RefitOptions() -> array<String> {
    if this.Male() { return ["auto", "basebody", "atlas", "adonis"]; };
    return ["auto", "basebody", "ebb", "ebbp", "ebbrb", "ebbprb", "rb", "angel", "lush", "vhd", "elegy", "flat"];
  }

  private func RefitValue() -> String {
    let options = this.RefitOptions();
    if this.refitIndex < 0 || this.refitIndex >= ArraySize(options) { return "auto"; };
    return options[this.refitIndex];
  }

  private func RefitName(value: String) -> String {
    if StrLen(value) == 0 { return NPVWardrobeView.Text("O DO JOGO", "GAME DEFAULT", "EL DEL JUEGO"); };
    if Equals(StrLower(value), "basebody") { return "VANILLA"; };
    return StrUpper(value);
  }

  private func RefreshRefit() -> Void {
    if !IsDefined(this.refitLabel) { return; };
    let value = this.RefitValue();
    let shown = Equals(value, "auto") ? "AUTO (" + this.RefitName(this.fit.body) + ")" : this.RefitName(value);
    this.refitLabel.SetText(NPVWardrobeView.Text("CORPO DAS ROUPAS: ", "CLOTHES BODY: ", "CUERPO DE LA ROPA: ") + shown);
  }

  private func RefreshTabs() -> Void {
    let c = 0;
    while c < ArraySize(this.tabs) {
      let found: TweakDBID;
      for id in this.worn {
        if NPVWardrobeCatalog.Category(id) == c { found = id; };
      };
      if this.lastEquippedSlot >= 0 && this.lastEquippedSlot < ArraySize(this.desired)
        && ArrayContains(this.worn, this.desired[this.lastEquippedSlot])
        && NPVWardrobeCatalog.Category(this.desired[this.lastEquippedSlot]) == c {
        found = this.desired[this.lastEquippedSlot];
      };
      let count = 0;
      for wornId in this.worn {
        if NPVWardrobeCatalog.Category(wornId) == c { count += 1; };
      };
      let atlas: ResRef;
      let part: CName;
      let worn = TDBID.IsValid(found) && this.ItemIcon(found, atlas, part);
      if !worn { this.ShadowIcon(c, atlas, part); };
      this.tabs[c].SetText(NPVWardrobeCatalog.CategoryLabel(c) + (count > 0 ? " " + ToString(count) : ""));
      this.tabs[c].Paint(atlas, part, this.mode == 0 && StrLen(this.query) == 0 && c == this.category, TDBID.IsValid(found) || count > 0);
      c += 1;
    };
    let k = 0;
    while k < ArraySize(this.chips) {
      this.chips[k].Mark(k == 4 ? this.source == 2 : k == this.mode);
      k += 1;
    };
    this.chips[2].SetText(NPVWardrobeView.Text("VESTINDO", "WEARING", "PUESTA") + (ArraySize(this.worn) > 0 ? " (" + ToString(ArraySize(this.worn)) + ")" : ""));
    this.clearButton.SetDisabled(!this.AnyChanged() && ArraySize(this.drawnNames) == 0);
    let saved = ArraySize(NPVMakerSession.GetInstance().wardrobeOutfitIds);
    this.chips[3].SetText("OUTFITS" + (saved > 0 ? " (" + ToString(saved) + ")" : ""));
    this.chips[4].SetText(this.source == 2 ? NPVWardrobeView.Text("ORIGEM: MODS", "SOURCE: MODS", "ORIGEN: MODS")
      : NPVWardrobeView.Text("ORIGEM: JOGO", "SOURCE: GAME", "ORIGEN: JUEGO"));
  }

  private func AnyChanged() -> Bool {
    let i = 0;
    while i < ArraySize(this.slots) {
      if this.changed[i] && TDBID.IsValid(this.desired[i]) { return true; };
      i += 1;
    };
    return false;
  }

  private func Matches(entry: ref<NPVWardrobeEntry>) -> Bool {
    if this.mode == 2 && !ArrayContains(this.worn, entry.id) { return false; };
    if this.mode == 1 && !ArrayContains(this.favorites, entry.key) { return false; };
    if this.mode == 0 && StrLen(this.query) == 0 && entry.category != this.category { return false; };
    if StrLen(this.query) > 0 && !StrContains(entry.search, this.query) { return false; };
    if (this.source == 2 && entry.origin != 2) || (this.source != 2 && entry.origin == 2) { return false; };
    return true;
  }

  // Catalog entry of an equipped record, or one built from the record (pieces outside the catalog).
  private func WornEntry(id: TweakDBID) -> ref<NPVWardrobeEntry> {
    for entry in this.catalog.entries {
      if Equals(entry.id, id) { return entry; };
    };
    let e = new NPVWardrobeEntry();
    e.id = id;
    e.key = TDBID.ToStringDEBUG(id);
    let rec = TweakDBInterface.GetItemRecord(id);
    e.name = IsDefined(rec) ? GetLocalizedTextByKey(rec.DisplayName()) : "";
    if StrLen(e.name) == 0 { e.name = e.key; };
    e.category = NPVWardrobeCatalog.Category(id);
    e.origin = NPVMakerWardrobeOrigin(id);
    return e;
  }

  // Meshes the game draws with no equipped item behind them.
  private func LooseCount() -> Int32 {
    let count = 0;
    for name in this.drawnNames {
      if this.OwnerSlot(name) < 0 { count += 1; };
    };
    return count;
  }

  private func Short(text: String, limit: Int32) -> String {
    return StrLen(text) > limit ? StrLeft(text, limit - 3) + "..." : text;
  }

  // Favorites first, then pieces added by mods, then the base game.
  private func Render() -> Void {
    if !IsDefined(this.rows) { return; };
    this.lastCatalogSize = ArraySize(this.catalog.entries);
    this.lastCatalogDone = this.catalog.done;
    ArrayClear(this.filtered);
    if this.mode == 3 {
      // The catalog keeps loading and re-rendering; rebuilding the row would drop what is being typed.
      if this.renameIndex > 0 && IsDefined(this.renameInput) { return; };
      this.RenderOutfits();
      return;
    };
    // W12 (author 08/10/2026): the list shows what is EQUIPPED, by item name and icon. WEARING lists every equipped
    // item; a category tab starts with the equipped items of that category, one click takes them off.
    let view = ToString(this.mode) + "|" + ToString(this.category) + "|" + this.query + "|" + ToString(this.source);
    if NotEquals(view, this.pinnedView) {
      ArrayClear(this.pinned);
      this.pinnedView = view;
      for id in this.worn {
        if this.mode == 2 || (this.mode == 0 && StrLen(this.query) == 0 && NPVWardrobeCatalog.Category(id) == this.category) { ArrayPush(this.pinned, id); };
      };
    } else {
      if this.mode == 2 {
        for id in this.worn {
          if !ArrayContains(this.pinned, id) { ArrayPush(this.pinned, id); };
        };
      };
    };
    for id in this.pinned { ArrayPush(this.filtered, this.WornEntry(id)); };
    if this.mode != 2 {
      let pass = 0;
      while pass < 2 {
        for entry in this.catalog.entries {
          // W17 (QA W16 1): what the worn block on top shows is not repeated below; the block is frozen while the list is
          // open, so leaving it out does not move the rows.
          if this.Matches(entry) && !ArrayContains(this.pinned, entry.id) {
            let rank = ArrayContains(this.favorites, entry.key) ? 0 : 1;
            if rank == pass { ArrayPush(this.filtered, entry); };
          };
        };
        pass += 1;
      };
    };
    let total = ArraySize(this.filtered);
    this.listTotal = total;
    let visible = NPVWardrobeView.Rows();
    this.offset = Max(0, Min(this.offset, total - visible));
    this.rows.RemoveAllChildren();
    ArrayClear(this.cardIDs);
    ArrayClear(this.cardDrawn);
    let j = this.offset;
    while j < total && j < this.offset + visible {
      let entry = this.filtered[j];
      ArrayPush(this.cardIDs, entry.id);
      let line = this.Row(this.rows, 12.0);
      let wornNow = ArrayContains(this.worn, entry.id);
      let favorite = ArrayContains(this.favorites, entry.key);
      let second = NPVWardrobeCatalog.CategoryLabel(entry.category) + "  ·  ";
      if wornNow {
        let slotName = TDBID.ToStringDEBUG(NPVWardrobeCatalog.Placement(entry.id));
        second += NPVWardrobeView.Text("VESTINDO", "WEARING", "PUESTA") + "  ·  " + StrAfterFirst(slotName, ".");
      } else {
        second += (entry.origin == 2 ? "MOD" : NPVWardrobeView.Text("JOGO", "GAME", "JUEGO")) + "  ·  " + this.Short(StrBeginsWith(entry.key, "Items.") ? StrAfterFirst(entry.key, "Items.") : entry.key, 30);
      };
      let row = NPVWardrobeRow.Make();
      row.SetName(StringToName("npvw_row_" + entry.key));
      row.SetText(this.Short(entry.name, 46) + "\n" + second);
      row.SetFlipped(true);
      row.ToggleAnimations(true);
      row.ToggleSounds(true);
      row.Reparent(line, this.menu);
      row.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
      row.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
      row.Mark(wornNow, favorite);
      let atlas: ResRef;
      let part: CName;
      if this.ItemIcon(entry.id, atlas, part) { row.SetIcon(atlas, part, false); }
      else if this.ShadowIcon(entry.category, atlas, part) { row.SetIcon(atlas, part, true); };
      if wornNow {
        this.Button(line, "", StringToName("npvw_off_" + entry.key), 72.0, n"close", true).GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
      } else {
        let star = this.Button(line, "", StringToName("npvw_star_" + entry.key), 72.0, n"", true);
        star.SetFavorite(favorite, this.pageLabel);
        star.SetDisabled(!this.favoritesLoaded);
        star.GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
      };
      this.BindWheel(line);
      j += 1;
    };
    let loose = this.mode == 2 ? this.LooseCount() : 0;
    if loose > 0 && ArraySize(this.cardIDs) < visible {
      let line = this.Row(this.rows, 12.0);
      let row = NPVWardrobeRow.Make();
      row.SetName(n"npvw_loose");
      row.SetText(NPVWardrobeView.Text("LIMPAR PECAS SOLTAS (", "CLEAR LOOSE PIECES (", "QUITAR PIEZAS SUELTAS (") + ToString(loose) + ")\n"
        + NPVWardrobeView.Text("DESENHADAS NO PERSONAGEM SEM ITEM EQUIPADO", "DRAWN ON THE CHARACTER WITH NO ITEM EQUIPPED", "DIBUJADAS EN EL PERSONAJE SIN PRENDA EQUIPADA"));
      row.SetFlipped(true);
      row.ToggleAnimations(true);
      row.ToggleSounds(true);
      row.Reparent(line, this.menu);
      row.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
      row.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
      row.Mark(false, true);
      this.BindWheel(line);
    };
    if total == 0 && loose == 0 {
      let empty = NPVWardrobeView.Text("Nenhuma peca encontrada. Limpe a busca ou troque a ORIGEM.", "No piece found. Clear the search or switch SOURCE.", "Ninguna prenda encontrada. Borra la busqueda o cambia ORIGEN.");
      if !this.catalog.done { empty = NPVWardrobeView.Text("Carregando as roupas instaladas...", "Loading the installed clothes...", "Cargando la ropa instalada..."); }
      else if this.mode == 2 { empty = NPVWardrobeView.Text("Nada vestido ainda. Escolha uma categoria e clique numa peca.", "Nothing on yet. Pick a category and click a piece.", "Nada puesto aun. Elige una categoria y pulsa una prenda."); }
      else if this.mode == 1 && StrLen(this.query) == 0 { empty = NPVWardrobeView.Text("Nenhuma favorita ainda. Clique na estrela de uma peca para guardar.", "No favorites yet. Click a piece's star to keep it.", "Ninguna favorita aun. Pulsa la estrella de una prenda para guardarla."); };
      this.Label(this.rows, empty, 30, false, 936.0);
    };
    this.scrollTrack.SetVisible(total > visible);
    this.scrollThumb.SetVisible(total > visible);
    this.trackHit.SetVisible(total > visible);
    if total > visible {
      let height = NPVWardrobeView.Pitch() * Cast<Float>(visible);
      let thumbHeight = MaxF(32.0, height * Cast<Float>(visible) / Cast<Float>(total));
      this.scrollThumb.SetSize(5.0, thumbHeight);
      this.scrollThumb.SetMargin(new inkMargin(969.0, 548.0 + (height - thumbHeight) * Cast<Float>(this.offset) / Cast<Float>(total - visible), 0.0, 0.0));
    };
    let title = StrLen(this.query) > 0 ? NPVWardrobeView.Text("BUSCA EM TODAS", "SEARCH IN ALL", "BUSQUEDA EN TODAS") : NPVWardrobeCatalog.CategoryLabel(this.category);
    if this.mode == 2 { title = NPVWardrobeView.Text("VESTINDO AGORA", "WEARING NOW", "PUESTA AHORA"); }
    else if this.mode == 1 { title = NPVWardrobeView.Text("FAVORITAS", "FAVORITES", "FAVORITAS"); };
    title += "  ·  " + (this.source == 2 ? "MODS" : NPVWardrobeView.Text("JOGO", "GAME", "JUEGO"));
    this.countLabel.SetText(title + "  ·  " + ToString(total) + NPVWardrobeView.Text(" PECAS", " PIECES", " PRENDAS") + (this.catalog.done ? "" : NPVWardrobeView.Text("  ·  CARREGANDO...", "  ·  LOADING...", "  ·  CARGANDO...")));
    if this.source == 2 && this.catalog.done && ArraySize(this.catalog.entries) > 0 && this.catalog.entries[0].origin == 0 {
      this.countLabel.SetText(NPVWardrobeView.Text("ORIGEM: MODS indisponivel: o plugin NPVMakerWardrobe nao leu os indices do jogo.", "SOURCE: MODS unavailable: the NPVMakerWardrobe plugin did not read the game indexes.", "ORIGEN: MODS no disponible: el plugin NPVMakerWardrobe no leyo los indices del juego."));
    };
    this.pageLabel.SetText(total == 0 ? "" : ToString(this.offset + 1) + " - " + ToString(Min(this.offset + visible, total)) + " / " + ToString(total) + "  ·  " + NPVText.T("ROLE PARA EXPLORAR"));
    this.previousButton.SetDisabled(this.offset == 0);
    this.nextButton.SetDisabled(this.offset + visible >= total);
    let diagnostic = "probe\t" + NPVWardrobeView.Label() + "\ncatalog_entries\t" + ToString(ArraySize(this.catalog.entries)) + "\ncatalog_done\t" + ToString(this.catalog.done) + "\nfiltered\t" + ToString(total) + "\ncategory\t" + ToString(this.category) + "\nmode\t" + ToString(this.mode) + "\nsource\t" + ToString(this.source) + "\n";
    for id in this.cardIDs { diagnostic += "visible\t" + TDBID.ToStringDEBUG(id) + "\n"; };
    if this.catalog.done { NPVFiles.Write(NPVWardrobeView.File("-catalog.tsv"), diagnostic + "end\t1\n"); };
  }

  // WEARING: every piece the puppet draws, one row each, click to take it off.
  private func RenderDrawn() -> Void {
    let total = ArraySize(this.drawnNames);
    this.listTotal = total;
    let visible = NPVWardrobeView.Rows();
    this.offset = Max(0, Min(this.offset, total - visible));
    this.rows.RemoveAllChildren();
    ArrayClear(this.cardIDs);
    ArrayClear(this.cardDrawn);
    let j = this.offset;
    while j < total && j < this.offset + visible {
      let name = this.drawnNames[j];
      let index = ArraySize(this.cardDrawn);
      ArrayPush(this.cardDrawn, name);
      let category = NPVWardrobeView.DrawnCategory(name);
      let line = this.Row(this.rows, 12.0);
      let row = NPVWardrobeRow.Make();
      row.SetName(StringToName("npvw_drawn_" + ToString(index)));
      row.SetText(this.Short(NPVWardrobeView.DrawnLabel(name), 46) + "\n" + NPVWardrobeCatalog.CategoryLabel(category) + "  ·  "
        + NPVWardrobeView.Text("NO PERSONAGEM, CLIQUE PARA TIRAR", "ON THE CHARACTER, CLICK TO TAKE OFF", "EN EL PERSONAJE, PULSA PARA QUITAR"));
      row.SetFlipped(true);
      row.ToggleAnimations(true);
      row.ToggleSounds(true);
      row.Reparent(line, this.menu);
      row.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
      row.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
      row.Mark(true, false);
      let atlas: ResRef;
      let part: CName;
      if this.ShadowIcon(category, atlas, part) { row.SetIcon(atlas, part, false); };
      this.BindWheel(line);
      j += 1;
    };
    if total == 0 {
      this.Label(this.rows, NPVWardrobeView.Text("Nada vestido. Escolha uma categoria e clique numa peca.", "Nothing on. Pick a category and click a piece.", "Nada puesto. Elige una categoria y pulsa una prenda."), 30, false, 936.0);
    };
    this.scrollTrack.SetVisible(total > visible);
    this.scrollThumb.SetVisible(total > visible);
    this.trackHit.SetVisible(total > visible);
    if total > visible {
      let height = NPVWardrobeView.Pitch() * Cast<Float>(visible);
      let thumbHeight = MaxF(32.0, height * Cast<Float>(visible) / Cast<Float>(total));
      this.scrollThumb.SetSize(5.0, thumbHeight);
      this.scrollThumb.SetMargin(new inkMargin(969.0, 548.0 + (height - thumbHeight) * Cast<Float>(this.offset) / Cast<Float>(total - visible), 0.0, 0.0));
    };
    this.countLabel.SetText(NPVWardrobeView.Text("NO PERSONAGEM AGORA", "ON THE CHARACTER NOW", "EN EL PERSONAJE AHORA") + "  ·  " + ToString(total) + NPVWardrobeView.Text(" PECAS", " PIECES", " PRENDAS"));
    this.pageLabel.SetText(total == 0 ? "" : ToString(this.offset + 1) + " - " + ToString(Min(this.offset + visible, total)) + " / " + ToString(total) + "  ·  " + NPVText.T("ROLE PARA EXPLORAR"));
    this.previousButton.SetDisabled(this.offset == 0);
    this.nextButton.SetDisabled(this.offset + visible >= total);
  }

  // Everything off: slot items and every mesh the game still draws for worn items (shadows included).
  private func ClearAll(sweep: Bool) -> Void {
    this.lastAction = "clear_all";
    let i = 0;
    while i < ArraySize(this.slots) {
      let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
      if (this.changed[i] && TDBID.IsValid(this.desired[i])) || IsDefined(ts.GetItemInSlot(this.puppet, this.slots[i])) { this.TakeOff(i); };
      i += 1;
    };
    // Whatever the game still draws without an item a moment later is switched off then.
    this.sweepAll = sweep;
    ArrayClear(this.pendingNames);
    this.pendingUntil = sweep ? this.ticks + 56 : 0;
  }

  // The slot item that draws a piece: same item code as its mesh (h1_011...), else the only item of that category,
  // else a whole-outfit item (one slot, several meshes). -1 when no item draws it.
  private func OwnerSlot(name: CName) -> Int32 {
    let measured = ArrayFindFirst(this.ownNames, name);
    if measured >= 0 {
      let s = this.ownSlots[measured];
      let tsm = GameInstance.GetTransactionSystem(this.puppet.GetGame());
      return s >= 0 && s < ArraySize(this.slots) && IsDefined(tsm.GetItemInSlot(this.puppet, this.slots[s])) ? s : -1;
    };
    let parts = StrSplit(StrLower(NameToString(name)), "_");
    let code = ArraySize(parts) >= 2 ? parts[0] + "_" + parts[1] : StrLower(NameToString(name));
    let category = NPVWardrobeView.DrawnCategory(name);
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let byCode = -1;
    let byCategory = -1;
    let categoryCount = 0;
    let outfit = -1;
    let i = 0;
    while i < ArraySize(this.slots) {
      let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
      if IsDefined(obj) {
        let id = ItemID.GetTDBID(obj.GetItemID());
        let rec = TweakDBInterface.GetItemRecord(id);
        if IsDefined(rec) {
          if StrBeginsWith(StrLower(NameToString(rec.AppearanceName())), code) { byCode = i; };
          if NPVWardrobeCatalog.Category(id) == category { byCategory = i; categoryCount += 1; };
          if IsDefined(rec.ItemType()) && Equals(rec.ItemType().Type(), gamedataItemType.Clo_Outfit) { outfit = i; };
        };
      };
      i += 1;
    };
    if byCode >= 0 { return byCode; };
    if categoryCount == 1 { return byCategory; };
    return outfit;
  }

  private func RemovePiece(name: CName) -> Void {
    let slot = this.OwnerSlot(name);
    if slot < 0 { this.HideDrawn(name); return; };
    this.TakeOff(slot);
    if !ArrayContains(this.pendingNames, name) { ArrayPush(this.pendingNames, name); };
    this.pendingUntil = this.ticks + 56;
  }

  // The entry a row names (W14: rows carry the record key, not their position).
  private func EntryByKey(key: String) -> ref<NPVWardrobeEntry> {
    for entry in this.filtered {
      if Equals(entry.key, key) { return entry; };
    };
    for entry in this.catalog.entries {
      if Equals(entry.key, key) { return entry; };
    };
    for id in this.worn {
      if Equals(TDBID.ToStringDEBUG(id), key) { return this.WornEntry(id); };
    };
    return null;
  }

  private func ResolvePending() -> Void {
    if this.pendingUntil <= 0 || this.ticks < this.pendingUntil { return; };
    this.lastAction = "hide_leftovers\t" + ToString(ArraySize(this.pendingNames)) + (this.sweepAll ? "\tall" : "");
    for c in this.puppet.GetComponents() {
      if NPVWardrobeView.GeneratedPiece(c) && c.IsEnabled()
        && (this.sweepAll || ArrayContains(this.pendingNames, c.GetName())) && this.OwnerSlot(c.GetName()) < 0 {
        this.HidePart(c);
      };
    };
    this.pendingUntil = 0;
    this.sweepAll = false;
    ArrayClear(this.pendingNames);
  }

  // One saved outfit: its pieces and every mesh component the puppet draws now, body masks included.
  private func SnapshotJson(id: String, name: String) -> String {
    let rows = "";
    for c in this.puppet.GetComponents() {
      let row = NPVWardrobeView.ComponentJson(c);
      if StrLen(row) > 0 { rows += (StrLen(rows) > 0 ? ", " : "") + row; };
    };
    return "{\"id\": " + NPVFiles.Json(id) + ", \"name\": " + NPVFiles.Json(name) + ", \"pieces\": [" + this.PiecesJson()
      + "], \"drawn\": [" + rows + "]}";
  }

  private func SaveOutfit() -> Void {
    let s = NPVMakerSession.GetInstance();
    if ArraySize(s.wardrobeOutfitIds) >= 9 {
      this.Say(NPVWardrobeView.Text("Limite de 9 outfits. Apague um para salvar outro.", "Limit of 9 outfits. Delete one to save another.", "Limite de 9 conjuntos. Borra uno para guardar otro."));
      return;
    };
    this.ReadDrawn();
    if ArraySize(this.drawnNames) == 0 {
      this.Say(NPVWardrobeView.Text("Vista alguma roupa antes de salvar um outfit.", "Put some clothes on before saving an outfit.", "Ponte algo de ropa antes de guardar un conjunto."));
      return;
    };
    this.SyncLook();
    s.wardrobeOutfitNext = Max(1, s.wardrobeOutfitNext);
    let id = "outfit_" + ToString(s.wardrobeOutfitNext);
    let name = "Outfit " + ToString(s.wardrobeOutfitNext);
    s.wardrobeOutfitNext += 1;
    let look = "";
    for record in s.wardrobeLook { look += (StrLen(look) > 0 ? ";" : "") + TDBID.ToStringDEBUG(record); };
    ArrayPush(s.wardrobeOutfitIds, id);
    ArrayPush(s.wardrobeOutfitNames, name);
    ArrayPush(s.wardrobeOutfitLooks, look);
    ArrayPush(s.wardrobeOutfitCounts, ArraySize(this.drawnNames));
    ArrayPush(s.wardrobeOutfitJson, this.SnapshotJson(id, name));
    this.Say(NPVWardrobeView.Text(name + " salvo. O NPV ganha uma aparencia para ele (troca pelo NCA e pelo AMM).", name + " saved. The NPV gets an appearance for it (switch it in NCA and AMM).", name + " guardado. El NPV tiene una apariencia para el (cambiala en NCA y AMM)."));
  }

  private func DeleteOutfit(index: Int32) -> Void {
    let s = NPVMakerSession.GetInstance();
    if index < 0 || index >= ArraySize(s.wardrobeOutfitIds) { return; };
    let name = s.wardrobeOutfitNames[index];
    ArrayErase(s.wardrobeOutfitIds, index);
    ArrayErase(s.wardrobeOutfitNames, index);
    ArrayErase(s.wardrobeOutfitLooks, index);
    ArrayErase(s.wardrobeOutfitCounts, index);
    ArrayErase(s.wardrobeOutfitJson, index);
    this.Say(NPVWardrobeView.Text(name + " apagado.", name + " deleted.", name + " borrado."));
  }

  // W24: the new name goes into the session and into the outfit snapshot the save sends (SnapshotJson keeps the id,
  // then the name, then the pieces; a quote inside a name is escaped, so the pieces marker cannot appear in it).
  private func RenameOutfit(index: Int32, raw: String) -> Void {
    let s = NPVMakerSession.GetInstance();
    if index < 0 || index >= ArraySize(s.wardrobeOutfitIds) { return; };
    let name = StrReplaceAll(StrReplaceAll(StrReplaceAll(raw, "\n", " "), "\r", " "), "\t", " ");
    while StrBeginsWith(name, " ") { name = StrAfterFirst(name, " "); };
    while StrEndsWith(name, " ") { name = StrLeft(name, StrLen(name) - 1); };
    if StrLen(name) == 0 {
      this.Say(NPVWardrobeView.Text("O nome do outfit nao pode ficar vazio.", "The outfit name cannot be empty.", "El nombre del conjunto no puede quedar vacio."));
      return;
    };
    if StrLen(name) > 40 { name = StrLeft(name, 40); };
    let old = s.wardrobeOutfitNames[index];
    s.wardrobeOutfitNames[index] = name;
    let marker = ", \"pieces\": [";
    let json = s.wardrobeOutfitJson[index];
    if StrContains(json, marker) {
      s.wardrobeOutfitJson[index] = "{\"id\": " + NPVFiles.Json(s.wardrobeOutfitIds[index]) + ", \"name\": " + NPVFiles.Json(name) + marker + StrAfterFirst(json, marker);
    };
    this.Say(NPVWardrobeView.Text(old + " agora se chama " + name + ".", old + " is now called " + name + ".", old + " ahora se llama " + name + "."));
  }

  private func WearOutfit(index: Int32) -> Void {
    let s = NPVMakerSession.GetInstance();
    if index < 0 || index >= ArraySize(s.wardrobeOutfitIds) || !this.Allowed() { return; };
    this.ClearAll(false);
    for record in StrSplit(s.wardrobeOutfitLooks[index], ";") {
      if StrLen(record) > 0 { this.TryItem(TDBID.Create(record)); };
    };
    this.Say(NPVWardrobeView.Text("Vestindo " + s.wardrobeOutfitNames[index] + ".", "Wearing " + s.wardrobeOutfitNames[index] + ".", "Poniendo " + s.wardrobeOutfitNames[index] + "."));
  }

  // W24: an outfit name being edited: text field, OK and cancel in the place of the row.
  private func RenameLine(line: ref<inkHorizontalPanel>, k: Int32) -> Void {
    let s = NPVMakerSession.GetInstance();
    let input = HubTextInput.Create();
    input.SetWidth(720.0);
    input.SetMaxLength(40);
    input.Reparent(line, this.menu);
    input.GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
    input.SetText(s.wardrobeOutfitNames[k]);
    this.renameInput = input;
    this.Button(line, "", n"npvw_outfit_ok", 120.0, n"check", true).GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
    this.Button(line, "", n"npvw_outfit_cancel", 72.0, n"close", true).GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
  }

  private func OutfitLine(line: ref<inkHorizontalPanel>, j: Int32) -> Void {
    let s = NPVMakerSession.GetInstance();
    let row = NPVWardrobeRow.Make();
    if j == 0 {
      row.SetName(n"npvw_outfit_save");
      row.SetText(NPVWardrobeView.Text("+ SALVAR O QUE ESTA VESTIDO COMO OUTFIT", "+ SAVE WHAT IS WORN AS AN OUTFIT", "+ GUARDAR LO PUESTO COMO CONJUNTO") + "\n"
        + NPVWardrobeView.Text("CADA OUTFIT VIRA UMA APARENCIA DO NPV (NCA E AMM)", "EACH OUTFIT BECOMES AN APPEARANCE OF THE NPV (NCA AND AMM)", "CADA CONJUNTO ES UNA APARIENCIA DEL NPV (NCA Y AMM)"));
    } else {
      let k = j - 1;
      row.SetName(StringToName("npvw_outfit_" + ToString(k)));
      row.SetText(s.wardrobeOutfitNames[k] + "\n" + ToString(s.wardrobeOutfitCounts[k]) + NPVWardrobeView.Text(" PECAS  ·  CLIQUE PARA VESTIR", " PIECES  ·  CLICK TO WEAR", " PRENDAS  ·  PULSA PARA PONER"));
    };
    row.SetFlipped(true);
    row.ToggleAnimations(true);
    row.ToggleSounds(true);
    row.Reparent(line, this.menu);
    row.GetRootWidget().SetAnchorPoint(new Vector2(0.0, 0.0));
    row.RegisterToCallback(n"OnBtnClick", this, n"OnButton");
    row.Mark(false, j > 0);
    let atlas: ResRef;
    let part: CName;
    if this.ShadowIcon(6, atlas, part) { row.SetIcon(atlas, part, j == 0); };
    if j > 0 {
      row.SetRowWidth(720.0);
      this.Button(line, NPVWardrobeView.Text("NOME", "NAME", "NOMBRE"), StringToName("npvw_outfit_ren_" + ToString(j - 1)), 120.0, n"", false).GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
      this.Button(line, "", StringToName("npvw_outfit_del_" + ToString(j - 1)), 72.0, n"close", true).GetRootWidget().SetMargin(new inkMargin(0.0, 22.0, 0.0, 0.0));
    };
  }

  // OUTFITS: save the current look, wear or delete a saved one.
  private func RenderOutfits() -> Void {
    let s = NPVMakerSession.GetInstance();
    let total = ArraySize(s.wardrobeOutfitIds) + 1;
    this.listTotal = total;
    let visible = NPVWardrobeView.Rows();
    this.offset = Max(0, Min(this.offset, total - visible));
    this.rows.RemoveAllChildren();
    ArrayClear(this.cardIDs);
    ArrayClear(this.cardDrawn);
    let j = this.offset;
    while j < total && j < this.offset + visible {
      let line = this.Row(this.rows, 12.0);
      if j > 0 && this.renameIndex == j {
        this.RenameLine(line, j - 1);
      } else {
        this.OutfitLine(line, j);
      };
      this.BindWheel(line);
      j += 1;
    };
    this.scrollTrack.SetVisible(total > visible);
    this.scrollThumb.SetVisible(total > visible);
    this.trackHit.SetVisible(total > visible);
    this.countLabel.SetText("OUTFITS DO NPV  ·  " + ToString(total - 1) + NPVWardrobeView.Text(" SALVOS  ·  O VESTIDO AGORA E A APARENCIA PADRAO", " SAVED  ·  WHAT IS WORN NOW IS THE DEFAULT APPEARANCE", " GUARDADOS  ·  LO PUESTO AHORA ES LA APARIENCIA PREDETERMINADA"));
    this.pageLabel.SetText("");
    this.previousButton.SetDisabled(this.offset == 0);
    this.nextButton.SetDisabled(this.offset + visible >= total);
  }

  private func BindWheel(widget: ref<inkWidget>) -> Void {
    // Same path as the UI08 picker (RUNTIME PASS): the editor receives the
    // relative event at the hit target and forwards it to HandleWheel.
    widget.RegisterToCallback(n"OnRelative", this.menu, n"NPVOnChoiceWheel");
    let compound = widget as inkCompoundWidget;
    if !IsDefined(compound) { return; };
    let i = 0;
    while i < compound.GetNumChildren() {
      this.BindWheel(compound.GetWidgetByIndex(i));
      i += 1;
    };
  }

  public func ScrollPress(evt: ref<inkPointerEvent>, pressed: Bool) -> Bool {
    if !IsDefined(this.trackHit) || !evt.IsAction(n"click") { return false; };
    this.dragging = pressed;
    this.DragTo(evt);
    return true;
  }

  public func StopDrag() -> Void { this.dragging = false; }

  private func DragTo(evt: ref<inkPointerEvent>) -> Void {
    let visible = NPVWardrobeView.Rows();
    let local = WidgetUtils.GlobalToLocal(this.trackHit, evt.GetScreenSpacePosition());
    let fraction = ClampF(local.Y / (NPVWardrobeView.Pitch() * Cast<Float>(visible)), 0.0, 1.0);
    let target = Cast<Int32>(fraction * Cast<Float>(Max(0, this.listTotal - visible)) + 0.5);
    if target != this.offset { this.offset = target; this.Render(); };
  }

  public func HandleWheel(evt: ref<inkPointerEvent>) -> Bool {
    if this.dragging && evt.IsAction(n"mouse_y") {
      this.DragTo(evt);
      return true;
    };
    if !IsDefined(this.root) || !evt.IsAction(n"mouse_wheel") || evt.IsConsumed() || evt.GetAxisData() == 0.0 { return false; };
    evt.Handle();
    evt.Consume();
    this.Scroll(evt.GetAxisData() > 0.0 ? -1 : 1);
    return true;
  }

  private func Scroll(delta: Int32) -> Void {
    let next = Max(0, Min(this.offset + delta, this.listTotal - NPVWardrobeView.Rows()));
    if next != this.offset { this.offset = next; this.Render(); };
  }

  private func Allowed() -> Bool {
    let s = NPVMakerSession.GetInstance();
    if !IsDefined(s) || !s.active || !this.menu.NPVCanEdit() { return false; };
    let host = s.system.GetPuppetPreviewGameController();
    return IsDefined(host) && host.GetGamePuppet() == this.puppet && this.puppet != GetPlayer(GetGameInstance());
  }

  protected cb func OnButton(widget: wref<inkWidget>) -> Bool {
    let name = NameToString(widget.GetName());
    this.menu.NPVStudioClearFocus();
    if Equals(name, "npvw_close") { this.closeRequested = true; return true; };
    if Equals(name, "npvw_previous") { this.Scroll(-NPVWardrobeView.Rows()); return true; };
    if Equals(name, "npvw_next") { this.Scroll(NPVWardrobeView.Rows()); return true; };
    if StrBeginsWith(name, "npvw_tab_") {
      this.category = Clamp(StringToInt(StrAfterFirst(name, "npvw_tab_"), 3), 0, 6);
      this.mode = 0;
      this.renameIndex = 0;
      this.pinnedView = "";
      this.offset = 0;
      if StrLen(this.query) > 0 { this.search.SetText(""); this.query = ""; };
      this.RefreshTabs(); this.Render();
      return true;
    };
    if StrBeginsWith(name, "npvw_chip_") {
      let chip = StringToInt(StrAfterFirst(name, "npvw_chip_"), 0);
      if chip == 4 { this.source = this.source == 2 ? 1 : 2; if this.mode >= 2 { this.mode = 0; }; } else { this.mode = chip; };
      this.renameIndex = 0;
      this.pinnedView = "";
      this.offset = 0;
      this.RefreshTabs(); this.Render();
      return true;
    };
    if StrBeginsWith(name, "npvw_star_") {
      let starred = this.EntryByKey(StrAfterFirst(name, "npvw_star_"));
      if IsDefined(starred) && this.favoritesLoaded {
        let key = starred.key;
        if ArrayContains(this.favorites, key) { ArrayRemove(this.favorites, key); } else { ArrayPush(this.favorites, key); };
        let text = "format\tnpv-wardrobe-favorites-1\n";
        for favorite in this.favorites { text += "favorite\t" + favorite + "\n"; };
        if !NPVFiles.Write("wardrobe-favorites.txt", text + "end\t1\n") {
          this.Say(NPVWardrobeView.Text("Favorita so nesta sessao: o RedFileSystem nao gravou o arquivo.", "Favorite for this session only: RedFileSystem did not write the file.", "Favorita solo en esta sesion: RedFileSystem no guardo el archivo."));
        };
        this.Render();
      };
      return true;
    };
    if !this.Allowed() { return true; };
    if Equals(name, "npvw_refit_prev") || Equals(name, "npvw_refit_next") {
      let count = ArraySize(this.RefitOptions());
      this.refitIndex = (this.refitIndex + (Equals(name, "npvw_refit_next") ? 1 : count - 1)) % count;
      let value = this.RefitValue();
      this.fit.Select(value);
      this.RefreshRefit();
      if !Equals(value, "auto") && !this.fit.hookReady {
        this.Say(NPVWardrobeView.Text("Troca de corpo indisponivel: o plugin NPVMakerWardrobe nao respondeu. Confira se ele esta instalado.", "Body switch unavailable: the NPVMakerWardrobe plugin did not answer. Check that it is installed.", "Cambio de cuerpo no disponible: el plugin NPVMakerWardrobe no respondio. Comprueba que esta instalado."));
      } else {
        this.Say(NPVWardrobeView.Text("So muda pecas que tem versao para esse corpo; as outras ficam como estavam.", "Only pieces made for that body change; the others stay as they were.", "Solo cambian las prendas hechas para ese cuerpo; las demas quedan igual."));
      };
      return true;
    };
    if Equals(name, "npvw_outfit_save") { this.renameIndex = 0; this.SaveOutfit(); this.RefreshTabs(); this.Render(); return true; };
    if StrBeginsWith(name, "npvw_outfit_ren_") {
      this.renameIndex = StringToInt(StrAfterFirst(name, "npvw_outfit_ren_"), -1) + 1;
      this.renameInput = null;
      this.Render();
      return true;
    };
    if Equals(name, "npvw_outfit_ok") {
      if IsDefined(this.renameInput) { this.RenameOutfit(this.renameIndex - 1, this.renameInput.GetText()); };
      this.renameIndex = 0;
      this.renameInput = null;
      this.Render();
      return true;
    };
    if Equals(name, "npvw_outfit_cancel") {
      this.renameIndex = 0;
      this.renameInput = null;
      this.Render();
      return true;
    };
    if StrBeginsWith(name, "npvw_outfit_del_") {
      this.renameIndex = 0;
      this.renameInput = null;
      this.DeleteOutfit(StringToInt(StrAfterFirst(name, "npvw_outfit_del_"), -1));
      this.RefreshTabs(); this.Render();
      return true;
    };
    if StrBeginsWith(name, "npvw_outfit_") {
      this.WearOutfit(StringToInt(StrAfterFirst(name, "npvw_outfit_"), -1));
      this.ReadWorn(); this.RefreshTabs(); this.Render();
      return true;
    };
    if Equals(name, "npvw_clear") {
      this.ClearAll(true);
      this.Say(NPVWardrobeView.Text("Roupas retiradas. Sem nada vestido, o NPV sai sem roupa.", "Clothes removed. With nothing worn, the NPV has no clothes.", "Ropa quitada. Sin nada puesto, el NPV sale sin ropa."));
      this.ReadWorn(); this.RefreshTabs(); this.Render();
      return true;
    };
    if Equals(name, "npvw_loose") {
      let names = this.drawnNames;
      for piece in names {
        if this.OwnerSlot(piece) < 0 { this.HideDrawn(piece); };
      };
      this.ReadDrawn();
      this.Say(NPVWardrobeView.Text("Pecas soltas retiradas.", "Loose pieces removed.", "Piezas sueltas quitadas."));
      this.RefreshTabs(); this.Render();
      return true;
    };
    if StrBeginsWith(name, "npvw_drawn_") {
      let index = StringToInt(StrAfterFirst(name, "npvw_drawn_"), -1);
      if index >= 0 && index < ArraySize(this.cardDrawn) {
        let piece = this.cardDrawn[index];
        this.RemovePiece(piece);
        // A slot item with nothing left on the puppet is taken off too.
        this.ReadDrawn();
        this.Say(NPVWardrobeView.Text("Peca retirada: ", "Piece taken off: ", "Prenda quitada: ") + NPVWardrobeView.DrawnLabel(piece));
        this.RefreshTabs(); this.Render();
      };
      return true;
    };
    if StrBeginsWith(name, "npvw_off_") || StrBeginsWith(name, "npvw_row_") {
      let clicked = this.EntryByKey(StrBeginsWith(name, "npvw_off_") ? StrAfterFirst(name, "npvw_off_") : StrAfterFirst(name, "npvw_row_"));
      if !IsDefined(clicked) { return true; };
      let id = clicked.id;
      if ArrayContains(this.worn, id) {
        let i = 0;
        let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
        while i < ArraySize(this.slots) {
          let obj = ts.GetItemInSlot(this.puppet, this.slots[i]);
          if (IsDefined(obj) && Equals(ItemID.GetTDBID(obj.GetItemID()), id)) || (this.changed[i] && Equals(this.desired[i], id)) { this.TakeOff(i); };
          i += 1;
        };
        this.Say(NPVWardrobeView.Text("Peca retirada.", "Piece taken off.", "Prenda quitada."));
      } else {
        this.TryItem(id);
      };
      this.ReadWorn(); this.RefreshTabs(); this.Render();
      return true;
    };
    return true;
  }

  // The production Wardrobe+ preview path (v50/v121): preview ItemIDs,
  // ordinary attach then force attach, incremental pieces, no appearance change
  // after dressing. The editor already supplies the customized player body.
  private func Attach(i: Int32) -> Bool {
    // Resolve BodyType before GivePreview/AddItem; never change an item's
    // appearance after attachment (the production Wardrobe+ V460 contract).
    this.fit.Select(this.RefitValue());
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let item = ItemID.FromTDBID(this.desired[i]);
    let pid = ts.CreatePreviewItemID(item);
    if !ArrayContains(this.given, pid) && !ArrayContains(this.originals, pid) && !ts.HasItem(this.puppet, pid) {
      ArrayPush(this.given, pid);
    };
    let given = ts.GivePreviewItemByItemID(this.puppet, item);
    let before = ts.CanPlaceItemInSlot(this.puppet, this.slots[i], pid);
    // The CC puppet is created in a menu, outside normal actor equipment setup.
    // Vanilla prepares explicit slots this way for entities outside that flow
    // (GiveWeaponToTurret). Initialize only the captured preview's six slots;
    // never patch Character records or initialize the controlled player.
    // W18 (QA W17 1, MEDIDO 08/10/2026 13:30): InitializeSlots replaces the puppet's prepared slots with the list it
    // gets and empties them. Every slot this tab can use is prepared ONCE, on the first piece; a slot outside that
    // list (never expected) prepares the whole list again and the chosen pieces go back in.
    let initialized = true;
    if !ArrayContains(this.initSlots, this.slots[i]) {
      if ArraySize(this.initSlots) == 0 { this.initSlots = NPVWardrobeView.AllSlots(); };
      if !ArrayContains(this.initSlots, this.slots[i]) { ArrayPush(this.initSlots, this.slots[i]); };
      let prepared = this.initSlots;
      initialized = ts.InitializeSlots(this.puppet, prepared);
      this.operations += "init_slots\t" + ToString(ArraySize(prepared)) + "\tok=" + ToString(initialized) + "\n";
      this.Reseat(i);
    };
    let after = ts.CanPlaceItemInSlot(this.puppet, this.slots[i], pid);
    let old = this.trial[i];
    ts.RemoveItemFromSlot(this.puppet, this.slots[i], true);
    let normal = ts.AddItemToSlot(this.puppet, this.slots[i], pid);
    let priority = false;
    if !normal { priority = ts.AddItemToSlot(this.puppet, this.slots[i], pid, true); };
    let accepted = normal || priority;
    this.operations += "attach\t" + TDBID.ToStringDEBUG(this.desired[i])
      + "\tslot=" + TDBID.ToStringDEBUG(this.slots[i])
      + "\tgive_preview=" + ToString(given)
      + "\tpreview_data=" + ToString(IsDefined(ts.GetItemData(this.puppet, pid)))
      + "\tcan_before_init=" + ToString(before)
      + "\tinitialize_slots=" + ToString(initialized)
      + "\tcan_after_init=" + ToString(after)
      + "\tnormal_attach=" + ToString(normal)
      + "\tpriority_attach=" + ToString(priority) + "\n";
    NPVFiles.Write(NPVWardrobeView.File("-operations.tsv"), "probe\t" + NPVWardrobeView.Label() + "\npuppet_record\t" + TDBID.ToStringDEBUG(this.puppet.GetRecordID()) + "\n" + this.operations + "end\t1\n");
    // A replaced piece leaves even when the new one is refused: nothing stays drawn without a row to take it off.
    if NotEquals(ItemID.GetTDBID(old), this.desired[i]) { this.Drop(old); };
    if accepted { this.trial[i] = pid; } else {
      if NotEquals(ItemID.GetTDBID(old), this.desired[i]) { let none: ItemID; this.trial[i] = none; };
    };
    this.Reseat(i);
    ModLog(n"NPVMaker", NPVWardrobeView.Label() + " preview " + TDBID.ToStringDEBUG(this.desired[i]) + " slot=" + TDBID.ToStringDEBUG(this.slots[i]) + " accepted=" + ToString(accepted));
    return accepted;
  }

  // Pieces chosen here that the game dropped from their slot (still in the inventory, often still drawn) go back in.
  private func Reseat(except: Int32) -> Void {
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let k = 0;
    while k < ArraySize(this.slots) {
      if k != except && (!this.changed[k] || TDBID.IsValid(this.desired[k])) && ItemID.IsValid(this.trial[k])
        && !ts.HasItemInSlot(this.puppet, this.slots[k], this.trial[k]) && ts.HasItem(this.puppet, this.trial[k]) {
        let back = ts.AddItemToSlot(this.puppet, this.slots[k], this.trial[k]);
        if !back { back = ts.AddItemToSlot(this.puppet, this.slots[k], this.trial[k], true); };
        this.operations += "reseat\t" + TDBID.ToStringDEBUG(this.desired[k]) + "\tslot=" + TDBID.ToStringDEBUG(this.slots[k]) + "\tok=" + ToString(back) + "\n";
      };
      k += 1;
    };
  }

  private func SlotIndex(placement: TweakDBID) -> Int32 {
    let i = ArrayFindFirst(this.slots, placement);
    if i >= 0 { return i; };
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let obj = ts.GetItemInSlot(this.puppet, placement);
    let original: ItemID;
    if IsDefined(obj) { original = obj.GetItemID(); };
    i = ArraySize(this.slots);
    ArrayPush(this.slots, placement); ArrayPush(this.originals, original);
    ArrayPush(this.trial, original); ArrayPush(this.desired, ItemID.GetTDBID(original));
    ArrayPush(this.changed, false); ArrayPush(this.watched, false); this.slotsInitialized = false;
    return i;
  }

  private func Watch(i: Int32, name: String) -> Void {
    NPVMakerSession.GetInstance().wardrobePreviewTouched = true;
    this.lastEquippedSlot = i;
    this.changed[i] = true;
    this.watched[i] = true;
    this.retries = 0;
    this.watchUntil = this.ticks + 70;
    this.watchName = name;
    this.menu.NPVWardrobeCamera(true);
  }

  private func TryItem(record: TweakDBID) -> Void {
    // Categories locate cards. The ITEM determines its actual attachment slot.
    let placement = NPVWardrobeCatalog.Placement(record);
    if !TDBID.IsValid(record) || !TDBID.IsValid(placement) {
      this.Say(NPVWardrobeView.Text("Essa peca nao diz em que parte do corpo vai. Tente outra.", "This piece does not say where it goes on the body. Try another.", "Esta prenda no dice donde va en el cuerpo. Prueba otra."));
      return;
    };
    let names = this.PieceNames(record);
    let h = ArraySize(this.hiddenParts) - 1;
    while h >= 0 {
      let part = this.hiddenParts[h];
      if !IsDefined(part) { ArrayErase(this.hiddenParts, h); }
      else {
        if this.NameMatches(names, part.GetName()) { ArrayErase(this.hiddenParts, h); part.Toggle(true); };
      };
      h -= 1;
    };
    if ArraySize(this.OpenSlots()) == 0 {
      ArrayClear(this.beforeWear);
      for c in this.puppet.GetComponents() {
        if NPVWardrobeView.GeneratedPiece(c) && c.IsEnabled() && !ArrayContains(this.pendingNames, c.GetName()) { ArrayPush(this.beforeWear, c.GetName()); };
      };
    };
    let i = this.SlotIndex(placement);
    // W13 (author 08/10/2026, "more than one piece per slot, like NCA Wardrobe"): as Wardrobe+ v80, only the piece in
    // the SAME game slot leaves (Attach replaces it); pieces of one category in different slots stay together.
    let rec = TweakDBInterface.GetItemRecord(record);
    let name = IsDefined(rec) ? GetLocalizedTextByKey(rec.DisplayName()) : "";
    if StrLen(name) == 0 { name = TDBID.ToStringDEBUG(record); };
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let current = ts.GetItemInSlot(this.puppet, this.slots[i]);
    if IsDefined(current) && NotEquals(ItemID.GetTDBID(current.GetItemID()), record) {
      let queuedFrom = ArraySize(this.pendingNames);
      this.QueueDrawn(i);
      // W19 (QA W18 1, MEDIDO 13:46): a colour variant reuses the old piece's component (vest_w pink -> white). The old
      // item leaves the inventory at once, so whatever of it stays on after dressing belongs to the new piece.
      let q = queuedFrom;
      while q < ArraySize(this.pendingNames) { ArrayRemove(this.beforeWear, this.pendingNames[q]); q += 1; };
    };
    this.lastAction = "wear\t" + TDBID.ToStringDEBUG(record);
    this.Watch(i, name);
    this.desired[i] = record;
    this.Attach(i);
    this.Say(NPVWardrobeView.Text("Vestindo: ", "Putting on: ", "Poniendo: ") + name);
  }

  // W15 (QA W14 6): a preview item that left its slot stayed in the puppet's inventory and the game kept drawing it in
  // every remount. It leaves the inventory now (the editor's original items never do).
  // W22 (crash 08/10/2026 15:54:05, ACCESS_VIOLATION reading 0x1EC in code next to the exe, at the instant
  // tactical_pants_x_dirty_denim was replaced by veegee_casual_pt23_pants_color1 in OutfitSlots.LegsMiddle): W15-W21
  // removed the old item from the inventory in the SAME frame the new one went into the slot, while the game was still
  // rebuilding the puppet for it. HIPOTESE: the rebuild read the removed item. The item now leaves 28 ticks later,
  // after the rebuild, and only if no slot holds it again.
  private func Drop(pid: ItemID) -> Void {
    if !ItemID.IsValid(pid) || ArrayContains(this.originals, pid) || ArrayContains(this.dropQueue, pid) { return; };
    ArrayPush(this.dropQueue, pid);
    ArrayPush(this.dropAt, this.ticks + 28);
  }

  private func ProcessDrops() -> Void {
    if ArraySize(this.dropQueue) == 0 { return; };
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    let d = ArraySize(this.dropQueue) - 1;
    while d >= 0 {
      if this.ticks >= this.dropAt[d] {
        let pid = this.dropQueue[d];
        let held = false;
        let k = 0;
        while k < ArraySize(this.slots) {
          if ts.HasItemInSlot(this.puppet, this.slots[k], pid) { held = true; };
          k += 1;
        };
        if !held && ts.HasItem(this.puppet, pid) {
          let removed = ts.RemoveItem(this.puppet, pid, 1);
          this.operations += "drop\t" + TDBID.ToStringDEBUG(ItemID.GetTDBID(pid)) + "\tremoved=" + ToString(removed) + "\n";
          ArrayRemove(this.given, pid);
        } else {
          if held { this.operations += "drop_skipped_worn_again\t" + TDBID.ToStringDEBUG(ItemID.GetTDBID(pid)) + "\n"; };
        };
        ArrayErase(this.dropQueue, d);
        ArrayErase(this.dropAt, d);
      };
      d -= 1;
    };
  }

  // Meshes the item in slot i draws now; the ones the game still draws a moment after it leaves are switched off.
  private func QueueDrawn(i: Int32) -> Void {
    let queued = false;
    for piece in this.drawnNames {
      if this.OwnerSlot(piece) == i && !ArrayContains(this.pendingNames, piece) { ArrayPush(this.pendingNames, piece); queued = true; };
    };
    // Measured pieces of slot i also when the game already dropped its item from the slot.
    let w = 0;
    while w < ArraySize(this.ownNames) {
      if this.ownSlots[w] == i && !ArrayContains(this.pendingNames, this.ownNames[w]) { ArrayPush(this.pendingNames, this.ownNames[w]); queued = true; };
      w += 1;
    };
    if queued { this.pendingUntil = this.ticks + 56; };
    // Its measured pieces stop belonging to it; the next item in the slot measures its own.
    let m = 0;
    while m < ArraySize(this.ownSlots) {
      if this.ownSlots[m] == i { this.ownSlots[m] = -1; };
      m += 1;
    };
  }

  private func TakeOff(i: Int32) -> Void {
    if i < 0 || i >= ArraySize(this.slots) { return; };
    this.lastAction = "off\t" + TDBID.ToStringDEBUG(this.desired[i]);
    this.QueueDrawn(i);
    // W20 (audit): taking one piece off no longer closes the watch window of a piece just put on in another slot
    // (W14-W19 zeroed it, so that piece was neither retried nor measured).
    NPVMakerSession.GetInstance().wardrobePreviewTouched = true;
    this.changed[i] = true;
    this.watched[i] = false;
    this.desired[i] = TDBID.None();
    let ts = GameInstance.GetTransactionSystem(this.puppet.GetGame());
    ts.RemoveItemFromSlot(this.puppet, this.slots[i], true);
    this.Drop(this.trial[i]);
    let empty: ItemID;
    this.trial[i] = empty;
  }
}
