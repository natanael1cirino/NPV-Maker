#pragma once
#include <cstdint>
#include <istream>
#include <unordered_set>

namespace npvorigin {
// Read only the record index of the local unmodified TweakDB blob.
// Format: magic + seven uint32 fields; record table = count + (id64,type32).
// Layout reference: WolvenKit.RED4/TweakDB/{Header,TweakDBReader}.cs.
inline bool Read(std::istream& input, std::unordered_set<uint64_t>& output) {
    input.seekg(0, std::ios::end);
    const auto size = input.tellg();
    input.seekg(0);
    uint32_t header[8]{};
    if (!input.read(reinterpret_cast<char*>(header), sizeof(header))) return false;
    if (header[0] != 0x0BB1DB47 || header[1] != 8 || header[2] != 4 ||
        header[5] < 32 || static_cast<uint64_t>(header[5]) + 4 > static_cast<uint64_t>(size)) return false;
    input.seekg(header[5]);
    uint32_t count{};
    if (!input.read(reinterpret_cast<char*>(&count), 4) || count == 0 || count > 2000000 ||
        static_cast<uint64_t>(header[5]) + 4 + static_cast<uint64_t>(count) * 12 > static_cast<uint64_t>(size)) return false;
    std::unordered_set<uint64_t> staged;
    staged.reserve(count);
    for (uint32_t i = 0; i < count; ++i) {
        uint64_t id{}; uint32_t type{};
        if (!input.read(reinterpret_cast<char*>(&id), 8) || !input.read(reinterpret_cast<char*>(&type), 4)) return false;
        staged.insert(id & 0xFFFFFFFFFFull);
    }
    output.insert(staged.begin(), staged.end());
    return true;
}
inline int32_t Classify(uint64_t id, bool ready, const std::unordered_set<uint64_t>& records) {
    id &= 0xFFFFFFFFFFull;
    return !ready || !id ? 0 : (records.contains(id) ? 1 : 2);
}
}
