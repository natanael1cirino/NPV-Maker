public static native func NPVMakerWardrobeSetBody(preview: ref<Entity>, body: String) -> Bool

// 0 unknown (index unavailable), 1 base/DLC ID, 2 ID added by mods.
public static native func NPVMakerWardrobeOrigin(item: TweakDBID) -> Int32
